<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Edit Product</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Edit Product</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-product') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
      @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                      <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                     </div>
                     <hr>
                     <div class="row">
                        <input type="hidden" name="edit_id" value="{{ $edit_product->id }}">
                       <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Brand Name : <font color="red">*</font></label>
                              <select name="brand_id" id="brand_id" class="form-control" required="">
                                 <option> -- Choose Brand -- </option>
                                 <?php $Brands = DB::table('brand')->get(); ?>
                                 @foreach($Brands as $data)
                                 <option value="{{ $data->id }}" {{($data->id == $edit_product->brand_id) ? "selected" : ""}}>{{ $data->brand_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Model : <font color="red">*</font></label>
                              <select name="model_id" id="model_id" class="form-control" required="">
                                 <option> -- Choose Model -- </option>
                                 <?php $model = DB::table('category')->where('brand_id', $edit_product->brand_id)->get(); ?>
                                 @foreach($model as $data)
                                 <option value="{{ $data->id }}" {{($data->id == $edit_product->model_id) ? "selected" : ""}}>{{ $data->category_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Id No : </label>
                              <input type="text" class="form-control" name="id_no" value="{{ $edit_product->id_no}}" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Year : </label>
                              <input type="text" id="year" name="year" class="form-control" value="{{ $edit_product->year}}" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Percentage : </label>
                              <input type="text" id="percentage" name="percentage" class="form-control" value="{{ $edit_product->percentage }}" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Price : </label>
                              <input type="text" id="price" name="price" class="form-control" value="{{ $edit_product->price }}" required=""> 
                           </div>
                        </div>                       
                        <div class="col-md-6 field_wrapper">
                          @php $features = explode(",", $edit_product->features) @endphp
                          <div>
                            <label class="control-label">Features : </label>
                            @foreach($features as $data)
                              <input type="text" class="form-control" name="features[]" value="{{ $data}}"  /> <br>
                            @endforeach                                                        
                          </div>
                        </div>
                        <div class="col-md-12">
                           <div class="form-group">  
                              <label class="control-label">Description : </label>
                              <textarea class="form-control" name="description" id="descriptions" rows="4" required="">{{ $edit_product->description }}</textarea>
                           </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group"> 
                              <label class="control-label">Activity Image : </label>
                              <?php $producimage = DB::table('product_gallery')->where('product_id', $edit_product->id)->get(); ?>
                              @foreach($producimage as $img)
                                <img src="{{ URL::asset('/public/product_image/') }}/{{ $img->image }}" width="100px" height="100px"> 
                              @endforeach
                          </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Save</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
      
<!-- Script for model select according to brand  -->
<script type="text/javascript">
   $('#brand_id').change(function()
   {
      var barndId = $(this).val();
      if(barndId)
      {
         $.ajax({
            type:"GET",
            url:"{{url('get-model/')}}"+'/'+barndId, 
            success:function(res)
            {               
               if(res){
                  $("#model_id").empty();
                  $("#model_id").append('<option>-- Choose Model --</option>');
                  $.each(res,function(key,value){
                     $("#model_id").append('<option value="'+value.id+'">'+value.category_name+'</option>');
                  });
                }
               else{
                  $("#model_id").empty();
               }
            }
         });
      }
      else{
         $("#model_id").empty();
      } 
   });
</script>

<!-- add more features script -->
<script type="text/javascript">
   $(document).ready(function(){
       var maxField = 10; //Input fields increment limitation
       var addButton = $('.add_button'); //Add button selector
       var wrapper = $('.field_wrapper'); //Input field wrapper
       var fieldHTML = '<div><input type="text" class="form-control" name="features[]" value=""/><a href="javascript:void(0);" class="remove_button btn btn-danger">Remove</a></div>'; //New input field html 
       var x = 1; //Initial field counter is 1
       
       //Once add button is clicked
       $(addButton).click(function(){
           //Check maximum number of input fields
           if(x < maxField){ 
               x++; //Increment field counter
               $(wrapper).append(fieldHTML); //Add field html
           }
       });
       
       //Once remove button is clicked
       $(wrapper).on('click', '.remove_button', function(e){
           e.preventDefault();
           $(this).parent('div').remove(); //Remove field html
           x--; //Decrement field counter
       });
   });
</script>

