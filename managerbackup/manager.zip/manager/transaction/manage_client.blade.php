<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Client Transaction</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Client Transaction</li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                   <div class="row">
                     <div class="col-sm-6">
                        <div class="m-b-30">
                           <a href="{{URL::to('add-transaction')}}" class="btn btn-primary waves-effect waves-light">Add Money/Refund <i class="md md-add-circle-outline"></i></a>
                        </div>
                     </div>
                  </div> 
                  <hr>
                    @if(Session::get('userRole') == 1)
                    <form  action="{{ URL::to('filter-client') }}" method="POST" name="myForm" onsubmit="return validateForm()" id="FormValidation" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                    <?php 
                      $whitelabel_id = $whitelabel_id ?? '';
                      $manager_id = $manager_id ?? '';
                      $employee_id = $employee_id ?? '';
                      $fromdate = $fromdate ?? '';
                      $enddate = $enddate ?? '';
                    ?>
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        @if($whitelabel_id || $manager_id || $employee_id)
                        <a href="{{URL::to('manage-leads')}}">
                            <h3>
                                <i class="icon-filter icon-stack-base"></i>
                                <i class="icon-remove"></i> Filter
                            </h3>
                        </a>
                        @else
                          <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                        @endif
                      </div>
                    <?php
                      if(session::get('userRole') == 1){
                        $whitelabel = DB::table('users')->where('users_role', 2)->get(); 
                        $manager = DB::table('users')->where('users_role', 3)->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();             
                      }elseif(session::get('userRole') == 2){
                        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();
                      }elseif(session::get('userRole') == 3){
                        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();
                      }elseif(session::get('userRole') == 4){
                        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();
                      }
                    ?>
                    
                    @if(Session::get('userRole') == 1)

                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="whitelabel_id" id="whitelabel_id" class="form-control">
                             <option value="">-- Select White Label --</option>
                              @foreach($whitelabel as $data)
                                <option value="{{ $data->id }}" {{($data->id == $whitelabel_id) ? "selected" : ""}}>{{ $data->name }}</option>
                              @endforeach
                          </select>
                        </div>
                      </div>                      
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="manager_id" id="manager_id"  class="form-control">
                           <option value="">-- Select Manager --</option>
                           @foreach($manager as $data)
                              <option value="{{ $data->id }}" {{($data->id == $manager_id) ? "selected" : ""}}>{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="employee_id" id="employee_id"  class="form-control">
                           <option value="">-- Select Employee --</option>
                           @foreach($employee as $data)
                              <option value="{{ $data->id }}" {{($data->id == $employee_id) ? "selected" : ""}}>{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>

                     @elseif(Session::get('userRole') == 2)
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="manager_id" id="manager_id"  class="form-control">
                           <option value="">-- Select Manager --</option>
                           @foreach($manager as $data)
                              <option value="{{ $data->id }}">{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="employee_id" id="employee_id"  class="form-control">
                           <option value="">-- Select Employee --</option>
                          <!--  @foreach($employee as $data)
                              <option value="{{ $data->id }}">{{ $data->name }}</option>
                           @endforeach -->
                        </select>
                      </div>
                     @else
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="employee_id" id="employee_id"  class="form-control">
                           <option value="">-- Select Employee --</option>
                           @foreach($employee as $data)
                              <option value="{{ $data->id }}">{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>
                     @endif
                      <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                       <a href="{{URL::to('client-listing')}}" class="btn btn-primary">Refresh</a>
                     </div>
                  </div>
                </form>
                    <hr>
                    <form  action="{{ URL::to('search-status-transaction') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                    @csrf               
                    <div class="row">
                        <?php
                            $leadstatus = DB::table('status')->get();
                            $status_id = $status_id ?? '';
                        ?>
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="form-group">  
                                <select name="status_id" id="status_id" class="form-control">
                                    <option value="">-- Select Transaction Status --</option>
                                    <option value="0" {{($status_id == 0) ? "selected" : ""}}>Approved</option>
                                    <option value="1" {{($status_id == 1) ? "selected" : ""}}>NotApproved</option>
                                </select>
                            </div>
                        </div>   
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                            <a href="{{URL::to('client-listing')}}" class="btn btn-primary">Refresh</a>
                        </div>
                    </div>
                    </form>
                    <hr>
                    @endif
                    <form  action="{{ URL::to('search-translation-bydate') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                       <div class="col-md-4">
                            <div class="form-group">
                             <input type="text" value="{{ $fromdate ?? ''}}" id="my_date_picker1" name="from_date" class="form-control" placeholder="From Date" readonly=""></div>
                       </div>
                       <div class="col-md-4">
                          <div class="form-group">  
                             <input type="text" id="my_date_picker2" value="{{ $enddate ?? ''}}" name="end_date" class="form-control" aria-required="true" placeholder="To Date" required="" readonly=""> 
                          </div>
                       </div>
                       <div class="col-md-3 col-sm-3 col-xs-3">
                         <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                         <a href="{{URL::to('manage-leads')}}" class="btn btn-primary">Refresh</a>
                       </div>
                    </div>
                </form>
                  <hr>
                  <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                  <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
                    <li role="presentation" class="active">
                      <a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
                        <span class="text" style="font-size: 19px;"><b>Deposite</b></span>
                      </a>
                    </li>
                    <li role="presentation" class="next">
                      <a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile">
                        <span class="text" style="font-size: 19px;"><b>Refund</b></span>
                      </a>
                    </li>
                  </ul>
                <div id="myTabContent" class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active show" id="home" aria-labelledby="home-tab">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                              <thead>
                                <tr>
                                    <th>Sr.No.</th>                         
                                    <th>Client Name</th>
                                    <th>Deposit</th>   
                                    <th>Available Balance</th>
                                    <th>Status</th>
                                    <th>Date</th>                         
                                  <!-- <th>Action</th> -->
                                </tr>
                              </thead>
                              <tbody>                                
                                @foreach($withdrawal as $key => $data)                               
                                <?php 
                                    $withdrawal = DB::table('wallet_transaction')->where('client_id', $data->client_id)->where('status', 0)->orderBy('id', 'DESC')->first();
                                    
                                    $uploadby = DB::table('users')->where('id', $data->client_id)->first(); ?>
                                    @if(isset($uploadby->name))
                                    <tr class="gradeX">                         
                                        <td>{{ ++$key }}</td>
                                        <td>{{ $uploadby->name ?? ''}}</td>                             
                                        <td>{{ $data->deposit }}</td><!-- 
                                        <td>{{ $data->payment_mode }}</td> -->
                                        <td>{{ $withdrawal->available_balance }}</td>
                                        @if($data->status == 0)
                                        <td><a href="{{URL::to('update-transaction/0')}}/{{$data->id}}" class="btn btn-success">Approved</a></td>
                                        @elseif($data->status == 1)
                                        <td><a href="{{URL::to('update-transaction/1')}}/{{$data->id}}" class="btn btn-danger">NotApproved</a></td>
                                        @endif
                                        <td>{{ $data->date }}</td>
                                    </tr>
                                    @endif
                                @endforeach
                              </tbody>
                        </table>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="profile" aria-labelledby="profile-tab">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                          <thead>
                            <tr>
                                <th>Sr.No.</th>                         
                                <th>Client Name</th>
                                <th>Withdrawal</th>    
                                <th>Available Balance</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            @foreach($deposit as $key => $data)                               
                                <?php 
                                    $uploadby = DB::table('users')->where('id', $data->client_id)->first(); 
                                    $withdrawal = DB::table('wallet_transaction')->where('client_id', $data->client_id)->where('status', 0)->orderBy('id', 'DESC')->first();
                                    ?>
                                    @if(isset($uploadby->name))
                                        <tr class="gradeX">                         
                                            <td>{{ ++$key }}</td>
                                            <td>{{ $uploadby->name ?? ''}}</td>  
                                            <td>{{ $data->withdrawal ?? ''}}</td><!-- 
                                            <td>{{ $data->payment_mode }}</td> -->
                                            <td>{{ $withdrawal->available_balance }}</td>
                                            @if($data->status == 0)
                                            <td><a href="{{URL::to('update-transaction/0')}}/{{$data->id}}" class="btn btn-success">Approved</a></td>
                                            @elseif($data->status == 1)
                                            <td><a href="{{URL::to('update-transaction/1')}}/{{$data->id}}" class="btn btn-danger">NotApproved</a></td>
                                            @endif
                                            <td>{{ $data->date }}</td>
                                        </tr>
                                    @endif
                                @endforeach
                          </tbody>
                        </table>
                    </div>
                </div>
                </div>
                
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->

<script type="text/javascript">
    $("#checkAll").click(function () {
        $('input:checkbox').not(this).prop('checked', this.checked);
    });
</script>
<style>
@mixin ellipsis(){
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    word-wrap: normal;
    width: 100%;
}

@mixin icon-styles(){
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

@mixin transform($transform){
  -webkit-transform: $transform;
  -moz-transform: $transform;
  -ms-transform: $transform;
  -o-transform: $transform;
  transform: $transform;
}

.wrapper {
  padding: 15px 0;
}

.bs-example-tabs .nav-tabs {
  margin-bottom: 15px;
}
</style>
<script type="text/javascript">
  (function($) {

  'use strict';

  $(document).on('show.bs.tab', '.nav-tabs-responsive [data-toggle="tab"]', function(e) {
    var $target = $(e.target);
    var $tabs = $target.closest('.nav-tabs-responsive');
    var $current = $target.closest('li');
    var $parent = $current.closest('li.dropdown');
    $current = $parent.length > 0 ? $parent : $current;
    var $next = $current.next();
    var $prev = $current.prev();
    var updateDropdownMenu = function($el, position){
      $el
        .find('.dropdown-menu')
        .removeClass('pull-xs-left pull-xs-center pull-xs-right')
        .addClass( 'pull-xs-' + position );
    };

    $tabs.find('>li').removeClass('next prev');
    $prev.addClass('prev');
    $next.addClass('next');
    
    updateDropdownMenu( $prev, 'left' );
    updateDropdownMenu( $current, 'center' );
    updateDropdownMenu( $next, 'right' );
  });

})(jQuery);
</script>
<script> 
   $(document).ready(function() { 

       $(function() { 
           $("#my_date_picker1").datepicker({}); 
       }); 

       $(function() { 
           $("#my_date_picker2").datepicker({}); 
       }); 

       $('#my_date_picker1').change(function() { 
           startDate = $(this).datepicker('getDate'); 
           $("#my_date_picker2").datepicker("option", "minDate", startDate); 
       }) 

       $('#my_date_picker2').change(function() { 
           endDate = $(this).datepicker('getDate'); 
           $("#my_date_picker1").datepicker("option", "maxDate", endDate); 
       }) 
   }) 
</script> 