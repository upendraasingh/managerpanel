<?php 
   $clientdetail = DB::table('users')->where('id', $id)->first(); 
   $clientbal = DB::table('wallet_transaction')->where('client_id', $id)->where('status','0')->orderBy('id', 'Desc')->take(1)->first(); 
     
?>
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Transaction </h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Transaction </li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                  <div class="row">
                     <!-- <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                     </div> -->
                     <?php //print_r(); die; ?>
                     <div class="col-sm-3">
                        <div class="m-b-30">
                           <label class="control-label">Name : {{$clientdetail->name}}</label>
                           <!-- <input class="form-control" type="text" value="{{$clientdetail->name}}" readonly=""> -->
                        </div>
                     </div>
                     <?php if($clientdetail->users_role !=2 ){ ?>
                     <div class="col-sm-3">
                        <div class="m-b-30">
                           <label class="control-label">Avalable Balance : $ {{$clientbal->available_balance ?? ''}}</label>
                           <!-- <input class="form-control" type="text" value="{{$clientbal->available_balance ?? ''}}" readonly=""> -->
                        </div>
                     </div>
                    <?php } ?>
                  </div>
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr.No.</th>                          
                           <th>Deposit</th>
                           <th>Withdrawal</th>    
                           <th>Available Balance</th>
                           <th>Status</th>
                           <th>Date</th>
                           <!-- <th>Action</th> -->
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($transaction as $key => $data)                       
                            <tr class="gradeX">                         
                                <td>{{ ++$key }}</td>
                                <td>@if(isset($data->deposit)) ${{ $data->deposit }} @endif</td>
                                <td>@if(isset($data->withdrawal)) ${{ $data->withdrawal ?? ''}} @endif</td><!-- 
                                    <td>{{ $data->payment_mode }}</td> -->
                                <td>${{ $data->available_balance }}</td>
                                @if($data->status == 0)
                                <td><!-- <button class="btn btn-success">Approved</button> -->Approved</td>
                                    @elseif($data->status == 1)
                                <td><!-- <button class="btn btn-success">NotApproved</button> -->NotApproved</td>
                                    @endif
                                <td>{{ $data->date }}</td>

                                <!-- <td class="actions">
                                    <a href="{{ URL::to('view-product',$data->id) }}" class="on-default edit-row"  onclick="editRecords({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View"><i class="fas fa-eye"></i></a> 
                                    &nbsp;&nbsp;&nbsp;

                                    <a href="{{ URL::to('product-edit',$data->id) }}" class="on-default edit-row"data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                                    &nbsp;&nbsp;&nbsp;

                                    <a href="{{ URL::to('delete-product',$data->id) }}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                                </td> -->
                            </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->

<script type="text/javascript">
    $("#checkAll").click(function () {
     $('input:checkbox').not(this).prop('checked', this.checked);
 });
</script>