<style type="text/css">
    .colerclass {
        color: #317eeb;
    }

    .menustyle {
        margin: 10px;
    }
</style>
<?php
// dd(url());
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Edit Ride</h4>
                <ol class="breadcrumb pull-right">
                    <li><a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="{{ url('public/images/back_arrow.jpg') }}" alt="back_arrow">Back</a></li>
                </ol>
            </div>
        </div>
        <div class="add_country_heading">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h3>Edit Ride</h3>
                </div>
            </div>
        </div>
        <form method="POST" action="{{ url('ride-management/'.$editmanager->id.'/update') }}" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <div class="row" id="example-basic">
                <div class="col-md-12">
                    <div class="card country_management">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <b>Driver's Personal Information</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Order No<font color="red">*</font></label>
                                                <input type="text" id="order_no" name="order_no" class="form-control" aria-required="true" maxlength="25" value="{{ old('order_no',(isset($editmanager) && !empty($editmanager->order_no)) ? $editmanager->order_no : '' ) }}" placeholder="Enter order_no" required="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Driver Name<font color="red">*</font></label>
                                                <select class="form-control">
                                                    <option>Select Driver</option>
                                                    @foreach($driverData as $driver)
                                                    <option value="{{$driver->id}}" {{ ( $driver->id == $editmanager->driver_id) ? 'selected' : '' }}>{{$driver->firstname}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Pickup Address1<font color="red">*</font></label>
                                                <input type="text" id="pickup_address1" name="pickup_address1" class="form-control" aria-required="true" value="{{ old('pickup_address1',(isset($editmanager) && !empty($editmanager->pickup_address1)) ? $editmanager->pickup_address1 : '' ) }}" placeholder="Enter pickup_address1" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Pickup Address2<font color="red">*</font></label>
                                                <input type="text" id="pickup_address2" name="pickup_address2" class="form-control" aria-required="true" value="{{ old('pickup_address2',(isset($editmanager) && !empty($editmanager->pickup_address2)) ? $editmanager->pickup_address2 : '' ) }}" placeholder="Enter pickup_address2" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Pickup Name<font color="red">*</font></label>
                                                <input type="text" id="pickup_name" name="pickup_name" class="form-control" aria-required="true" value="{{ old('pickup_name',(isset($editmanager) && !empty($editmanager->pickup_name)) ? $editmanager->pickup_name : '' ) }}" placeholder="Enter pickup_name" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Pickup Mobile<font color="red">*</font></label>
                                                <input type="text" id="pickup_mobile" name="pickup_mobile" class="form-control" aria-required="true" value="{{ old('pickup_mobile',(isset($editmanager) && !empty($editmanager->pickup_mobile)) ? $editmanager->pickup_mobile : '' ) }}" placeholder="Enter pickup_mobile" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <b>Documentation</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Destination Address1<font color="red">*</font></label>
                                                <input type="text" id="destination_address1" name="destination_address1" class="form-control" aria-required="true" value="{{ old('destination_address1',(isset($editmanager) && !empty($editmanager->destination_address1)) ? $editmanager->destination_address1 : '' ) }}" placeholder="Enter destination_address1" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Destination Address2<font color="red">*</font></label>
                                                <input type="text" id="destination_address2" name="destination_address2" class="form-control" aria-required="true" value="{{ old('destination_address2',(isset($editmanager) && !empty($editmanager->destination_address2)) ? $editmanager->destination_address2 : '' ) }}" placeholder="Enter destination_address2" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Destination Name<font color="red">*</font></label>
                                                <input type="text" id="destination_name" name="destination_name" class="form-control" aria-required="true" value="{{ old('destination_name',(isset($editmanager) && !empty($editmanager->destination_name)) ? $editmanager->destination_name : '' ) }}" placeholder="Enter destination_name" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Destination Mobile<font color="red">*</font></label>
                                                <input type="text" id="destination_mobile" name="destination_mobile" class="form-control" aria-required="true" value="{{ old('destination_mobile',(isset($editmanager) && !empty($editmanager->destination_mobile)) ? $editmanager->destination_mobile : '' ) }}" placeholder="Enter destination mobile" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">type<font color="red">*</font></label>
                                                <input type="text" id="type" name="type" class="form-control" aria-required="true" value="{{ old('pdate',(isset($editmanager) && !empty($editmanager->pdate)) ? $editmanager->pdate : '' ) }}" placeholder="Enter type" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <b>Vehicle</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">pdate<font color="red">*</font></label>
                                                <input type="text" id="pdate" name="pdate" class="form-control" aria-required="true" value="{{ old('pdate',(isset($editmanager) && !empty($editmanager->pdate)) ? $editmanager->pdate : '' ) }}" placeholder="Enter pdate" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Stop_address1<font color="red">*</font></label>
                                                <input type="text" id="stop_address1" name="stop_address1" class="form-control" aria-required="true" value="{{ old('stop_address1',(isset($editmanager) && !empty($editmanager->stop_address1)) ? $editmanager->stop_address1 : '' ) }}" placeholder="Enter stop address1" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Stop Address2<font color="red">*</font></label>
                                                <input type="text" id="stop_address2" name="stop_address2" class="form-control" aria-required="true" value="{{ old('stop_address2',(isset($editmanager) && !empty($editmanager->stop_address2)) ? $editmanager->stop_address2 : '' ) }}" placeholder="Enter stop address2" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Stop name<font color="red">*</font></label>
                                                <input type="text" id="stop_name" name="stop_name" class="form-control" aria-required="true" value="{{ old('stop_name',(isset($editmanager) && !empty($editmanager->stop_name)) ? $editmanager->stop_name : '' ) }}" placeholder="Enter stop name" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <b>Documentation</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Stop Mobile<font color="red">*</font></label>
                                                <input type="text" id="stop_mobile" name="stop_mobile" class="form-control" aria-required="true" value="{{ old('stop_mobile',(isset($editmanager) && !empty($editmanager->stop_mobile)) ? $editmanager->stop_mobile : '' ) }}" placeholder="Enter stop_mobile" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Price<font color="red">*</font></label>
                                                <input type="text" id="price" name="price" class="form-control" aria-required="true" value="{{ old('price',(isset($editmanager) && !empty($editmanager->price)) ? $editmanager->price : '' ) }}" placeholder="Enter price" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Drivernote<font color="red">*</font></label>
                                                <input type="text" id="drivernote" name="drivernote" class="form-control" aria-required="true" value="{{ old('drivernote',(isset($editmanager) && !empty($editmanager->drivernote)) ? $editmanager->drivernote : '' ) }}" placeholder="Enter drivernote" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <b>Vehicle</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Vehicle<font color="red">*</font></label>
                                                <select class="form-control" required="">
                                                    <option value="">Select Vehicle</option>
                                                    @foreach($vehicleData as $vehicle)
                                                    <option value="{{$vehicle->id}}" {{ ( $vehicle->id == $editmanager->vehicle_id) ? 'selected' : '' }}>{{$vehicle->vehicle_type}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Status<font color="red">*</font></label>
                                                <select class="form-control" name="status" required="">
                                                    <option value="">Select Status</option>
                                                    <option value="Completed" {{ ( $editmanager->status == 'Completed') ? 'selected' : '' }}>Completed</option>
                                                    <option value="Item pickedup" {{ ( $editmanager->status == 'Item pickedup') ? 'selected' : '' }}>Item pickedup</option>
                                                    <option value="Auto Cancelled" {{ ( $editmanager->status == 'Auto Cancelled') ? 'selected' : '' }}>Auto Cancelled</option>
                                                    <option value="Failed" {{ ( $editmanager->status == 'Failed') ? 'selected' : '' }}>Failed</option>
                                                    <option value="Cancelled" {{ ( $editmanager->status == 'Cancelled') ? 'selected' : '' }}>Cancelled</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Tip<font color="red">*</font></label>
                                                <input type="text" id="tip" name="tip" class="form-control" aria-required="true" value="{{ old('tip',(isset($editmanager) && !empty($editmanager->tip)) ? $editmanager->tip : '' ) }}" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Itemtype<font color="red">*</font></label>
                                                <input type="text" id="itemtype" name="itemtype" class="form-control" aria-required="true" value="{{ old('itemtype',(isset($editmanager) && !empty($editmanager->itemtype)) ? $editmanager->itemtype : '' ) }}" placeholder="Enter itemtype" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Coupon<font color="red">*</font></label>
                                                <input type="text" id="coupon" name="coupon" class="form-control" aria-required="true" value="{{ old('coupon',(isset($editmanager) && !empty($editmanager->coupon)) ? $editmanager->coupon : '' ) }}" placeholder="Enter coupon">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" id="submitbtn" class="btn cancel_btn">Cancel</button>
                                <button type="submit" id="submitbtn" class="btn save_btn">Save & Add</button>
                            </div>
                        </div><!-- End card-body -->
                    </div> <!-- End card -->
        </form><!-- Form End -->
    </div><!-- container -->
</div>