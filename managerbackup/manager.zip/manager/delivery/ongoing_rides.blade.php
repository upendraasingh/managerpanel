<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <!--div class="col-sm-12">
            <h4 class="pull-left page-title">Ongoing Rides</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ url('add-driver') }}" class="back_btn"><img src="{{ url('public/images/plus_icon.jpg') }}" alt="plus_icon">Add New</a></li>
            </ol>
         </div-->
      </div>
      <div class="search_part">
         <div class="row">
            <div class="col-md-7 col-sm-7">
               <!-- form class="form-horizontal">
                  <div class="form-group row">
                     <label for="inputEmail3" class="col-sm-2 control-label">Search by :</label>
                     <div class="col-sm-4">
                        <select class="form-control">
                           <option>Select Area</option>
                           <option>India</option>
                           <option>Australia</option>
                        </select>
                     </div>
                     <div class="col-sm-2">
                        <button class="search_button">Search</button>
                     </div>
                  </div>
               </form -->
            </div>

         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card service_management">
               <div class="card-body">
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap management_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <th>Trip ID</th>
                           <th>Current Status</th>
                           <th>Driver Details</th>
                           <th>Service Type</th>
                           <th>Pickup</th>
                           <th>Drop</th>
                           <!-- <th>Reason</th> -->
                           <!-- <th>Status</th> -->
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($manager as $key => $data)
                        <?php //dd($data); 
                        ?>
                        <tr class="gradeX">
                           <td>{{ $key+1 }}</td>
                           <td>{{ $data->order_no }}</td>
                           <td>{{ $data->status }}</td>
                           <td>{{ $data->firstname }}<br /> {{ $data->middlename }} <br />{{ $data->mobile }}</td>
                           <td>{{ $data->vehicle_type }}</td>
                           <td>{{ $data->pickup_address1 }} <br>{{ $data->pickup_address2 }} </td>
                           <td>{{ $data->stop_address1 }}<br>{{ $data->stop_address2 }}</td>
                           <!-- <td></td> -->
                           <td class="actions">
                              <a href="{{ URL::to('ride-management/edit-ride',$data->id)}}" class="on-default edit-row" data-toggle="tooltip" data-modal="modal-12" data-placement="top" data-original-title="edit"><i class="fa fa-edit"></i></a>
                                 &nbsp;&nbsp;&nbsp;
                              <a href="{{ URL::to('ride-management/show-ride',$data->id)}}" class="on-default edit-row" data-toggle="tooltip" data-modal="modal-12" data-placement="top" data-original-title="Eye"><i class="fa fa-bell-o"></i></a>
                           </td>
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->


<script type="text/javascript">
   $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#datatable-responsive thead tr').clone(true).appendTo('#datatable-responsive thead');
      $('#datatable-responsive thead tr:eq(1) th').each(function(i) {
         var title = $(this).text();
         $(this).html('<input type="text" placeholder=" ' + title + '" />');

         $('input', this).on('keyup change', function() {
            if (table.column(i).search() !== this.value) {
               table
                  .column(i)
                  .search(this.value)
                  .draw();
            }
         });
      });

      var table = $('#datatable-responsive').DataTable({
         orderCellsTop: true,
         fixedHeader: true
      });
   });
</script>