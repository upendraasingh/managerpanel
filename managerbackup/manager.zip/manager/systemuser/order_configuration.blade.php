<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Order Request Configuration</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="https://162.241.87.160/duradrive/public/images/back_arrow.jpg" alt="back_arrow">Back</a></li>
            </ol>
         </div>
      </div>
      <div class="add_country_heading">
         <div class="row">
            <div class="col-md-12 col-sm-12">
               <h3>Manage Order Request Configuration</h3>
            </div>
         </div>
      </div>
      <form  action="{{ URL::to('add-drivers') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card country_management">
                  <div class="card-body">
                     <div class="row"> 
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Hide Logo On SideBar<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Full Name<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Email Address<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Phone Number<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Phone Number<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                        <label class="control-label">City<font color="red">*</font></label>
                                        <select class="form-control">
                                            <option>Select City</option>
                                            <option></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Hide Logo On SideBar<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Full Name<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Email Address<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                        <label class="control-label">City<font color="red">*</font></label>
                                        <select class="form-control">
                                            <option>Select City</option>
                                            <option></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Full Name<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Email Address<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn cancel_btn">Cancel</button>
                       <button type="submit" id="submitbtn" class="btn save_btn">Save & Add</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
