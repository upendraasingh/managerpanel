   <!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css"  /> -->
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Products </h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Products </li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <?php
                  $whitelabel_id = $whitelabel_id ?? '';
                  $brand_id = $brand_id ?? '';
                  $status = $status ?? '';
                ?>
                  <!--<div class="row">
                      <div class="col-sm-6">
                        <div class="m-b-30">
                          <button type="button" class="btn btn-primary waves-effect waves-light" onclick="addRecords()" > Add <i class="md md-add-circle-outline"></i></button>
                        </div>
                     </div>
                  </div> -->
                  <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                      @if($whitelabel_id || $brand_id || $status)
                        <a href="{{ URL::to('view-product')}}">
                          <h3>
                            <i class="icon-filter icon-stack-base"></i>
                            <i class="icon-remove"></i> Filter
                          </h3>
                        </a>
                      @else
                        <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                      @endif
                    </div>
                  </div>
                  <hr>
                  @if(Session::get('userRole') == 1)
                  <form  action="{{ URL::to('filter-whitelabel') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                      <?php
                        $whitelabel = DB::table('users')->where('users_role', 2)->get(); 
                      ?>
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="id" id="whitelabel_id" class="form-control" required="">
                             <option value="">-- Select White Label --</option>
                             @foreach($whitelabel as $data)
                                 <option value="{{ $data->id }}" {{($data->id == $whitelabel_id) ? "selected" : ""}}>{{ $data->name }}</option>
                             @endforeach
                          </select>
                        </div>
                     </div>
                    
                      <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                       <a href="{{URL::to('view-product')}}" class="btn btn-primary">Refresh</a>
                     </div>
                  </div>
                  </form>
               <hr>
               @endif
              <form  action="{{ URL::to('filter_brand') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                     <?php $brand = DB::table('brand')->get();  ?>
                     <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="brand_id" id="brand_id" class="form-control" required="">
                              <option value="">-- Select Brand --</option>
                              @foreach($brand as $data)
                                <option value="{{ $data->id }}" {{($data->id == $brand_id) ? "selected" : ""}}>{{ $data->brand_name }}</option>
                              @endforeach
                          </select>
                        </div>
                     </div>
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                        @if(Session::get('userRole') == 2)
                          <a href="{{URL::to('view-product')}}" class="btn btn-primary">Refresh</a>
                        @endif
                     </div>
                  </div>
                </form>
                <hr>
                <form  action="{{ URL::to('filter_status') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                    <?php $brand = DB::table('brand')->get();  ?>
                    
                     <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="status" id="status" class="form-control" required="">
                            <option value="">-- Select Status --</option>
                              <option value="0" {{(0 == $status) ? "selected" : ""}}>Approve</option>                             
                              <option value="1" {{(1 == $status) ? "selected" : ""}}>NotApprove</option>                             
                            </select>
                        </div>
                     </div>
                    
                      <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                     </div>
                  </div>
                </form>
               <hr>
               
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           @if(session::get('userRole') == 1)
                           <!-- <th><input type="checkbox" id="checkAll"> Select All</th> -->
                           @endif
                           <th>Sr.No.</th>
                           @if(session::get('userRole') == 1)
                           <th>Created By</th>
                           @endif
                           <th>Brand</th>
                           <th>Model</th>
                           <th>Year</th>
                           <th>Price</th>
                           <th>Percentage</th>
                           <th>Status</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($productdata as $key => $data)
                        <?php 
                           $brand = DB::table('brand')->where('id', $data->brand_id)->first();
                           $uploadby = DB::table('users')->where('id', $data->upload_by)->first();
                        ?>
                        <tr class="gradeX">
                           @if(session::get('userRole') == 1)
                          <!--  <td><input type="checkbox" name=""></td> -->
                           @endif
                           <td>{{ $key+1 }}</td>
                           @if(session::get('userRole') == 1)
                           <td>{{ $uploadby->name ?? ''}}</td>
                           @endif
                           <td>{{ $brand->brand_name }}</td>
                           <td>{{ $data->model_name ?? ''}}</td>
                           <td>{{ $data->year }}</td>
                           <td><i class="fas fa-euro-sign"></i> {{ $data->price }}</td>
                           <td>{{ $data->percentage }}%</td>
                            @if(session::get('userRole')==1)
                              <td>
                                  @if($data->status == 0)  
                                    <i class="fa fa-check-square" aria-hidden="true"></i><a href="{{ URL::to('status-change', $data->id) }}" > Approved</a> | 
                                    <i class="fas fa-minus-square"></i><a href="{{ URL::to('status-change', $data->id) }}"> Not approved</a>
                                  @else
                                    <i class="fas fa-minus-square"></i><a href="{{ URL::to('status-change', $data->id) }}" > Approved</a> |
                                    <i class="fa fa-check-square" aria-hidden="true"></i><a href="{{ URL::to('status-change', $data->id) }}"> Not approved</a>                                 
                                  @endif
                              </td>
                           @else
                              <td>
                                 @if($data->status == 0)
                                    <button class="btn btn-success">Approved</button>
                                 @else
                                    <button class="btn btn-danger">Not approved</button>
                                 @endif
                              </td>
                           @endif
                          
                           <td class="actions">
                              <a href="{{ URL::to('view-product',$data->id) }}" class="on-default edit-row"  onclick="editRecords({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View"><i class="fas fa-eye"></i></a> 
                              &nbsp;&nbsp;&nbsp;
                              
                              <a href="{{ URL::to('product-edit',$data->id) }}" class="on-default edit-row"data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                              &nbsp;&nbsp;&nbsp;
                              
                              <a href="{{ URL::to('delete-product',$data->id) }}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                           </td>
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->

<script type="text/javascript">
    $("#checkAll").click(function () {
     $('input:checkbox').not(this).prop('checked', this.checked);
 });
</script>
<!-- White label -->
<script type="text/javascript">
   function whitelabel_filter()
   {
     var id = $('#whitelabel_id').val();

     //alert(id);

      $.ajaxSetup({
         headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         }
      });

      $.ajax({   
         url:"{{url('filter-whitelabel/')}}"+'/'+id,
         method:"POST", 
         contentType : 'application/json',
         success: function( data ) 
         {
            
         }
      });
      
   }
</script>

<!-- Product approve or not approve jquery  -->
<script type="text/javascript">
  function changestauts(){
    var id = $('#activeid').val();
    alert(id);
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({   
      url:"{{url('status-change/')}}"+'/'+id,
      method:"POST", 
      contentType : 'application/json',
      success: function( data ) 
      {
        location.reload();
      }
    });
  }
</script>

