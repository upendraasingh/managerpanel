
<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Edit Product</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Edit Product</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-product') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
      @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                      <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <a href="{{URL::to('view-product')}}" class="btn btn-primary waves-effect waves-light" ><i class="fa fa-arrow-left"></i>  Go Back</a>
                           </div>
                        </div>
                     </div>
                     <hr>
                     <div class="row">
                        <input type="hidden" name="edit_id" value="{{ $edit_product->id ?? ''}}">
                        <div class="col-md-6">
                            <div class="form-group">  
                              <label class="control-label">Brand Name : <font color="red">*</font></label>
                              <select name="brand_id" id="brand_id" class="form-control" required="">
                                 <option> -- Choose Brand -- </option>
                                 <?php $Brands = DB::table('brand')->get(); ?>
                                 @if($Brands!='')
                                 @foreach($Brands as $data)
                                 <option value="{{ $data->id }}" {{($data->id == $edit_product->brand_id) ? "selected" : ""}}>{{ $data->brand_name }}</option>
                                 @endforeach
                                 @endif
                              </select>
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Model name : <font color="red">*</font></label>
                              <input type="text" name="model_name" id="model_name" value="{{ $edit_product->model_name ?? ''}}" class="form-control" required="">
                            
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Id No : </label>
                              <input type="text" class="form-control" name="id_no" value="{{ $edit_product->id_no ?? ''}}" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Year : <font color="red">*</font></label>
                              <input type="text" id="dateyeser" readonly="" name="year" value="{{ $edit_product->year ?? ''}}" class="date-own form-control" required=""> 
                             
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Percentage : <font color="red">*</font></label>
                              <input type="text" id="percentage" name="percentage" class="form-control" value="{{ $edit_product->percentage ?? ''}}" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="3"> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Price : <font color="red">*</font></label>
                              <input type="text" id="price" name="price" class="form-control" value="{{ $edit_product->price ?? ''}}" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="10"> 
                           </div>
                        </div>                       
                        <div class="col-md-6 field_wrapper">
                          @php $features = explode(",", $edit_product->features) @endphp
                          <div>
                            <label class="control-label">Features : <font color="red">*</font></label>
                            @if($features!='')
                            @foreach($features as $data)
                              <input type="text" class="form-control" name="features[]" value="{{ $data}}"  /> <br>
                            @endforeach      
                            @endif
                          </div>
                        </div>
                        <div class="col-md-12">
                           <div class="form-group">  
                              <label class="control-label">Description : <font color="red">*</font></label>
                              <textarea class="form-control" name="description" id="descriptions" rows="4" required="">{{ $edit_product->description ?? ''}}</textarea>
                           </div>
                        </div>
                        <div class="col-md-12">
                          <div class="form-group"> 
                            <label class="control-label">Product Image : <font color="red">*</font></label>
                            <br/>
                            <?php $producimage = DB::table('product_gallery')->where('product_id', $edit_product->id)->get(); ?>
                            @if($producimage!='')
                            @foreach($producimage as $img)
                            <div class="product_images">
                              <img style="border: 1px solid #e2d8d8;" src="{{ URL::asset('/public/product_image/') }}/{{ $img->image }}" width="100px" height="100px">

                              <a href="#" onclick="editRecords({{$img->id}})" class="on-default edit edit-row"data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a>

                              <a href="{{ URL::to('product-image-delete', $img->id) }}" class="on-default delete remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fa fa-times" aria-hidden="true"></i></a>
                              </div>
                            @endforeach
                            @endif
                            <div class="add_more_btn">
                            <a href="#" onclick="addrecord({{$img->product_id ?? ''}})" class="btn btn-primary on-default edit-row"data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit">Add More </a>
                            </div>
                          </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Save</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>


    <!---Edit Product image MODEL CALL--->
<div id="image-edit-model" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Image Edit</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form  action="{{ url('edit-product-image') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="image_id" id="ids">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <p class="control-label"><b>Image :</b> <font color="red">*</font></p>
                    <input  type="file" id="image" name="image" class="form-control" required="" aria-required="true" accept="image/x-png,image/gif,image/jpeg"> 
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                 <button type="submit" id="submitbtn" class="btn btn-primary">Update</button> 
                 <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button> 
              </div>
            </div>
         </form>
      </div>
   </div>
</div>
<!-- /.modal eND -->
<!---add Product image MODEL CALL--->
<div id="image-add-model" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Image Edit</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form  action="{{ url('add-product-image') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="product_id" id="productid" value="">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <p class="control-label"><b>Image :</b> <font color="red">*</font></p>
                    <input  type="file" id="image" name="image" class="form-control" required="" aria-required="true" accept="image/x-png,image/gif,image/jpeg"> 
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                 <button type="submit" id="submitbtn" class="btn btn-primary">Save</button> 
                 <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button> 
              </div>
            </div>
         </form>
      </div>
   </div>
</div>
<!-- /.modal eND -->
      
<!-- Script for model select according to brand  -->
<script type="text/javascript">
   $('#brand_id').change(function()
   {
      var barndId = $(this).val();
      if(barndId)
      {
         $.ajax({
            type:"GET",
            url:"{{url('get-model/')}}"+'/'+barndId, 
            success:function(res)
            {               
               if(res){
                  $("#model_id").empty();
                  $("#model_id").append('<option>-- Choose Model --</option>');
                  $.each(res,function(key,value){
                     $("#model_id").append('<option value="'+value.id+'">'+value.category_name+'</option>');
                  });
                }
               else{
                  $("#model_id").empty();
               }
            }
         });
      }
      else{
         $("#model_id").empty();
      } 
   });
</script>
<!-- add more features script -->
<script type="text/javascript">
   $(document).ready(function(){
       var maxField = 10; //Input fields increment limitation
       var addButton = $('.add_button'); //Add button selector
       var wrapper = $('.field_wrapper'); //Input field wrapper
       var fieldHTML = '<div><input type="text" class="form-control" name="features[]" value=""/><a href="javascript:void(0);" class="remove_button btn btn-danger">Remove</a></div>'; //New input field html 
       var x = 1; //Initial field counter is 1
       
       //Once add button is clicked
       $(addButton).click(function(){
           //Check maximum number of input fields
           if(x < maxField){ 
               x++; //Increment field counter
               $(wrapper).append(fieldHTML); //Add field html
           }
       });
       
       //Once remove button is clicked
       $(wrapper).on('click', '.remove_button', function(e){
           e.preventDefault();
           $(this).parent('div').remove(); //Remove field html
           x--; //Decrement field counter
       });
   });
</script>
<!-- Script for select onlu yesr -->
<script type="text/javascript">
  $('.date-own').datepicker({
     minViewMode: 2,
     format: 'yyyy'
   });
</script>
<!-- model call script  -->
<script type="text/javascript">
  function editRecords(id) { 
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    }); 
    $.ajax({   
      url:"{{url('product-image-edit/')}}"+'/'+id,
      method:"POST", 
      contentType : 'application/json',
      success: function( data ) 
      {
        $('#image-edit-model').modal('show');   
        document.getElementById("ids").value = data.id; 
      }
    });
  }
</script>
<script type="text/javascript">
  function addrecord(product_id){
    document.getElementById("FormValidation").reset();
    document.getElementById("productid").value = product_id;
    $('#image-add-model').modal('show');
  }
</script>