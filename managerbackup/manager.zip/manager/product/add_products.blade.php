<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" rel="stylesheet"/>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/> -->



<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link type="text/css" rel="stylesheet" href="http://example.com/image-uploader.min.css">
<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Add Product</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Add Product</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-product') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
      @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                    <div class="row">
                      @if(session::get('userRole') == 1)
                        <input type="hidden" name="status" value="0">
                      @else
                        <input type="hidden" name="status" value="1">
                      @endif
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Brand Name : <font color="red">*</font></label>
                              <select name="brand_id" id="brand_id" class="form-control" required="">
                                 <option value=""> -- Choose Brand -- </option>
                                 <?php $Brands = DB::table('brand')->get(); ?>
                                 @foreach($Brands as $data)
                                 <option value="{{ $data->id }}">{{ $data->brand_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Model name : <font color="red">*</font></label>
                              <input type="text" name="model_name" id="model_name" class="form-control" required="">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Id No : <font color="red">*</font></label>
                              <input type="text" id="id_no" name="id_no" class="form-control" required="" aria-required="true" > 
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Percentage(%) : <font color="red">*</font></label>
                              <input type="text" id="percentage" name="percentage" class="form-control" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="3"> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Price : <font color="red">*</font></label>
                              <input type="text" id="price" name="price" class="form-control" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="10"> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Year : <font color="red">*</font></label>
                              <input type="text" id="dateyeser" readonly="" name="year" class="date-own form-control" required=""> 
                             
                           </div>
                        </div>
                        
                        <div class="col-md-6 field_wrapper">
                           <div>
                              <label class="control-label">Features : <font color="red">*</font></label>
                              <input type="text" class="form-control" name="features[]" value=""/>
                              <a href="javascript:void(0);" class="add_button btn btn-success" title="Add field">Add</a>
                           </div>
                        </div>

                        <!-- <div class="col-md-6">
                          <div class="form-group">
                              <p class="control-label"><b>Status</b> <font color="red">*</font></p>
                              <div class="radio radio-info form-check-inline">
                                <input type="radio" id="active" value="0" name="status" checked="">
                                <label for="inlineRadio1"> Show everyone </label>
                              </div>
                              <div class="radio radio-info form-check-inline">
                                <input type="radio" id="inactive" value="1" name="status">
                                <label for="inlineRadio1"> Show only me </label>
                              </div>
                          </div>
                        </div> -->
                        <div class="col-md-12">
                           <div class="form-group">  
                              <label class="control-label">Description : <font color="red">*</font></label>
                              <textarea class="form-control" name="description" id="descriptions" rows="4" required=""></textarea>
                           </div>
                        </div>

                        <div class="col-md-12">
                          <div class="form-group"> 
                            <label class="control-label">Product Image : <font color="red">*</font></label>
                            <input class="form-control" type="file" id="files"  name="image[]" multiple="" required="" accept="image/x-png,image/gif,image/jpeg">
                          </div>
                        </div>
                      </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Save</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
          </div><!-- container -->
        </div>
      
<script type="text/javascript" src="http://example.com/jquery.min.js"></script>
<script type="text/javascript" src="http://example.com/image-uploader.min.js"></script>

<script type="text/javascript">
  $('.input-images').imageUploader();
</script>
<!-- Script for model select according to brand  -->
<script type="text/javascript">
   $('#brand_id').change(function(){
      var barndId = $(this).val();
      if(barndId){
        $.ajax({
          type:"GET",
          url:"{{url('get-model/')}}"+'/'+barndId, 
          success:function(res)
          {               
            if(res){
              $("#model_id").empty();
              $("#model_id").append('<option>-- Choose Model --</option>');
              $.each(res,function(key,value){
                 $("#model_id").append('<option value="'+value.id+'">'+value.category_name+'</option>');
              });
            }else{
              $("#model_id").empty();
            }
          }
        });
      }
      else{
        $("#model_id").empty();
      } 
   });
</script>
<!-- add more features script -->
<script type="text/javascript">
    $(document).ready(function(){
      var maxField = 10; //Input fields increment limitation
      var addButton = $('.add_button'); //Add button selector
      var wrapper = $('.field_wrapper'); //Input field wrapper
       var fieldHTML = '<div><input type="text" class="form-control" name="features[]" value=""/><a href="javascript:void(0);" class="remove_button btn btn-danger">Remove</a></div>'; //New input field html 
       var x = 1; 
        $(addButton).click(function(){
          if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
          }
        });
       
     //Once remove button is clicked
      $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
      });
   });
</script>

<script type="text/javascript">
  $(document).ready(function() {
  if (window.File && window.FileList && window.FileReader) {
    $("#files").on("change", function(e) {
      var files = e.target.files,
        filesLength = files.length;
      for (var i = 0; i < filesLength; i++) {
        var f = files[i]
        var fileReader = new FileReader();
        fileReader.onload = (function(e) {
          var file = e.target;
          $("<div class=\"col-md-3 pip\">" +
            "<img class=\"imageThumb\" width=\"100px\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
            "<br/><button class=\"remove\">Remove image</button>" +
            "</div>").insertAfter("#files");          

          $(".remove").click(function(e){
            e.preventDefault();
            $(this).parent(".pip").remove();
            $('#files').val("");
          });


          $(wrapper).on('click', '.remove_button', function(e){
           e.preventDefault();
           $(this).parent('div').remove(); //Remove field html
           x--; //Decrement field counter
       });
                    
        });
        fileReader.readAsDataURL(f);
      }
    });
  } else {
    alert("Your browser doesn't support to File API")
  }
});
</script>
 <script type="text/javascript">
      $('.date-own').datepicker({
         minViewMode: 2,
         format: 'yyyy'
       });
     </script>