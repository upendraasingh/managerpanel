<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">View Product</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">View Product</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-product') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
      @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                     </div>
                     <hr>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Brand Name : </label>
                                <?php $Brands = DB::table('brand')->where('id', $view_product->brand_id)->first(); ?>
                                <input class="form-control" type="text" value="{{ $Brands->brand_name }}" readonly="">
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Model Name : </label>
                                
                                <input class="form-control" type="text" value="{{ $view_product->model_name }}" readonly="">
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Id No : </label>
                              <input type="text" class="form-control" value="{{ $view_product->id_no}}" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Year : </label>
                              <input type="text" id="year" name="year" class="form-control" value="{{ $view_product->year}}" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Percentage : </label>
                              <input type="text" id="percentage" name="percentage" class="form-control" value="{{ $view_product->percentage }}" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Price : </label>
                              <input type="text" id="price" name="price" class="form-control" value="{{ $view_product->price }}" readonly=""> 
                           </div>
                        </div>
                       
                        <div class="col-md-6 field_wrapper">
                          @php $features = explode(",", $view_product->features) @endphp

                          <div>
                            <label class="control-label">Features : </label>
                            @foreach($features as $data)
                              <input type="text" class="form-control" name="features[]" value="{{ $data}}" readonly="" /> <br>
                            @endforeach
                                                        
                          </div>
                        </div>
                        <div class="col-md-12">
                           <div class="form-group">  
                              <label class="control-label">Description : </label>
                              <textarea class="form-control" name="description" id="descriptions" rows="4" readonly="">{{ $view_product->description }}</textarea>
                           </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group"> 
                              <label class="control-label">Activity Image : </label>
                              <?php $producimage = DB::table('product_gallery')->where('product_id', $view_product->id)->get(); ?>
                              @foreach($producimage as $img)
                                <img src="{{ URL::asset('/public/product_image/') }}/{{ $img->image }}" width="100px" height="100px"> 
                              @endforeach
                          </div>
                        </div>
                     </div>                    
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
      
<!-- Script for model select according to brand  -->
<script type="text/javascript">
   $('#brand_id').change(function()
   {
      var barndId = $(this).val();
      if(barndId)
      {
         $.ajax({
            type:"GET",
            url:"{{url('get-model/')}}"+'/'+barndId, 
            success:function(res)
            {               
               if(res){
                  $("#model_id").empty();
                  $("#model_id").append('<option>-- Choose Model --</option>');
                  $.each(res,function(key,value){
                     $("#model_id").append('<option value="'+value.id+'">'+value.category_name+'</option>');
                  });
                }
               else{
                  $("#model_id").empty();
               }
            }
         });
      }
      else{
         $("#model_id").empty();
      } 
   });
</script>

<!-- add more features script -->
<script type="text/javascript">
   $(document).ready(function(){
       var maxField = 10; //Input fields increment limitation
       var addButton = $('.add_button'); //Add button selector
       var wrapper = $('.field_wrapper'); //Input field wrapper
       var fieldHTML = '<div><input type="text" class="form-control" name="features[]" value=""/><a href="javascript:void(0);" class="remove_button btn btn-danger">Remove</a></div>'; //New input field html 
       var x = 1; //Initial field counter is 1
       
       //Once add button is clicked
       $(addButton).click(function(){
           //Check maximum number of input fields
           if(x < maxField){ 
               x++; //Increment field counter
               $(wrapper).append(fieldHTML); //Add field html
           }
       });
       
       //Once remove button is clicked
       $(wrapper).on('click', '.remove_button', function(e){
           e.preventDefault();
           $(this).parent('div').remove(); //Remove field html
           x--; //Decrement field counter
       });
   });
</script>

