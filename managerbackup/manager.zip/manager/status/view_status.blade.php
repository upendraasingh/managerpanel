<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">view Model</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">view Model</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-brand')}}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm-4">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                     </div>
                      <?php $brand = DB::table('brand')->where('id', $modeldata->brand_id)->first(); ?>
                     <div class="row">
                        <div class="col-md-4">
                           <div class="form-group">  
                              <label class="control-label">Brand name : <font color="red">*</font></label>
                              <input  type="text" class="form-control" value="{{ $brand->brand_name ?? '' }}" readonly=""> 
                           </div>
                        </div>
                         <div class="col-md-4">
                           <div class="form-group">  
                              <label class="control-label">Model name : <font color="red">*</font></label>
                              <input  type="text" class="form-control" value="{{ $modeldata->category_name ?? '' }}" readonly=""> 
                           </div>
                        </div>
                       
                        <div class="col-md-4">
                           <div class="form-group">
                              <p class="control-label"><b>Status : </b> <font color="red">*</font></p>
                              @if($modeldata->status == 0)
                              <input type="text" class="form-control" value="Active" readonly="">
                              @else
                              <input type="text" class="form-control" value="InActive" readonly="">
                              @endif
                           </div>
                        </div>
                        </div>                        
                     </div>   
               </div><!-- End card-body -->
            </div> <!-- End card -->
         </form><!-- Form End -->
      </div><!-- container -->
   </div>
