
<style type="text/css">
    .colerclass {
        color: #317eeb;
    }

    .menustyle {
        margin: 10px;
    }
</style>
<div class="content">
    <div class="driver_details_pg fw">
        <div class="topHeading_sec fw">
            <h4>Driver Details <a href="#">
                    <span class="rightbtn_sec">
                        <a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="{{ url('public/images/back_arrow.jpg') }}" alt="back_arrow">Back</a>
                    </span>
                </a>
            </h4>
        </div>
        <?php 
         // dd($driveuserData);
        ?>
        <div class="raider_profile fw">
            <div class="col-grid-2">
                <div class="raider_profileFirst">
                    <div class="img_crl_icon">
                         <?php if (!empty($driveuserData->profilephoto_url)) { ?>
                        <img src="{{ url('public/uploads/profilephoto/'.$driveuserData->profilephoto_url) }}" alt="icon">
                        <?php } else { ?>
                                 <img src="{{ url('public/images/user.jpg') }}" >
                              <?php } ?>
                    </div>
                    <div class="raider_name_detail fw">
                        <div class="text_pra_wapper fw">
                            <p>{{ @$driveuserData->firstname }}</p>
                            <p>{{ @$driveuserData->mobile }}</p>
                            <p>{{ @$driveuserData->email }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p>
                        <span class="fw">Type of Rider</span>
                        Retail
                    </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p>
                        <span class="fw">Referral Code</span>
                        ETD5M
                    </p>
                    <div class="text_pra_bottom">
                        <p>
                            <span class="fw">Register Date</span>
                            {{ date('d/m/Y g:i A', strtotime(@$driveuserData->created_at)) }}
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p>
                        <span class="fw">Register Platform</span>
                        App
                    </p>
                    <div class="text_pra_bottom">
                        <p>
                            <span class="fw">Commission type</span>
                            Commission Based
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p>
                        <span class="fw">Wallet</span>
                        0
                    </p>
                </div>
            </div>
        </div>
        <div class="raider_profile no-pad fw">
            <h3>Documentation</h3>
            <div class="col-grid-2">
                <div class="raider_name_detail fw">
                    <div class="text_pra_wapper fw">
                        <p><span>Document Type</span> Driving License</p>
                    </div>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p><span>Document Expiration</span> {{ date('d/m', strtotime(@$driveuserData->created_at)) }} </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p><span>Status</span> {{ @$driveuserData->docs_status }} </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p>
                        <span class="fw">Document Upload Date</span>
                        {{ date('d/m', strtotime(@$driveuserData->updated_at)) }}
                    </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <div class="laicenc_img">
                        <img src="{{ url('public/uploads/frontlicensephoto/'.@$driveuserData->frontlicensephoto) }}" alt="img">
                    </div>
                </div>
            </div>
        </div>
        <div class="raider_profile no-pad fw">
            <h3>Vehicle</h3>
            <div class="col-grid-2">
                <div class="raider_name_detail fw">
                    <div class="text_pra_wapper fw">
                        <p><span>Vehicle Type</span> {{ @$driveuserData->vehicle_type }}</p>
                    </div>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p><span>Service Type</span> {{ @$driveuserData->vehicle_ser_type }} </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="laicenc_img bike_img">
                    <img src="{{ url('public/uploads/vehicle_images/'.@$driveuserData->vehicle_image) }}" alt="img">
                </div>
            </div>
            <div class="col-grid-2">
                <div class="laicenc_img bike_img">
                    <img src="{{ url('public/uploads/vehicle_plate_image/'.@$driveuserData->vehicle_plate_image) }}" alt="img">
                </div>
            </div>
            <div class="col-grid-2">

            </div>
        </div>
        <div class="raider_profile no-pad fw">
            <h3>Vehicle Documentation</h3>
            <div class="col-grid-2">
                <div class="raider_name_detail fw">
                    <div class="text_pra_wapper fw">
                        <p><span>Document Type</span> Registration Certificate</p>
                    </div>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p><span>Document Expiration</span> {{ date('d/m', strtotime(@$driveuserData->docsExpire)) }} </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper">
                    <p><span>Status</span> Valid </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="text_pra_wapper"> 
                    <p><span>Document Upload Date</span> {{ date('d/m/Y', strtotime(@$driveuserData->veh_doc_upload_at)) }} </p>
                </div>
            </div>
            <div class="col-grid-2">
                <div class="laicenc_img bike_img">
                    <img src="{{ url('public/uploads/veh_doc_image/'.@$driveuserData->veh_doc_image) }}" alt="img">
                </div>
            </div>
        </div>
        <div class="notify_driver_sec fw">
            <a href="#" class="notify_driver_btn ">Notify Driver</a>
        </div>
    </div>
</div>