<style type="text/css">
    .colerclass {
        color: #317eeb;
    }

    .menustyle {
        margin: 10px;
    }
</style>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Add Driver</h4>
                <ol class="breadcrumb pull-right">
                    <li><a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="{{ url('public/images/back_arrow.jpg') }}" alt="back_arrow">Back</a></li>
                </ol>
            </div>
        </div>
        <div class="add_country_heading">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h3>Add Driver</h3>
                </div>
            </div>
        </div>
        <form action="{{ URL::to('manager-add-drivers') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <div class="row" id="example-basic">
                <div class="col-md-12">
                    <div class="card country_management">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <b>Driver's Personal Information</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Rider Photo<font color="red">*</font></label>
                                                <input type="file" id="profilephoto_url" name="profilephoto_url" class="form-control" aria-required="true"  placeholder="Enter ISD code of the country" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Full Name<font color="red">*</font></label>
                                                <input type="text" id="firstname" name="firstname" class="form-control" aria-required="true" maxlength="25" placeholder="Enter first name" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Email Address<font color="red">*</font></label>
                                                <input type="email" id="email" name="email" class="form-control" aria-required="true" maxlength="25" placeholder="Enter email" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Phone Number<font color="red">*</font></label>
                                                <input type="text" id="mobile" name="mobile" class="form-control" aria-required="true" maxlength="15" placeholder="Enter mobile" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <?php $Country = DB::table('city')->get(); ?>
                                                <label class="control-label">City<font color="red">*</font></label>
                                                <input type="text" id="city" name="city" class="form-control" aria-required="true" maxlength="25" placeholder="Enter city" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Address<font color="red">*</font></label>
                                                <input type="text" id="address" name="address" class="form-control" aria-required="true" maxlength="25" placeholder="Enter Address" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="col-md-12">
                                    <b>Driver Documentation</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <?php
                                                $Country = DB::table('document')
                                                    ->groupBy('name')
                                                    ->get(); ?>
                                                <label class="control-label">Document Type<font color="red">*</font></label>
                                                <select class="form-control" name="document_type">
                                                    <option value="">Select Document Type</option>
                                                    @foreach($Country as $data)
                                                    <option value="{{ $data->name }}">{{ $data->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">DocumentExpiration<font color="red">*</font></label>
                                                <input type="date" id="docsExpire" name="docsExpire" class="form-control" aria-required="true"  placeholder="Enter ISD code of the country" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Document File<font color="red">*</font></label>
                                                <input type="file" id="document_file" name="document_file" class="form-control" aria-required="true" required="">
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Licensce Front<font color="red">*</font></label>
                                                <input type="file" id="frontlicensephoto" name="frontlicensephoto" class="form-control" aria-required="true" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Status<font color="red">*</font></label>
                                                <select class="form-control" name="docs_status">
                                                    <option>Select Status</option>
                                                    <option value="valid">Valid</option>
                                                    <option value="invalid">Invalid</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Document Upload Date<font color="red">*</font></label>
                                                <input type="date" id="docs_upload_date" name="docs_upload_date" class="form-control" aria-required="true"  placeholder="Enter docs upload date" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <hr>

                                <div class="col-md-12">
                                    <b>Driver Vehicle</b><br><br><br>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <?php
                                                $vehicalType = DB::table('vehicle_type')
                                                ->groupBy('v_type')
                                                ->get();
                                                ?>
                                                <label class="control-label">Vehicle Type<font color="red">*</font></label>
                                                <select class="form-control" name="vehicle_type">
                                                    <option value="">Select Vehicle Type</option>
                                                    @foreach($vehicalType as $data)
                                                    <option value="{{ $data->v_type }}">{{ $data->v_type }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Vehicle Photo<font color="red">*</font></label>
                                                <input type="file" id="vehicle_image" name="vehicle_image" class="form-control" aria-required="true"  placeholder="Enter ISD code of the country" required="">
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Vehicle Number Plate Photo<font color="red">*</font></label>
                                                <input type="file" id="vehicle_plate_image" name="vehicle_plate_image" class="form-control" aria-required="true"  placeholder="Enter ISD code of the country" required="">
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Vehicle doc Image<font color="red">*</font></label>
                                                <input type="file" id="veh_doc_image" name="veh_doc_image" class="form-control" aria-required="true"  placeholder="Enter ISD code of the country" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <?php $country = DB::table('document')->groupBy('name')->get(); ?>
                                                <label class="control-label">Document Type<font color="red">*</font></label>
                                                <select class="form-control" name="veh_doc_type">
                                                    <option value="">Select Document Type</option>
                                                    @foreach($country as $data)
                                                    <option value="{{ $data->name }}">{{ $data->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <?php
                                                $country = DB::table('dura_services_type')->get();
                                                ?>
                                                <label class="control-label">Document Type<font color="red">*</font></label>
                                                <select class="form-control" name="vehicle_ser_type">
                                                    <option value="">Select Document Type</option>
                                                    @foreach($country as $data)
                                                    <option value="{{ $data->service_name }}">{{ $data->service_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Document Expiration<font color="red">*</font></label>
                                                <input type="date" id="veh_doc_expire" name="veh_doc_expire" class="form-control" aria-required="true"  placeholder="Enter document expiration" required="">
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Document Upload Date<font color="red">*</font></label>
                                                <input type="date" id="veh_doc_upload_at" name="veh_doc_upload_at" class="form-control" aria-required="true"  placeholder="Enter docs upload date" required="">
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label class="control-label">Status<font color="red">*</font></label>
                                                <select class="form-control" name="veh_doc_status">
                                                    <option>Select Status</option>
                                                    <option value="valid">Valid</option>
                                                    <option value="invalid">Invalid</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" id="submitbtn" class="btn cancel_btn">Cancel</button>
                                <button type="submit" id="submitbtn" class="btn save_btn">Save & Add</button>
                            </div>
                        </div>
                    </div>
        </form>
    </div>
</div>