<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">All Driver</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ url('manager-add-driver') }}" class="back_btn"><img src="{{ url('public/images/plus_icon.jpg') }}" alt="plus_icon">Add New</a></li>
            </ol>
         </div>
      </div>
      <div class="search_part">
         <div class="row">
            <!--<div class="col-md-7 col-sm-7">
               <form class="form-horizontal">
                  <div class="form-group row">
                     <label for="inputEmail3" class="col-sm-2 control-label">Search by :</label>
                     <div class="col-sm-4">
                        <select class="form-control">
                           <option>Select Area</option>
                           <option>India</option>
                           <option>Australia</option>
                        </select>
                     </div>
                     <div class="col-sm-2">
                        <button class="search_button">Search</button>
                     </div>
                  </div>
               </form>
            </div>-->
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card service_management">
               <div class="card-body">
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap management_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <!--<th>Id Number</th>-->
                           <th>Area</th>
                           <th>Driver Name</th>
                           <th>Mobile No</th>
                           <th>Email Address</th>
                           <!--<th>Vehicle No</th>-->
                           <th>Register Date</th>
                           <th>Status</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($manager as $key => $data)
                        <?php  
                        // dd($data); 
                        ?>
                        <tr class="gradeX">
                        <td>{{ $key+1 }}</td>
                        <td>{{ $data->city}}</td>
                        <td>{{ $data->firstname}} {{ $data->middlename}} </td>
                        <td>{{ $data->mobile}}</td>
                        <td>{{ $data->email}}</td>
                        <!--<td>Referral Code</td>-->
                        <td>{{ date('Y-m-d', strtotime($data->updated_at)) }}</td>
                        <td>
                            @if($data->isactive === 1)
                            <p class="mb-0">
                                <span class="badge badge-success">Active</span>
                            </p>
                            @else
                            <p class="mb-0">
                                <span class="badge badge-danger">Inactive</span>
                            </p>
                            @endif
                        </td>
                        <td class="actions">
                        <a href="{{ URL::to('manager-edit-driver',$data->id)}}" class="on-default edit-row" data-toggle="tooltip" data-modal="modal-12" data-placement="top" data-original-title="edit"><i class="fa fa-edit"></i></a>
                        &nbsp;&nbsp;&nbsp;
                        <a href="" class="on-default edit-row" data-toggle="tooltip" data-modal="modal-12" data-placement="top" data-original-title="delete"><i class="fa fa-trash"></i></a>
                        <!-- &nbsp;&nbsp;&nbsp;
                        <a href="{{ URL::to('edit-country',$data->id)}}" class="on-default edit-row" data-toggle="tooltip" data-modal="modal-12" data-placement="top" data-original-title="Eye"><i class="fa fa-sign-out-alt"></i></a>  -->
                        </td>
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->


<script type="text/javascript">
   $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#datatable-responsive thead tr').clone(true).appendTo('#datatable-responsive thead');
      $('#datatable-responsive thead tr:eq(1) th').each(function(i) {
         var title = $(this).text();
         $(this).html('<input type="text" placeholder=" ' + title + '" />');
         $('input', this).on('keyup change', function() {
            if (table.column(i).search() !== this.value) {
               table
                  .column(i)
                  .search(this.value)
                  .draw();
            }
         });
      });

      var table = $('#datatable-responsive').DataTable({
         orderCellsTop: true,
         fixedHeader: true
      });
   });
</script>