<?php 
    use App\User;
?>
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Document</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Document</li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                  @if(Session::get('userRole') == 1)
                  <form style="display:none;"  action="{{ URL::to('filter-clients') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                     @csrf
                     <?php 
                        $whitelabel = DB::table('users')->where('users_role', 2)->get();
                        $filterid = $filterid ?? '';
                     ?>
                     <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            @if($filterid!='')
                                <a href="{{ URL::to('view-client')}}">
                                    <h3>
                                        <i class="icon-filter icon-stack-base"></i>
                                        <i class="icon-remove"></i> Filter
                                    </h3>
                                </a>
                            @else
                              <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                            @endif
                        </div>
                        
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="form-group">  
                                <select name="id" id="whitelabel_id" onchange="whitelabel_filter()" class="form-control">
                                    <option value="">-- Select White Label --</option>
                                    @foreach($whitelabel as $data)
                                        <option value="{{ $data->id }}" {{($data->id == $filterid) ? "selected" : ""}}>{{ $data->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                            <a href="{{URL::to('view-client')}}" class="btn btn-primary">Refresh</a>
                        </div>                       
                     </div>
                  </form>
                   @endif
                  <table id="datatable-responsives" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>                            
                            <th>Utility Bill Image</th>
                            <th>Passport Image</th>
                            <th>Bank Account Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($document as $key => $data)
                        <tr class="gradeX"> 
                            <form style="display:none;"  action="{{ URL::to('admin-update-docuemnt') }}/{{ $data->id }}" method="POST" id="FormValidation" enctype="multipart/form-data">   
                            @csrf                        
                                <td>                 
                                    @if($data->bill!="")
                                        <img src="{{URL('/')}}/public/user_document/{{ $data->bill }}" style="height: 235px;width: 296px;">
                                    @else
                                        <img src="{{URL('/')}}/public/user_document/no_image.jpg" style="height: 235px;width: 296px;">
                                    @endif
                                    <br><br>
                                    <input type="file" name="bill" id="bill">
                                    @if($data->bill!="")
                                    <a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#myModalbill">View Image</a>
                                    @endif
                                </td>
                                                         
                                <td>
                                    @if($data->passport!="")
                                        <img src="{{URL('/')}}/public/user_document/{{ $data->passport }}" style="height: 235px;width: 296px;">
                                    @else
                                        <img src="{{URL('/')}}/public/user_document/no_image.jpg" style="height: 235px;width: 296px;">
                                    @endif
                                    <br><br>
                                    <input type="file" name="passport" id="passport">
                                    @if($data->passport!="")
                                    <a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#myModalbill">View Image</a>
                                    @endif
                                </td>
                                <td>
                                    @if($data->bank!="")
                                        <img src="{{URL('/')}}/public/user_document/{{ $data->bank }}" style="height: 235px;width: 296px;">
                                    @else
                                        <img src="{{URL('/')}}/public/user_document/no_image.jpg" style="height: 235px;width: 296px;">
                                    @endif
                                    <br><br>
                                    <input type="file" name="bank" id="bank">
                                    @if($data->bank!="")
                                    <a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#myModalbill">View Image</a>
                                    @endif
                                    <br><br><br>
                                    <button type="submit" style="background-color: #413A18;color: #ffffff;font-size: 16px;height: 55px;width: 90%;border-radius: 5px;" class="btn big_btn modal_btn btn-block text-left">Upload Documents</button>                                   
                                </td>                                
                            </form>
                        </tr>
                        @endforeach
                        </tbody>
                    </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->
<div id="myModalbill" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-md">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Image</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
            <div class="modal-body">
               <div class="row">
                  <img src="{{URL('/')}}/public/user_document/{{ $data->bill }}" style="height: 300px;width: 458px;">
               </div>
            </div>
      </div>
   </div>
</div>
<div id="myModalpassport" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-md">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Image</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
            <div class="modal-body">
               <div class="row">
                  <img src="{{URL('/')}}/public/user_document/{{ $data->passport }}" style="height: 300px;width: 458px;">
               </div>
            </div>
      </div>
   </div>
</div>
<div id="myModalbank" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-md">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Image</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
            <div class="modal-body">
               <div class="row">
                  <img src="{{URL('/')}}/public/user_document/{{ $data->bill }}" style="height: 300px;width: 458px;">
               </div>
            </div>
      </div>
   </div>
</div>
<script type="text/javascript">
    function myFunction2() {
        var x = document.getElementById("new_password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    function myFunction2() {
        var x = document.getElementById("new_password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    function myFunction2() {
        var x = document.getElementById("new_password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>