<?php 
    use App\User;
?>
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Clients</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Clients </li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                  <div class="row">
                     <div class="col-sm-6">
                        <div class="m-b-30">
                           <a class="btn btn-primary waves-effect waves-light" href="{{URL::to('client-add')}}"> Add <i class="md md-add-circle-outline"></i></a>
                        </div>
                     </div>
                  </div>
                  <hr>
                  @if(Session::get('userRole') == 1)
                    <form  action="{{ URL::to('filter-clients') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                         @csrf
                        <div class="row">
                        <?php 
                          $whitelabel_id = $whitelabel_id ?? '';
                          $manager_id = $manager_id ?? '';
                          $employee_id = $employee_id ?? '';
                          $fromdate = $fromdate ?? '';
                          $enddate = $enddate ?? '';
                        ?>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            @if($whitelabel_id || $manager_id || $employee_id)
                            <a href="{{URL::to('manage-leads')}}">
                                <h3>
                                    <i class="icon-filter icon-stack-base"></i>
                                    <i class="icon-remove"></i> Filter
                                </h3>
                            </a>
                            @else
                              <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                            @endif
                          </div>
                        <?php
                          if(session::get('userRole') == 1){
                            $whitelabel = DB::table('users')->where('users_role', 2)->get(); 
                            $manager = DB::table('users')->where('users_role', 3)->get(); 
                            $employee = DB::table('users')->where('users_role', 4)->get();             
                          }elseif(session::get('userRole') == 2){
                            $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                            $employee = DB::table('users')->where('users_role', 4)->get();
                          }elseif(session::get('userRole') == 3){
                            $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                            $employee = DB::table('users')->where('users_role', 4)->get();
                          }elseif(session::get('userRole') == 4){
                            $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                            $employee = DB::table('users')->where('users_role', 4)->get();
                          }
                        ?>
                        
                        @if(Session::get('userRole') == 1)
    
                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <div class="form-group">  
                              <select name="whitelabel_id" id="whitelabel_id" class="form-control">
                                 <option value="">-- Select White Label --</option>
                                  @foreach($whitelabel as $data)
                                    <option value="{{ $data->id }}" {{($data->id == $whitelabel_id) ? "selected" : ""}}>{{ $data->name }}</option>
                                  @endforeach
                              </select>
                            </div>
                          </div>                      
                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <select name="manager_id" id="manager_id"  class="form-control">
                               <option value="">-- Select Manager --</option>
                               @foreach($manager as $data)
                                  <option value="{{ $data->id }}" {{($data->id == $manager_id) ? "selected" : ""}}>{{ $data->name }}</option>
                               @endforeach
                            </select>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <select name="employee_id" id="employee_id"  class="form-control">
                               <option value="">-- Select Employee --</option>
                               @foreach($employee as $data)
                                  <option value="{{ $data->id }}" {{($data->id == $employee_id) ? "selected" : ""}}>{{ $data->name }}</option>
                               @endforeach
                            </select>
                          </div>
    
                         @elseif(Session::get('userRole') == 2)
                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <select name="manager_id" id="manager_id"  class="form-control">
                               <option value="">-- Select Manager --</option>
                               @foreach($manager as $data)
                                  <option value="{{ $data->id }}">{{ $data->name }}</option>
                               @endforeach
                            </select>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <select name="employee_id" id="employee_id"  class="form-control">
                               <option value="">-- Select Employee --</option>
                              <!--  @foreach($employee as $data)
                                  <option value="{{ $data->id }}">{{ $data->name }}</option>
                               @endforeach -->
                            </select>
                          </div>
                         @else
                          <div class="col-md-3 col-sm-3 col-xs-3">
                            <select name="employee_id" id="employee_id"  class="form-control">
                               <option value="">-- Select Employee --</option>
                               @foreach($employee as $data)
                                  <option value="{{ $data->id }}">{{ $data->name }}</option>
                               @endforeach
                            </select>
                          </div>
                         @endif
                          <div class="col-md-3 col-sm-3 col-xs-3">
                           <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                           <a href="{{URL::to('client-listing')}}" class="btn btn-primary">Refresh</a>
                         </div>
                     </div>
                    </form>
                   @endif
                    <hr>
                    <form  action="{{ URL::to('search-status-client') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                    @csrf               
                        <div class="row">
                            <?php
                                $leadstatus = DB::table('status')->get();
                                $status_id = $status_id ?? '';
                            ?>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <div class="form-group">  
                                    <select name="status_id" id="status_id" class="form-control">
                                        <option value="">-- Select Client Status --</option>
                                        <option value="0" {{($status_id == 0) ? "selected" : ""}}>Active</option>
                                        <option value="1" {{($status_id == 1) ? "selected" : ""}}>InActive</option>
                                    </select>
                                </div>
                            </div>   
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                                <a href="{{URL::to('client-listing')}}" class="btn btn-primary">Refresh</a>
                            </div>
                        </div>
                    </form>
                    <hr>
                    <form  action="{{ URL::to('search-client-bydate') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                           <div class="col-md-4">
                                <div class="form-group">
                                 <input type="text" value="{{ $fromdate ?? ''}}" id="my_date_picker1" name="from_date" class="form-control" placeholder="From Date" readonly=""></div>
                           </div>
                           <div class="col-md-4">
                              <div class="form-group">  
                                 <input type="text" id="my_date_picker2" value="{{ $enddate ?? ''}}" name="end_date" class="form-control" aria-required="true" placeholder="To Date" required="" readonly=""> 
                              </div>
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3">
                             <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                             <a href="{{URL::to('manage-leads')}}" class="btn btn-primary">Refresh</a>
                           </div>
                        </div>
                    </form>
                    <hr>
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr.No.</th>
                           @if(Session::get('userRole') == 1)
                           <th>Created By</th>
                           <th>White Level</th>
                           <th>Manager</th>
                           @endif
                           <th>Client Name</th>
                           <th>Email</th>
                           <th>Phone</th>
                           <th>Image</th>
                           <th>Gender</th>
                           <th>Status</th>
                           <th>View Transaction</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($client as $key => $data)
                        <tr class="gradeX">
                           <td>{{ $key+1 }}</td>
                           @if(Session::get('userRole') == 1)
                           <?php 
                              $uploder = DB::table('users')->where('id', $data->upload_by)->first();
                              $whitelevelupload = DB::table('users')->where('id', $uploder->upload_by)->first();
                              $managerlevelupload = DB::table('users')->where('id', $whitelevelupload->upload_by ?? '')->first();
                           ?>
                           @if($uploder->users_role == 1 )
                           <td> {{ $uploder->name ?? ''}} </td>
                           <td> - </td>
                           <td> - </td>
                           @elseif($uploder->users_role == 2)
                            <td> -</td>
                            <td> {{ $uploder->name ?? ''}} </td>
                            <td>  -</td>
                           @elseif($uploder->users_role == 3)
                            <td> - </td>
                            <td>-</td>
                            <td>{{ $uploder->name ?? ''}} </td>
                           @endif
                           @endif

                           <td>{{ $data->name }}</td>
                           <td>{{ $data->email }}</td>
                           <td>{{ $data->phone }}</td>
                          
                           <td>
                              @if($data->profile_image!='')
                              <a href="{{asset('public/profile_image/').'/'.$data->profile_image}}" target="_blank">
                              <img src="{{asset('public/profile_image/').'/'.$data->profile_image}}" alt="profile Image" height="50" width="50"> 
                              </a>
                              @else
                              <img src="{{asset('public/no-image.jpg')}}" alt="Brand Image" height="50" width="50">
                              @endif
                           </td>
                           @if($data->gender == 0)
                           <td>
                              <p class="mb-0">
                                 Male
                              </p>
                           </td>
                           @else
                           <td>
                              <p class="mb-0">
                                 Female
                              </p>
                           </td>
                           @endif
                            <?php $activeuser = User::isOnline($data->id); ?>
                            @if($activeuser)
                            <td style="color: green;"><strong>Online</strong></td>
                            @else
                              <td style="color: red;"><strong>Offline</strong></td>
                            @endif
                            <td><a href="{{ URL::to('get-transaction',$data->id)}}" target="_blank" class="on-default eye-row"  data-toggle="tooltip" data-placement="top" title="" data-original-title="View">View</a></td>
                            <td class="actions">
                              <a href="{{ URL::to('client-view-data',$data->id)}}"  target="_blank" class="on-default eye-row"  data-toggle="tooltip" data-placement="top" title="" data-original-title="View"><i class="fa fa-eye"></i></a>
                              &nbsp;&nbsp;&nbsp;
                              <a href="{{ URL::to('edit-client',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                              &nbsp;&nbsp;&nbsp;
                              <a href="{{ URL::to('delete-user',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->
<script> 
   $(document).ready(function() { 

       $(function() { 
           $("#my_date_picker1").datepicker({}); 
       }); 

       $(function() { 
           $("#my_date_picker2").datepicker({}); 
       }); 

       $('#my_date_picker1').change(function() { 
           startDate = $(this).datepicker('getDate'); 
           $("#my_date_picker2").datepicker("option", "minDate", startDate); 
       }) 

       $('#my_date_picker2').change(function() { 
           endDate = $(this).datepicker('getDate'); 
           $("#my_date_picker1").datepicker("option", "maxDate", endDate); 
       }) 
   }) 
</script> 