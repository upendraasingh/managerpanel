<?php 
    use App\User;
?>
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">View Comment</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">View Comment</li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="m-b-30">
                                <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>Go Back</button>
                            </div>
                        </div>
                    </div>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                            <th>Sr.No.</th>
                            @if($comment[0]->client_id!=0)
                                <th>Client Name</th>
                            @else
                                <th>Lead Name</th>
                            @endif
                            <th>Booking Date</th>
                            <th>Comment</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($comment as $key => $data)                        
                        <tr class="gradeX">
                            <td>{{ $key+1 }}</td>
                                @if($data->lead_id!=0)
                                    @foreach($lead as $key => $le)
                                        @if($le->id == $data->lead_id)
                                            <th>{{$le->name}}</th>
                                        @endif
                                    @endforeach
                                @else
                                    @foreach($client as $key => $cli)
                                        
                                        @if($cli->id == $data->client_id)
                                            <th>{{$cli->name}}</th>
                                        @endif
                                    @endforeach
                                @endif                            
                            <td>{{ $data->bookingdate }}</td>
                            <td>{{ $data->comment }}</td>                          
                            <td></td>                           
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->
