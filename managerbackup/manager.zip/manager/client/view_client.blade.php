<style type="text/css">
    .colerclass{
        color: #317eeb;
    }
    .menustyle{
        margin: 10px;
    }
</style>

@php 
$useramount = DB::table('wallet_transaction')->where('client_id', $viewclient->id)->where('status','0')->orderBy('id','DESC')->first();
@endphp

<!-- Start content -->
<div class="content">
    <div class="container-fluid"><!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">           
                <h4 class="pull-left page-title">View Client</h4>
                <ol class="breadcrumb pull-right">
                    <li><a href="{{ URL::to('home') }}">Home</a></li>
                    <li class="active">View Client</li>
                </ol>
            </div>
        </div>
        <form  action="{{ URL::to('add-')}}" method="POST" id="FormValidation" enctype="multipart/form-data">
        @csrf
        <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="m-b-30">
                                    <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>Go Back</button>
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <a href="{{ URL::to('check/document')}}/{{$viewclient->id}}" style="float: right;" class="btn btn-primary">Check Document</a>
                                <a href="#" class="btn btn-primary" style="float: right;margin-right:10px;">Available Bailance: $ @if($useramount!=null){{$useramount->available_balance}} @else 0 @endif</a>
                                <a href="#" class="btn btn-primary" style="float: right;margin-right:10px;" data-toggle="modal" data-target="#myModalview">View Appointment</a>
                            </div>
                        </div>
                     <hr>
                    <div class="row" style="text-align: center;">
                        <div class="col-md-12">
                            <div class="form-group"> 
                                @if($viewclient->profile_image!='')
                                    <img src="{{ asset('public/profile_image/').'/'.$viewclient->profile_image }}" alt="image" width="100" height="100">
                                @else
                                    <img src="http://localhost/imark_admin/public/no-image.jpg" alt="image" width="100" height="100">
                                @endif
                            </div>
                        </div>
                    </div>
                     <div class="row">
                        <input type="hidden" name="ids" id="ids" value="{{ $viewclient->id ?? '' }}">
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Name : </label>
                              <input  type="text" id="name" name="name" class="form-control" required="" value="{{ $viewclient->name ?? '' }}" aria-required="true" placeholder="" autocomplete="off" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Email : </label>
                              <input  type="email" id="email" name="email" class="form-control" required="" value="{{ $viewclient->email ?? ''}}" aria-required="true" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Phone : </label>
                              <input  type="text" id="phone" name="phone" readonly="" class="form-control" required="" value="{{ $viewclient->phone ?? ''}}" > 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Password : </label>
                              <input  type="text" id="password" name="password" readonly="" disabled="" class="form-control" required="" value="{{$viewclient->view_password}}" > 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $Country = DB::table('country')->get(); ?>
                              <label class="control-label">Country : </label>
                              <select class="form-control" id="country_id" name="country_id" required="" readonly=''>
                                 <option value="">-- Choose Country --</option>
                                 @foreach($Country as $data)
                                 <option value="{{ $data->id }}" {{ ($data->id == $viewclient->country_id) ? "selected" : "" }}>{{ $data->country_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Address : </label>
                              <input type="text" id="address" name="address" value="{{ $viewclient->address }}" class="form-control" aria-required="true" maxlength="100" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">  
                                <label class="control-label">Gender : </label>
                                @if($viewclient->gender == 0)
                                    <input type="text" value="Male" class="form-control" readonly=""> 
                                @else
                                    <input type="text" value="Female" class="form-control" readonly=""> 
                                @endif                              
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">  
                                <br>
                                <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Password Change</a>
                            </div>
                        </div>  
                     </div>
               </div><!-- End card-body -->
            </div> <!-- End card -->
        </form><!-- Form End -->
      </div><!-- container -->
   </div>
<!--- MODEL CALL--->
<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Password Change</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form  action="{{ url('change-password-client') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
               <div class="row">
                  <input type="hidden" name="editId" value="{{ $viewclient->id }}">
                  <div class="col-md-12">
                     <div class="form-group">
                        <p class="control-label"><b>New password :</b> <font color="red">*</font></p>
                        <input type="password" id="new_password" name="password" class="form-control" required="" aria-required="true">
                        <input type="checkbox" onclick="myFunction2()"> Show Password 
                     </div>
                  </div>
                  <div class="col-md-12">
                     <div class="form-group">
                        <p class="control-label"><b>Confirm password :</b> <font color="red">*</font></p>
                        <input type="password" id="password" name="password" onchange="check_password()" class="form-control" required="" aria-required="true">
                        <input type="checkbox" onclick="myFunction3()"> Show Confirm Password 
                     </div>
                  </div>                
               </div>
            </div>
            <div class="modal-footer"> 
               <button type="submit" onclick="return check_password()" id="submitbtn" class="btn btn-primary">Update</button>
               <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>                
            </div>
         </form>
      </div>
   </div>
</div>

<!-- /.modal eND -->
<!--- MODEL CALL--->
<div id="myModalview" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">View All Client Appointment</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form  action="{{ url('book-appointment') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
                <div class="row">
                    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>Sr.No.</th>
                                <th>Appointment Date</th>
                                <th>Comment</th>
                            </tr>
                        </thead>
                        <tbody>  
                            <?php
                                $appointment = DB::table('leadappointment')->get(); 
                                $appointment = $appointment->toArray();
                            ?>                            
                            @foreach($appointment as $key => $data)
                            @if($data->client_id !=0 )   
                            <tr class="gradeX">
                                <td>{{ $key+1 }}</td>
                                <td>{{ $data->bookingdate ?? ''}}</td>
                                <td>{{ $data->comment ?? ''}}</td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody> 
                        </table>  
                    </div>       
                </div>
            </div>
            <!-- <div class="modal-footer"> 
                <button type="submit" id="submitbtn" class="btn btn-primary">Book</button>
                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>                
            </div> -->
         </form>
      </div>
   </div>
</div>
<!-- /.modal eND -->
<script type="text/javascript">
    function myFunction2() {
        var x = document.getElementById("new_password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>

<script type="text/javascript">
    function myFunction3() {
        var x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>

<!-- Password & Confirm passeword mach script -->
<script type="text/javascript">
    function check_password()
    {      
        if($('#new_password').val() != $('#password').val()) {
            alert("Password and Confirm Password don't match");
            event.preventDefault();

            $("#password").val('');    
            $("#password").focus();
        }  
    }
</script>
