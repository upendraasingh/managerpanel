<div class="content">
    <div class="container-fluid">
    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Orders</h4>
            <ol class="breadcrumb pull-right">
                <li><a href="{{ URL::to('home') }}">Home</a></li>
                <li class="active">Manage Orders</li>
            </ol>
        </div>
    </div>
    <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">                  
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                            <th>Sr.No.</th>                          
                            <th>Client Name</th>
                            <th>ID N0</th>                             
                            <th>Product</th> 
                            <th>Purchase Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($orders as $key => $data)  
                            <tr class="gradeX">                         
                                <td>{{ ++$key }}</td>
                                <?php 
                                    $client = DB::table('users')->where('id', $data->user_id)->first();
                                    $product = DB::table('product')->where('id', $data->watch_id)->first();
                                ?>
                                <td>{{ $client->name }}</td>
                                <td>{{ $product->id_no ?? ''}}</td>
                                <td>{{ $product->model_name }}</td>

                                @php $date = new DateTime($data->created_at);@endphp

                                <td>{{ $date->format('d-m-Y') }}</td>  
                                <td class="actions">
                                    <a href="{{ URL::to('admin-moveto-marketplace',$data->id) }}" class="btn btn-primary"  onclick="return confirm('Are you want to move this watch to MarkerPlace?')" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Move To MarkerPlace">Move To MarkerPlace</a> 
                                    &nbsp;&nbsp;&nbsp;
                                 
                                    <!--<a href="{{ URL::to('view-order-details',$data->id) }}" class="on-default edit-row"data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                                     &nbsp;&nbsp;&nbsp;
                                 
                                    <a href="{{ URL::to('delete-product',$data->id) }}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>-->
                                </td>                         
                            </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div><!-- end card-body -->
            </div>
         </div><!-- container -->
      </div>
   </div>
</div>
<!-- content -->
<script type="text/javascript">
    $("#checkAll").click(function () {
        $('input:checkbox').not(this).prop('checked', this.checked);
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('[data-toggle="popover"]').popover({
          placement: 'top',
          trigger: 'hover'
        });
    });
</script>