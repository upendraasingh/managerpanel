<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<?php
  $client = DB::table('users')->where('id', $orderDetail->client_id)->first();
  $product = DB::table('product')->where('id', $orderDetail->product_id)->first();
?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
     <div class="col-sm-12">
        <h4 class="pull-left page-title">View Order Detail</h4>
        <ol class="breadcrumb pull-right">
           <li><a href="{{ URL::to('home') }}">Home</a></li>
           <li class="active">View Order Detail</li>
        </ol>
     </div>
    </div>
  <div class="row" id="example-basic">
     <div class="col-md-12">
        <div class="card">
           <div class="card-body">
              <div class="row">
                 <div class="col-md-4">
                    <div class="form-group">  
                       <label class="control-label">Client Name :</label>
                       <input type="text" class="form-control" readonly="" value="{{ $client->name }}"> 
                    </div>
                 </div>
                 <div class="col-md-4">
                    <div class="form-group">  
                       <label class="control-label">Product :</label>
                       <input type="text" class="form-control" readonly="" value="{{ $product->model_name }}"> 
                    </div>
                 </div>
                 <div class="col-md-4">
                    <div class="form-group">  
                       <label class="control-label">Order Id :</label>
                       <input type="text" class="form-control" readonly="" value="{{ $orderDetail->order_id }}"> 
                    </div>
                 </div>
                 <div class="col-md-4">
                    <div class="form-group">  
                       <label class="control-label">Purchase Date :</label>
                       <input type="text" class="form-control" readonly="" value="{{ $orderDetail->purchase_date }}"> 
                    </div>
                 </div>
                 <div class="col-md-4">
                    <div class="form-group">  
                       <label class="control-label">Order Status :</label>
                       @if($orderDetail->status == 1)
                       <input type="text" class="form-control" readonly="" value="Success"> 
                       @elseif($orderDetail->status == 2)
                       <input type="text" class="form-control" readonly="" value="Pending"> 
                       @elseif($orderDetail->status == 3)
                       <input type="text" class="form-control" readonly="" value="Process"> 
                       @else
                       <input type="text" class="form-control" readonly="" value="cancel"> 
                       @endif                               
                    </div>
                 </div>
              </div>
           </div><!-- End card-body -->
        </div>
     </div><!-- container -->
</div>
     