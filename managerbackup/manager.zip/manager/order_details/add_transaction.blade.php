<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Add Transaction</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Add Transaction</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-amount') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
      @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                    <div class="row">
                      <input type="hidden" name="admin_add_money" value="1">
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Client List : <font color="red">*</font></label>
                              <select name="client_id" id="client_id" class="form-control" required="">
                                 <option value=""> -- Choose Client -- </option>
                                  <?php
                                    if (Session::get('userRole') == 1) {
                                      $clients = DB::table('users')->where('users_role', 5)->get();
                                    }elseif (Session::get('userRole') == 2) {
                                      $clients = DB::table('users')->where('users_role', 5)->where('upload_by', Session::get('gorgID'))->get();
                                    } 
                                  ?>
                                 @foreach($clients as $data)
                                 <option value="{{ $data->id }}">{{ $data->name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>   
                       
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Money : <font color="red">*</font></label>
                              <input type="text" id="deposit" name="deposit" class="form-control" required="" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="10" aria-required="true" placeholder="Enter money"> 
                           </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Save</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
      
<!-- Script for model select according to brand  -->
<script type="text/javascript">
   $('#brand_id').change(function()
   {
      var barndId = $(this).val();
      if(barndId)
      {
         $.ajax({
            type:"GET",
            url:"{{url('get-model/')}}"+'/'+barndId, 
            success:function(res)
            {               
               if(res){
                  $("#model_id").empty();
                  $("#model_id").append('<option>-- Choose Model --</option>');
                  $.each(res,function(key,value){
                     $("#model_id").append('<option value="'+value.id+'">'+value.category_name+'</option>');
                  });
                }
               else{
                  $("#model_id").empty();
               }
            }
         });
      }
      else{
         $("#model_id").empty();
      } 
   });
</script>

<!-- add more features script -->
<script type="text/javascript">
   $(document).ready(function(){
       var maxField = 10; //Input fields increment limitation
       var addButton = $('.add_button'); //Add button selector
       var wrapper = $('.field_wrapper'); //Input field wrapper
       var fieldHTML = '<div><input type="text" class="form-control" name="features[]" value=""/><a href="javascript:void(0);" class="remove_button btn btn-danger">Remove</a></div>'; //New input field html 
       var x = 1; //Initial field counter is 1
       
       //Once add button is clicked
       $(addButton).click(function(){
           //Check maximum number of input fields
           if(x < maxField){ 
               x++; //Increment field counter
               $(wrapper).append(fieldHTML); //Add field html
           }
       });
       
       //Once remove button is clicked
       $(wrapper).on('click', '.remove_button', function(e){
           e.preventDefault();
           $(this).parent('div').remove(); //Remove field html
           x--; //Decrement field counter
       });
   });
</script>
