<p> Hi, This is {{ $data['name'] }}</p>
<p> I have some query like {{ $data['email'] }}</p>
<p> i would be {{ $data['phone'] }}</p>