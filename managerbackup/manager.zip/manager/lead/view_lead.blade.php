<style type="text/css">
    .colerclass{
        color: #317eeb;
    }
    .menustyle{
        margin: 10px;
    }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">View Leads</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">View Leads</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-leads') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <div class="m-b-30" style="float: right;">
                              <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal">View Appointment</a>
                           </div>
                        </div>
                     </div>
                     <hr>
                     <div class="row">                     
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Name :</label>
                              <input type="text" id="name" name="name" value="{{ $viewlead->name }}" class="form-control" aria-required="true" maxlength="25" required="" readonly="">
                           </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                           <div class="form-group">  
                              <label class="control-label">Email :</label>
                              <input type="email" id="email" name="email" value="{{ $viewlead->email }}" onchange="email_check()" class="form-control" required="" maxlength="25" readonly="">
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Phone :</label>
                              <input type="text" value="{{ $viewlead->phone }}" class="form-control" aria-required="true" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $Country = DB::table('country')->get(); ?>
                              <label class="control-label">Country :</label>
                              <select class="form-control" id="country_id" name="country_id" readonly="">
                                 <option value="">-- Choose Country --</option>
                                 @foreach($Country as $data)
                                 <option value="{{ $data->id }}" {{($data->id == $viewlead->country_id) ? "selected" : ""}}>{{ $data->country_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Address :</label>
                              <input type="text" id="address" name="address" value="{{ $viewlead->address }}" class="form-control" aria-required="true" maxlength="100" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">DOB :</label>
                              <input type="text" id="datepicker" name="dob"  value="{{ $viewlead->dob }}" class="form-control" aria-required="true" readonly=""> 
                           </div>
                        </div> 
                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $status = DB::table('status')->get(); ?>
                              <label class="control-label">Status : <font color="red">*</font></label>
                              <select class="form-control" id="status_id" name="status_id" required="" readonly="">
                                 <option value="">-- Choose Status --</option>
                                 @foreach($status as $data)
                                 <option value="{{ $data->id }}" {{($data->id == $viewlead->status_id) ? "selected" : ""}}>{{ $data->status_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        @if($viewlead->gender == 0)
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="control-label">Gender :</label>
                              <input type="text" class="form-control" value="Male" readonly="">
                           </div>
                        </div>
                        @else 
                       <div class="col-md-6">
                           <div class="form-group">
                              <label class="control-label">Gender :</label>
                              <input type="text" class="form-control" value="FeMale" readonly="">
                           </div>
                        </div>
                        @endif  
                        <div class="col-md-6">
                           <div class="form-group"> 
                              <label class="control-label">Image :</label>
                              <img src="{{ URL::asset('/public/profile_image/') }}/{{ $viewlead->image ?? ''}}" width="100px" height="100">
                           </div>
                        </div>                 
                     </div>                    
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
<!--- MODEL CALL--->
<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">View All Lead Appointment</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form  action="{{ url('book-appointment') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
                <div class="row">
                    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>Sr.No.</th>
                                <th>Appointment Date</th>
                                <th>Comment</th>
                            </tr>
                        </thead>
                        <tbody>  
                            <?php
                                $appointment = DB::table('leadappointment')->get(); 
                            ?>                            
                            @foreach($appointment as $key => $data)      
                            @if($data->lead_id !=0 )                  
                            <tr class="gradeX">
                                <td>{{ $key+1 }}</td>
                                <td>{{ $data->bookingdate ?? ''}}</td>
                                <td>{{ $data->comment ?? ''}}</td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody> 
                        </table>  
                    </div>       
                </div>
            </div>
            <!-- <div class="modal-footer"> 
                <button type="submit" id="submitbtn" class="btn btn-primary">Book</button>
                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>                
            </div> -->
         </form>
      </div>
   </div>
</div>
<!-- /.modal eND -->
<script type="text/javascript">
   $('#whitelabel_id').change(function()
   {
      var whitelabel_ID = $(this).val();
      if(whitelabel_ID){
         $.ajax({
            type:"GET",
            url:"{{url('get-whitelabeldata/')}}"+'/'+whitelabel_ID, 
            success:function(res)
            {               
               if(res){
                  $("#upload_by").empty();
                  $("#upload_by").append('<option value="">-- Choose Manager --</option>');
                  $.each(res,function(key,value){
                     $("#upload_by").append('<option value="'+value.id+'">'+value.name+'</option>');
                  });
               }
               else{
                  $("#upload_by").empty();
               }
            }
         });
      }
      else{
         $("#upload_by").empty();
      } 
   });
</script>