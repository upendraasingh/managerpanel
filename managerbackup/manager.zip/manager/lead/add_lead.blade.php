<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Add Leads</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Add Leads</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-leads') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">   

                    
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Name : <font color="red">*</font></label>
                              <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                           <div class="form-group">  
                              <label class="control-label">Email : <font color="red">*</font></label>
                              <input type="email" id="email" name="email" onchange="email_check()" class="form-control" required="" maxlength="25">
                              <p style="color: red; display: none;" id="email_error">Email already exists.</p>
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Phone : <font color="red">*</font></label>
                              <input type="text" id="phone" name="phone" class="form-control" aria-required="true" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="10" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $Country = DB::table('country')->get(); ?>
                              <label class="control-label">Country : <font color="red">*</font></label>
                              <select class="form-control" id="country_id" name="country_id" required="">
                                 <option value="">-- Choose Country --</option>
                                 @foreach($Country as $data)
                                 <option value="{{ $data->id }}">{{ $data->country_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Address : <font color="red">*</font></label>
                              <input type="text" id="address" name="address" class="form-control" aria-required="true" maxlength="100" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">DOB : </label>
                              <input type="text" id="datepicker" name="dob" class="form-control" aria-required="true" required="" readonly=""> 
                           </div>
                        </div> 
                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $status = DB::table('status')->get(); ?>
                              <label class="control-label">Status : <font color="red">*</font></label>
                              <select class="form-control" id="status_id" name="status_id" required="">
                                 <option value="">-- Choose Status --</option>
                                 @foreach($status as $data)
                                 <option value="{{ $data->id }}">{{ $data->status_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <p class="control-label"><b>Gender :</b> <font color="red">*</font></p>
                              <div class="radio radio-info form-check-inline">
                                 <input type="radio" id="active" value="0" name="gender" checked="">
                                 <label for="inlineRadio1"> Male </label>
                              </div>
                              <div class="radio radio-info form-check-inline">
                                 <input type="radio" id="inactive" value="1" name="gender">
                                 <label for="inlineRadio1"> Femail </label>
                              </div>
                           </div>
                        </div>   
                        <div class="col-md-6">
                           <div class="form-group"> 
                              <label class="control-label">Image : <font color="red">*</font></label>
                              <input type="file" class="form-control" name="image" accept="image/x-png,image/gif,image/jpeg" required="">
                           </div>
                        </div>                 
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Save</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>

<script type="text/javascript">
   $('#whitelabel_id').change(function()
   {
      var whitelabel_ID = $(this).val();
      if(whitelabel_ID){
         $.ajax({
            type:"GET",
            url:"{{url('get-whitelabeldata/')}}"+'/'+whitelabel_ID, 
            success:function(res)
            {               
               if(res){
                  $("#upload_by").empty();
                  $("#upload_by").append('<option value="">-- Choose Manager --</option>');
                  $.each(res,function(key,value){
                     $("#upload_by").append('<option value="'+value.id+'">'+value.name+'</option>');
                  });
               }
               else{
                  $("#upload_by").empty();
               }
            }
         });
      }
      else{
         $("#upload_by").empty();
      } 
   });
</script>