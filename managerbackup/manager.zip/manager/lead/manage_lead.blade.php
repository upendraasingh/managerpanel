<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"> </script> 
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Leads </h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Leads </li>
            </ol>
         </div>
      </div>

      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">

                  <div class="row">
                     <div class="col-sm-6">
                        <div class="m-b-30">
                           <a href="{{ URL::to('add-lead')}}" class="btn btn-primary waves-effect waves-light">Add <i class="md md-add-circle-outline" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
                  <hr>
                <form  action="{{ URL::to('search-lead') }}" method="POST" name="myForm" onsubmit="return validateForm()" id="FormValidation" enctype="multipart/form-data">
                @csrf
                  <div class="row">
                    <?php 
                      $whitelabel_id = $whitelabel_id ?? '';
                      $manager_id = $manager_id ?? '';
                      $employee_id = $employee_id ?? '';
                      $fromdate = $fromdate ?? '';
                      $enddate = $enddate ?? '';
                    ?>
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        @if($whitelabel_id || $manager_id || $employee_id)
                        <a href="{{URL::to('manage-leads')}}">
                            <h3>
                                <i class="icon-filter icon-stack-base"></i>
                                <i class="icon-remove"></i> Filter
                            </h3>
                        </a>
                        @else
                          <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                        @endif
                      </div>
                    <?php
                      if(session::get('userRole') == 1){
                        $whitelabel = DB::table('users')->where('users_role', 2)->get(); 
                        $manager = DB::table('users')->where('users_role', 3)->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();             
                      }elseif(session::get('userRole') == 2){
                        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();
                      }elseif(session::get('userRole') == 3){
                        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();
                      }elseif(session::get('userRole') == 4){
                        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', Session::get('gorgID'))->get(); 
                        $employee = DB::table('users')->where('users_role', 4)->get();
                      }
                    ?>
                    
                    @if(Session::get('userRole') == 1)

                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="whitelabel_id" id="whitelabel_id" class="form-control">
                             <option value="">-- Select White Label --</option>
                              @foreach($whitelabel as $data)
                                <option value="{{ $data->id }}" {{($data->id == $whitelabel_id) ? "selected" : ""}}>{{ $data->name }}</option>
                              @endforeach
                          </select>
                        </div>
                      </div>                      
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="manager_id" id="manager_id"  class="form-control">
                           <option value="">-- Select Manager --</option>
                           @foreach($manager as $data)
                              <option value="{{ $data->id }}" {{($data->id == $manager_id) ? "selected" : ""}}>{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="employee_id" id="employee_id"  class="form-control">
                           <option value="">-- Select Employee --</option>
                           @foreach($employee as $data)
                              <option value="{{ $data->id }}" {{($data->id == $employee_id) ? "selected" : ""}}>{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>

                     @elseif(Session::get('userRole') == 2)
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="manager_id" id="manager_id"  class="form-control">
                           <option value="">-- Select Manager --</option>
                           @foreach($manager as $data)
                              <option value="{{ $data->id }}">{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="employee_id" id="employee_id"  class="form-control">
                           <option value="">-- Select Employee --</option>
                          <!--  @foreach($employee as $data)
                              <option value="{{ $data->id }}">{{ $data->name }}</option>
                           @endforeach -->
                        </select>
                      </div>
                     @else
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <select name="employee_id" id="employee_id"  class="form-control">
                           <option value="">-- Select Employee --</option>
                           @foreach($employee as $data)
                              <option value="{{ $data->id }}">{{ $data->name }}</option>
                           @endforeach
                        </select>
                      </div>
                     @endif
                      <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                       <a href="{{URL::to('manage-leads')}}" class="btn btn-primary">Refresh</a>
                     </div>

                  </div>
                </form>
               <hr>
               <form  action="{{ URL::to('search-status') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
               @csrf               
                  <div class="row">
                      <?php
                        $leadstatus = DB::table('status')->get();
                        $status_id = $status_id ?? '';
                      ?>
                     <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="status_id" id="status_id" class="form-control">
                            <option value="">-- Select lead Status --</option>
                            @foreach($leadstatus as $lead)
                              <option value="{{ $lead->id }}" {{($lead->id == $status_id) ? "selected" : ""}}>{{ $lead->status_name }}</option>
                            @endforeach
                          </select>
                        </div>
                     </div>   
                      <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                       <a href="{{URL::to('manage-leads')}}" class="btn btn-primary">Refresh</a>
                     </div>
                  </div>
               </form>
               <hr>

                <form  action="{{ URL::to('search-leads-bydate') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                       <div class="col-md-4">
                            <div class="form-group">
                             <input type="text" value="{{ $fromdate ?? ''}}" id="my_date_picker1" name="from_date" class="form-control" placeholder="From Date" readonly=""></div>
                       </div>
                       <div class="col-md-4">
                          <div class="form-group">  
                             <input type="text" id="my_date_picker2" value="{{ $enddate ?? ''}}" name="end_date" class="form-control" aria-required="true" placeholder="To Date" required="" readonly=""> 
                          </div>
                       </div>
                       <div class="col-md-3 col-sm-3 col-xs-3">
                         <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                         <a href="{{URL::to('manage-leads')}}" class="btn btn-primary">Refresh</a>
                       </div>
                    </div>
                </form>
                  <hr>
                  <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                      <button data-toggle="modal" data-target="#myModal" class="btn btn-success">Import Client Data</button>
                        &nbsp;&nbsp;&nbsp;
                      <a class="btn btn-warning" href="{{ URL::to('export') }}">Export Client Data</a>
                    </div>                   
                  </div>
                  <hr>
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                          <th>Sr.No.</th> 
                            @if(Session::get('userRole') == 1) <!-- admin label -->
                                <th>Created By Me</th>
                                <th>White Label</th>
                                <th>Manager</th>
                                <th>Employee</th>
                            @elseif(Session::get('userRole') == 2) <!-- White label -->
                                <th>Created By Me</th>
                                <th>Manager</th>
                                <th>Employee</th>
                            @elseif(Session::get('userRole') == 3) <!-- Manager label -->
                                <th>Created By Me</th>
                                <th>Employee</th>
                            @elseif(Session::get('userRole') == 4) <!-- Employee label -->
                              <th>Created By Me</th>
                            @endif                         
                           <th>Lead Name</th>
                           <th>Email</th>
                           <th>Phone</th>                            
                           <th>Status</th>                            
                           <th>Date</th>                            
                           <th>Action</th>
                        </tr>
                    </thead>
                    @if(Session::get('userRole') == 1)

                    <tbody>                              
                        @foreach($leads as $key => $data)
                        <?php 
                            $uploder = DB::table('users')->where('id', $data->upload_by)->first();
                            $whitelabel = DB::table('users')->where('id', $uploder->upload_by ?? '')->first();
                            $manager = DB::table('users')->where('id', $whitelabel->upload_by ?? '')->first();
                        ?>                        

                          <tr class="gradeX">
                            <td>{{ $key+1 }}</td>  
                            @if(Session::get('userRole') == 1)   
                                @if($uploder!='')
                                    @if($uploder->users_role == 1 )
                                        <td>{{ $uploder->name ?? '' }}</td> 
                                        <td> - </td> 
                                        <td> - </td> 
                                        <td> - </td> 
                                    @elseif($uploder->users_role == 2)
                                        <td> - </td> <!-- SuperAdmin Label Name -->
                                        <td>{{ $uploder->name ?? '' }}</td> <!-- White Label Name -->
                                        <td> - </td> <!-- Manager Name -->
                                        <td> - </td> <!-- Employee Name -->
                                    @elseif($uploder->users_role == 3)
                                        <td> - </td> <!-- SuperAdmin Label Name -->
                                        <td>{{ $whitelabel->name ?? ''}}</td> <!-- White Label Name -->
                                        <td>{{ $uploder->name ?? '' }}</td> <!-- Manager Name -->
                                        <td> - </td> <!-- Employee Name -->
                                    @elseif($uploder->users_role == 4)
                                        <td> - </td> <!-- SuperAdmin Label Name -->
                                        <td>{{ $manager->name ?? ''}}</td> <!-- White Label Name -->
                                        <td>{{ $whitelabel->name ?? ''}}</td> <!-- Manager Name -->
                                        <td>{{ $uploder->name ?? ''}}</td> <!-- Employee Name -->
                                    @endif                              
                                @endif                         
                            @endif                         
                              <td>{{ $data->name ?? ''}}</td>
                              <td>{{ $data->email ?? ''}}</td>
                              <td>{{ $data->phone ?? ''}}</td>                      
                              
                              <td>
                                <?php $status = DB::table('status')->where('id', $data->status_id)->first(); ?>
                                <p class="mb-0">{{ $status->status_name ?? ''}}</p>                              
                              </td>                       
                              <td>{{ $data->created_at ?? ''}}</td>                         
                           
                              <td class="actions">
                                <a href="{{ URL::to('lead-view',$data->id) }}" class="on-default edit-row"  onclick="editRecords({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View"><i class="fas fa-eye"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-edit',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-delete',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                              </td>
                        </tr>
                        @endforeach
                    </tbody> 

                    @elseif(Session::get('userRole') == 2)

                    <tbody>
                        <?php 
                            $finalarray[]  = array(); 
                            $uploder[]     = array(); 
                            $whitelabel[]  = array(); 
                            $manager[]     = array();
                            $employee[]    = array();

                            foreach($leads as $key => $data){    
                                $uploderdata = DB::table('users')->where('id',$data->upload_by)->get();                                              
                                foreach($uploderdata as $key => $upload){  
                                    $leadss  = DB::table('leads')->where('upload_by',$upload->id)->first();                                              
                                    $finalarray[] = $leadss;                                    
                                    $uploder[] = $upload;
                                    $whitelabeldata = DB::table('users')->where('upload_by',$upload->id)->get();
                                    foreach($whitelabeldata as $key => $white){     
                                        $leadsss  = DB::table('leads')->where('upload_by',$white->id)->first();
                                        $finalarray[] = $leadsss;
                                        $whitelabel[] = $white;                   
                                        $managerdata  = DB::table('users')->where('upload_by',$white->id)->get(); 
                                        
                                        foreach($managerdata as $key => $manage){ 
                                            $leadssss  = DB::table('leads')->where('upload_by',$manage->id)->first();
                                            $finalarray[] = $leadssss;
                                            $manager[] = $manage;
                                        }    
                                    }
                                }
                            }
                            $finalarray   = array_filter($finalarray);  
                        ?>                        

                        @foreach($finalarray as $key => $data)
                        <?php 
                           
                            /*$uploader = array_filter((array)$uploder);
                            $whitelabel = array_filter((array)$whitelabel);
                            $manager = array_filter((array)$manager);*/
                            
                            $uploder = DB::table('users')->where('id', $data->upload_by)->first();
                            $whitelabel = DB::table('users')->where('id', $uploder->upload_by)->first();
                            $manager = DB::table('users')->where('id', $whitelabel->upload_by ?? '')->first();
                            //dd($manager);

                        ?>
                        <tr class="gradeX">
                            <td>{{ $key }}</td>

                                @if($uploder->users_role == 2)                                
                                    <td>{{ $uploder->name ?? '' }}</td> <!-- White Label Name -->
                                    <td> - </td> <!-- Manager Name -->
                                    <td> - </td> <!-- Employee Name -->
                                @elseif($uploder->users_role == 3)                              
                                    <td> <!-- {{ $whitelabel->name ?? ''}} -->- </td> <!-- White Label Name -->
                                    <td>{{ $uploder->name ?? '' }}</td> <!-- Manager Name -->
                                    <td> - </td> <!-- Employee Name -->
                                @elseif($uploder->users_role == 4)
                                    <td><!-- {{ $manager->name ?? ''}} -->-  </td> <!-- White Label Name -->
                                    <td>  {{ $whitelabel->name ?? ''}}</td> <!-- Manager Name -->
                                    <td>{{ $uploder->name ?? ''}}</td> <!-- Employee Name -->
                                @endif                
                                                     
                            <td>{{ $data->name ?? ''}}</td>
                            <td>{{ $data->email ?? ''}}</td>
                            <td>{{ $data->phone ?? ''}}</td>                      
                              
                            <td>
                                <?php $status = DB::table('status')->where('id', $data->status_id)->first(); ?>
                                <p class="mb-0">{{ $status->status_name }}</p>  
                            </td>                       
                            <td>{{ $data->created_at ?? ''}}</td>                         
                           
                              <td class="actions">
                                <a href="{{ URL::to('lead-view',$data->id) }}" class="on-default edit-row"  onclick="editRecords({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View"><i class="fas fa-eye"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-edit',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-delete',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                              </td>
                        </tr>
                        @endforeach
                    </tbody> 
                    @elseif(Session::get('userRole') == 3)
                    <tbody> 
                        <?php 
                            $finalarray[]  = array(); 
                            $uploder[]     = array(); 
                            $whitelabel[]  = array(); 
                            $manager[]     = array();
                            $employee[]    = array();

                            foreach($leads as $key => $data){   

                                $managerdata  = DB::table('users')->where('id',$data->upload_by)->get();                                       
                                foreach($managerdata as $key => $manage){
                                    $managerlead  = DB::table('leads')->where('upload_by',$manage->id)->first();
                                    $finalarray[] = $managerlead;
                                    $employeedata = DB::table('users')->where('upload_by',$manage->id)->get();                                    
                                    foreach($employeedata as $key => $employee){ 
                                        $employeelead  = DB::table('leads')->where('upload_by',$employee->id)->first();
                                        $finalarray[] = $employeelead;                                    
                                    }    
                                }    
                            }
                                
                            $finalarray   = array_filter($finalarray);  
                            //dd($finalarray);
                        ?>                        
                        @foreach($finalarray as $key => $data)
                        <?php 
                            $uploder = DB::table('users')->where('id', $data->upload_by)->first();
                            $whitelabel = DB::table('users')->where('id', $uploder->upload_by)->first();
                            $manager = DB::table('users')->where('id', $whitelabel->upload_by ?? '')->first();
                            $employee = DB::table('users')->where('id', $data->upload_by)->first();                           
                            //dd($uploder);
                        ?>
                        <tr class="gradeX">
                            <td>{{ $key }}</td>         
                              @if($uploder->users_role == 2)                                
                                <td>{{ $uploder->name ?? '' }}</td> <!-- White Label Name -->
                                <td> - </td> <!-- Manager Name -->
                                <td> - </td> <!-- Employee Name -->
                              @elseif($uploder->users_role == 3)                                                          
                                <td>{{ $uploder->name ?? '' }}</td> <!-- Manager Name -->
                                <td> - </td> <!-- Employee Name -->
                              @elseif($uploder->users_role == 4)
                                <!-- <td>{{ $manager->name ?? ''}}</td>
                                <td>{{ $whitelabel->name ?? ''}}</td>
                                <td>{{ $uploder->name ?? ''}}</td> -->
                                <td>-</td> <!-- Manager Name -->
                                <td>{{ $uploder->name ?? '' }} </td> <!-- Employee Name -->
                              @endif                    
                              <td>{{ $data->name ?? ''}}</td>
                              <td>{{ $data->email ?? ''}}</td>
                              <td>{{ $data->phone ?? ''}}</td>                      
                              
                              <td>
                                <?php $status = DB::table('status')->where('id', $data->status_id)->first(); ?>
                                <p class="mb-0">{{ $status->status_name }}</p>                              
                              </td>                       
                              <td>{{ $data->created_at ?? ''}}</td>                         
                           
                              <td class="actions">
                                <a href="{{ URL::to('lead-view',$data->id) }}" class="on-default edit-row"  onclick="editRecords({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View"><i class="fas fa-eye"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-edit',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-delete',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                              </td>
                        </tr>
                        @endforeach
                    </tbody> 
                    @elseif(Session::get('userRole') == 4)
                    <tbody>
                        @foreach($leads as $key => $data)
                        <?php 
                            $uploder = DB::table('users')->where('id', $data->upload_by)->first();
                            $whitelabel = DB::table('users')->where('id', $uploder->upload_by)->first();
                            $manager = DB::table('users')->where('id', $whitelabel->upload_by ?? '')->first();
                        ?>
                        <tr class="gradeX">
                            <td>{{ $key+1 }}</td>                       
                              
                              @if($uploder->users_role == 2)                                
                                <td>{{ $uploder->name ?? '' }}</td> <!-- White Label Name -->
                                <td> - </td> <!-- Manager Name -->
                                <td> - </td> <!-- Employee Name -->
                              @elseif($uploder->users_role == 3)                              
                                <td> {{ $whitelabel->name ?? ''}} </td> <!-- White Label Name -->
                                <td>{{ $uploder->name ?? '' }}</td> <!-- Manager Name -->
                                <td> - </td> <!-- Employee Name -->
                              @elseif($uploder->users_role == 4)

                                <!-- <td>{{ $manager->name ?? ''}}  </td>
                                <td>{{ $whitelabel->name ?? ''}}</td>
                                <td>{{ $uploder->name ?? ''}}</td> -->

                                <td>{{ $uploder->name ?? ''}}</td> <!-- Employee Name -->
                              @endif                             
                                                        
                              <td>{{ $data->name ?? ''}}</td>
                              <td>{{ $data->email ?? ''}}</td>
                              <td>{{ $data->phone ?? ''}}</td>                      
                              
                              <td>
                                <?php $status = DB::table('status')->where('id', $data->status_id)->first(); ?>
                                <p class="mb-0">{{ $status->status_name }}</p>                              
                              </td>                       
                              <td>{{ $data->created_at ?? ''}}</td>                         
                           
                            <td class="actions">
                                <a href="{{ URL::to('lead-view',$data->id) }}" class="on-default edit-row"  onclick="editRecords({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View"><i class="fas fa-eye"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-edit',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                                  &nbsp;&nbsp;&nbsp;

                                <a href="{{ URL::to('lead-delete',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody> 
                    @endif
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->

<!-- Modal content Start-->
 <!--  <div id="myModal" class="modal fade" role="dialog" style="padding-right: 0px">
        <div class="modal-dialog changepasswordmodal">
      <div class="modal-content">
                <div class="modal-header">
                  <h3>File upload</h3>
                  <button type="button" class="close" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                </div>
                <div class="modal-body">
                  <form class="form_outer form_inner mdt0 col-lg-12 col-md-12 col-sm-12 col-xs-12" method="POST" action="{{ URL::to('import-leads') }}" multipart="">
                  {{csrf_field()}}
                        <div class="row mdt20">
                          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <input type="file" class="form-control" id="oldpassword" placeholder="Old Password" name="file"/>
                          </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" id="submit" class="btn btn-primary" >Upload</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div> -->


    <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Upload File</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
          <form  action="{{ url('import-excel') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="ids" id="ids">
            <div class="modal-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <input  type="file" id="file" name="import_file" class="form-control" required="" aria-required="true" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"> 
                     </div>
                  </div>
                </div>
            </div>
            <div class="modal-footer">
               <button type="submit" id="submitbtn" class="btn btn-primary">Submit</button> 
               <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button> 
            </div>
          </form>
      </div>
    </div>
</div>

<script type="text/javascript">
   $('#whitelabel_id').change(function()
   {
      var whitelabel_ID = $(this).val();
      if(whitelabel_ID){
         $.ajax({
            type:"GET",
            url:"{{url('get-whitelabeldata/')}}"+'/'+whitelabel_ID, 
            success:function(res)
            {               
              if(res){
                $("#manager_id").empty();
                $("#manager_id").append('<option value="">-- Choose Manager --</option>');
                $.each(res,function(key,value){
                   $("#manager_id").append('<option value="'+value.id+'">'+value.name+'</option>');
                });
              }
              else{
                $("#manager_id").empty();
             }
            }
         });
      }
      else{
         $("#manager_id").empty();
      } 
   });

   $('#manager_id').change(function()
   {
      var manager_id = $(this).val();
      if(manager_id){
         $.ajax({
            type:"GET",
            url:"{{url('get-employee/')}}"+'/'+manager_id, 
            success:function(res)
            {               
               if(res){
                  $("#employee_id").empty();
                  $("#employee_id").append('<option value="">-- Choose Employee --</option>');
                  $.each(res,function(key,value){
                     $("#employee_id").append('<option value="'+value.id+'">'+value.name+'</option>');
                  });
               }
               else{
                  $("#employee_id").empty();
               }
            }
         });
      }
      else{
         $("#employee_id").empty();
      } 
   });
</script>

<script> 
   $(document).ready(function() { 

       $(function() { 
           $("#my_date_picker1").datepicker({}); 
       }); 

       $(function() { 
           $("#my_date_picker2").datepicker({}); 
       }); 

       $('#my_date_picker1').change(function() { 
           startDate = $(this).datepicker('getDate'); 
           $("#my_date_picker2").datepicker("option", "minDate", startDate); 
       }) 

       $('#my_date_picker2').change(function() { 
           endDate = $(this).datepicker('getDate'); 
           $("#my_date_picker1").datepicker("option", "maxDate", endDate); 
       }) 
   }) 
</script> 


<!-- <script type="text/javascript">
  function validateForm() {
  var x = document.forms["myForm"]["whitelabel_id"].value;
  var y = document.forms["myForm"]["manager_id"].value;
  var z = document.forms["myForm"]["employee_id"].value;
  if (x == "" || y == "" || z == "") {
    alert("");
    return false;
  }
}
</script> -->