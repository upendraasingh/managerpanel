<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Food Merchant User</h4>
            <!--<ol class="breadcrumb pull-right">
               <li><a href="{{ url('add-driver') }}" class="back_btn"><img src="https://162.241.87.160/duradrive/public/images/plus_icon.jpg" alt="plus_icon">Add New</a></li>
            </ol>-->
         </div>
      </div>
      <div class="search_part">
        <div class="row">
          <div class="col-md-7 col-sm-7">
            <form class="form-horizontal">
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-2 control-label">Search by :</label>
                <div class="col-sm-4">
                  <select class="form-control">
                    <option>Select Area</option>
                    <option>India</option>
                    <option>Australia</option>
                  </select>
                </div>
                <div class="col-sm-2">
                  <button class="search_button">Search</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card service_management">
               <div class="card-body">
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap management_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <th>Merchant Detail</th>
                           <th>Business Name</th>
                           <th>Country</th>
                           <th>City</th>
                           <th>Address</th>
                           <th>Password</th>
                           <th>Status</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($usredata as $key => $data)
                        <tr class="gradeX">
                           <td>{{ $key+1 }}</td>
                           <td>test</td>
                           <td>{{ $data->phone }}</td>
                           <td>{{ $data->name }}</td>
                           <td>{{ $data->email }}</td>
                           <td>{{ $data->phone }}</td>
                           <td>password</td>
                           <td>status</td>
                           <td class="actions">
                                
                                <a href="{{ URL::to('edit-country',$data->id)}}" class="on-default edit-row" data-toggle="tooltip" data-modal="modal-12" data-placement="top" data-original-title="Eye"><i class="fa fa-aye"></i></a> 
                                
                           </td>
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->


<script type="text/javascript">
  $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#datatable-responsive thead tr').clone(true).appendTo( '#datatable-responsive thead' );
      $('#datatable-responsive thead tr:eq(1) th').each( function (i) {
          var title = $(this).text();
          $(this).html( '<input type="text" placeholder=" '+title+'" />' );
   
          $( 'input', this ).on( 'keyup change', function () {
              if ( table.column(i).search() !== this.value ) {
                  table
                      .column(i)
                      .search( this.value )
                      .draw();
              }
          } );
      } );
   
      var table = $('#datatable-responsive').DataTable( {
          orderCellsTop: true,
          fixedHeader: true
      } );
  } );
</script>