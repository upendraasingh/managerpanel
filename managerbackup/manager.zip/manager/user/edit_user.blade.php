<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Edit White Label</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Edit White Label</li>
            </ol>
         </div>
      </div>
      <form action="{{ URL::to('add-user')}}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <a style="float: right;" href="{{ URL::to('get-transaction',$editdata->id)}}" target="_blank" class="btn btn-primary waves-effect waves-light"  data-toggle="tooltip" data-placement="top" title="" data-original-title="View">View Transaction</a>
                        </div> 
                     </div>
                     
                     <div class="col-md-12" style="text-align: center;">
                        <div class="form-group"> 
                           @if($editdata->profile_image!='')
                           <img style="border: 1px solid #eae3e3;" src="{{ asset('public/profile_image/').'/'.$editdata->profile_image }}" alt="image" width="100" height="100">
                           
                           @else
                           <img src="{{asset('public/no-image.jpg')}}" alt="Brand Image" height="100" width="100">
                           @endif
                           <input type="file" class="form-control" name="image" accept="image/x-png,image/gif,image/jpeg" >
                        </div>
                     </div>


                     <div class="row">
                        <input type="hidden" name="ids" id="ids" value="{{ $editdata->id ?? '' }}">
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Name : <font color="red">*</font></label>
                              <input  type="text" id="name" name="name" class="form-control" required="" value="{{ $editdata->name ?? '' }}" aria-required="true" placeholder="" autocomplete="off"> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Email : <font color="red">*</font></label>
                              <input  type="email" id="email" name="email" class="form-control" required="" value="{{ $editdata->email ?? ''}}" aria-required="true"> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label"> Phone : <font color="red">*</font></label>
                              <input  type="text" id="phone" name="phone" class="form-control" required="" value="{{ $editdata->phone ?? ''}}" aria-required="true" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" maxlength="10" title="phone"> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $Country = DB::table('country')->get(); ?>
                              <label class="control-label">Country : <font color="red">*</font></label>
                              <select class="form-control" id="country_id" name="country_id" required="">
                                 <option value="">-- Choose Country --</option>
                                 @foreach($Country as $data)
                                 <option value="{{ $data->id }}" {{ ($data->id == $editdata->country_id) ? "selected" : "" }}>{{ $data->country_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Address : <font color="red">*</font></label>
                              <input type="text" id="address" name="address" value="{{ $editdata->address }}" class="form-control" aria-required="true" maxlength="100" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <p class="control-label"><b>Status : </b> <font color="red">*</font></p>
                              <div class="radio radio-info form-check-inline">
                                 <input type="radio" id="active" value="0" name="status" checked="">
                                 <label for="inlineRadio1"> Active </label>
                              </div>
                              <div class="radio radio-info form-check-inline">
                                 <input type="radio" id="inactive" value="1" name="status">
                                 <label for="inlineRadio1"> Inactive </label>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">  
                              <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Password Change</a>
                           </div>
                        </div>
                     </div>                      
                                                                                 
                  <div class="modal-footer">
                     <button type="submit" id="submitbtn" class="btn btn-primary">Update</button>
                  </div>
               </div><!-- End card-body -->
            </div> <!-- End card -->
         </form><!-- Form End -->
      </div><!-- container -->
   </div>

<!--- MODEL CALL--->
<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Password Change</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form  action="{{ url('change-password') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
               <div class="row">
                  <input type="hidden" name="editId" value="{{ $editdata->id }}">
                  <div class="col-md-12">
                     <div class="form-group">
                        <p class="control-label"><b>New password :</b> <font color="red">*</font></p>
                        <input type="password" id="new_password" name="password" class="form-control" required="" aria-required="true">
                        <input type="checkbox" onclick="myFunction2()"> Show Password 
                     </div>
                  </div>
                  <div class="col-md-12">
                     <div class="form-group">
                        <p class="control-label"><b>Confirm password :</b> <font color="red">*</font></p>
                        <input type="password" id="password" name="password" onchange="check_password()" class="form-control" required="" aria-required="true">
                        <input type="checkbox" onclick="myFunction3()"> Show Confirm Password 
                     </div>
                  </div>                
               </div>
            </div>
            <div class="modal-footer"> 
               <button type="submit" onsubmit="check_password" id="submitbtn" class="btn btn-primary">Update</button>
               <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>                
            </div>
         </form>
      </div>
   </div>
</div>
<!-- /.modal eND -->

<script type="text/javascript">
   function myFunction2() {
     var x = document.getElementById("new_password");
     if (x.type === "password") {
       x.type = "text";
     } else {
       x.type = "password";
     }
   }
</script>

<script type="text/javascript">
   function myFunction3() {
     var x = document.getElementById("password");
     if (x.type === "password") {
       x.type = "text";
     } else {
       x.type = "password";
     }
   }
</script>

<!-- Password & Confirm passeword mach script -->
 <script type="text/javascript">
   function check_password()
   {
      if($('#new_password').val() != $('#password').val()) {
         alert("Password and Confirm Password don't match");
         event.preventDefault();

         $("#password").val('');    
         $("#password").focus();
      }  
   }
</script>
