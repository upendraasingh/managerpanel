<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Vehicle Model Management</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="https://162.241.87.160/duradrive/public/images/back_arrow.jpg" alt="back_arrow">Back</a></li>
            </ol>
         </div>
      </div>
      <div class="add_country_heading">
         <div class="row">
            <div class="col-md-12 col-sm-12">
               <h3>Edit Vehicle Model</h3>
            </div>
         </div>
      </div>
      <form  action="{{ URL::to('add-banners') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card country_management">
                  <div class="card-body">
                     <div class="row"> 
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                           <?php $whitelabel = DB::table('users')->where('users_role', 2)->get(); ?>
                              <label class="control-label">Vehicle Type<font color="red">*</font></label>
                              <select class="form-control" id="upload_by" name="upload_by" required="">
                                     <option value="">Select Services</option>
                                     @foreach($whitelabel as $value)
                                     <option value="{{ $value->id }}">{{ $value->name }}</option>
                                     @endforeach
                                  </select>
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Vehicle Make<font color="red">*</font></label>
                              <select class="form-control" id="upload_by" name="upload_by" required="">
                                     <option value="">Vehicle Make</option>
                                     @foreach($whitelabel as $value)
                                     <option value="{{ $value->id }}">{{ $value->name }}</option>
                                     @endforeach
                                  </select>
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Vehicle Model<font color="red">*</font></label>
                              <select class="form-control" id="upload_by" name="upload_by" required="">
                                     <option value="">Vehicle Model</option>
                                     @foreach($whitelabel as $value)
                                     <option value="{{ $value->id }}">{{ $value->name }}</option>
                                     @endforeach
                                  </select>
                           </div>
                        </div>
                            
                            
                        </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                               <div class="form-group">
                                    <label class="control-label">No. of seats<font color="red">*</font></label>
                                    <input type="number" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                               </div>
                            </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-8 col-sm-4">
                                   <div class="form-group">
                                       <label class="control-label">Description<font color="red">*</font></label>
                                       <textarea class="form-control" id="upload_by" name="upload_by" required=""  rows="5" cols="50" placeholder="Write Description"></textarea>
                                   </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Available For ride now<font color="red">*</font></label>
                              <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Available For ride later<font color="red">*</font></label>
                              <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                           </div>
                        </div>
                            </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn cancel_btn">Cancel</button>
                       <button type="submit" id="submitbtn" class="btn save_btn">Save & Add</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
