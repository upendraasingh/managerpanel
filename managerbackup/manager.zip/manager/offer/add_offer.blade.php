<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Add Market Place</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Add Offer</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-offer') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">                       
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Name : <font color="red">*</font></label>
                              <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="30" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="control-label">Type : <font color="red">*</font></label>
                              <select class="form-control" id="type" name="type" required="">
                                 <option value="0">-- Choose Type --</option>
                                 <option value="P">Percentage</option>
                                 <option value="F">Flat</option>                                 
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Offer Value : <font color="red">*</font></label>
                              <input type="text" id="value" name="value" class="form-control" aria-required="true" maxlength="10" required=""> 
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Per user : <font color="red">*</font></label>
                              <input type="text" id="peruser" name="peruser" class="form-control" aria-required="true" maxlength="100" required=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Start Date : <font color="red">*</font></label>
                              <input type="text" id="datepicker" name="start_from" class="form-control" aria-required="true" required="" readonly=""> 
                           </div>
                        </div> 
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">End Date : <font color="red">*</font></label>
                              <input type="text" id="datepicker2" name="end_to" class="form-control" aria-required="true" required="" readonly=""> 
                           </div>
                        </div> 
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="control-label">Status : <font color="red">*</font></label>
                              <select class="form-control" id="status" name="status" required="">
                                 <option value="">-- Choose Status --</option>
                                 <option value="1">Active</option>
                                 <option value="0">Deactive</option>                                 
                              </select>
                           </div>
                        </div> 
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Save</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
