<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">View Market Place</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">View Market Place</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-offer') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                     </div>
                     <div class="row">

                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Name : <font color="red">*</font></label>
                              <input type="text" value="{{ $editoffer->name }}" name="name" class="form-control" aria-required="true" maxlength="25"  autocomplete="off" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                           <div class="form-group">
                              <label class="control-label">Type : <font color="red">*</font></label>
                              <select class="form-control" id="type" name="type" autocomplete="off" readonly="" disabled="">
                                 <option value="0">-- Choose Type --</option>
                                 <option @if($editoffer->type=='P') selected @endif value="P">Percentage</option>
                                 <option @if($editoffer->type=='F') selected @endif value="F">Flat</option>                                 
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Offer Value : <font color="red">*</font></label>
                              <input type="text" id="value" name="value" value="{{ $editoffer->value }}"  class="form-control" aria-required="true" maxlength="10"  autocomplete="off" readonly=""> 
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Per user : <font color="red">*</font></label>
                              <input type="text" id="peruser" name="peruser" value="{{ $editoffer->peruser }}" class="form-control" aria-required="true" maxlength="100"  autocomplete="off" readonly=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Start Date : <font color="red">*</font></label>
                              <input type="text" id="datepicker" disabled="" name="start_from" value="{{ $editoffer->start_from }}" class="form-control" aria-required="true"  autocomplete="off" readonly=""> 
                           </div>
                        </div> 
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">End Date : <font color="red">*</font></label>
                              <input type="text" id="datepicker2" disabled="" name="end_to" value="{{ $editoffer->end_to }}" class="form-control" aria-required="true"  autocomplete="off" readonly=""> 
                           </div>
                        </div> 
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="control-label">Status : <font color="red">*</font></label>
                              <select class="form-control" id="status" name="status" autocomplete="off" readonly=""  disabled="">
                                 <option value="">-- Choose Status --</option>
                                 <option @if($editoffer->status=='1') selected @endif value="1">Active</option>
                                 <option @if($editoffer->status=='0') selected @endif value="0">Deactive</option>                                 
                              </select>
                           </div>
                        </div>            
                     </div>                 
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>

<script type="text/javascript">
   $(".chosen-select").chosen({
      no_results_text: "Oops, nothing found!"
   })
</script>
<!-- Script for datepicker -->
<script type="text/javascript">
   $(function()
   {
      $('.date-pick').datePicker()
      $('#dt1').bind(
         'dpClosed',
         function(e, selectedDates)
         {
            var d = selectedDates[0];
            if (d) {
               d = new Date(d);
               $('#dt2').dpSetStartDate(d.addDays(1).asString());
            }
         }
      );
      $('#dt2').bind(
         'dpClosed',
         function(e, selectedDates)
         {
            var d = selectedDates[0];
            if (d) {
               d = new Date(d);
               $('#dt1').dpSetEndDate(d.addDays(-1).asString());
            }
         }
      );
   });
</script>


<script type="text/javascript">
   $('#ServiceId').change(function()
   {
      var service_cat_id = $(this).val();
      if(service_cat_id)
      {
         $.ajax({
            type:"GET",
            url:"{{url('get-servicecategory/')}}"+'/'+service_cat_id, 
            success:function(res)
            {               
               if(res)
                {
                  $("#home_cat_id").empty();
                  $("#home_cat_id").append('<option>-- Choose Service Category --</option>');
                  $.each(res,function(key,value){
                     $("#home_cat_id").append('<option value="'+value.Id+'">'+value.Name+'</option>');
                  });
                }
               else{
                  $("#home_cat_id").empty();
               }
            }
         });
      }
      else{
         $("#home_cat_id").empty();
      } 
   });
/* script for activity */
   $('#home_cat_id').change(function()
   {
      var service_cat_id = $(this).val();
      if(service_cat_id)
      {
         $.ajax({
            type:"GET",
            url:"{{ url('get-service-activity/') }}"+'/'+service_cat_id, 
            success:function(res)
            {  
               console.log(res);
               if(res){
                  $("#activity_id").empty();
                  $("#activity_id").append('<option>-- Choose Service Activity --</option>');
                  $.each(res,function(key,value){
                     $("#activity_id").append('<option value="'+value.Id+'">'+value.Name+'</option>');
                  });
               }
               else{
                  $("#activity_id").empty();
               }
            }
         });
      }
      else{
        $("#activity_id").empty();
      }
   });
</script>

<script type="text/javascript">
   function myFunction2() {
     var x = document.getElementById("new_password");
     if (x.type === "password") {
       x.type = "text";
     } else {
       x.type = "password";
     }
   }
</script>

<script type="text/javascript">
   function myFunction3() {
     var x = document.getElementById("password");
     if (x.type === "password") {
       x.type = "text";
     } else {
       x.type = "password";
     }
   }
</script>

<!-- Password & Confirm passeword mach script -->
 <script type="text/javascript">
   function check_password()
   {
      if($('#new_password').val() != $('#password').val()) {
         alert("Password and Confirm Password don't match");
         event.preventDefault();

         $("#password").val('');    
         $("#password").focus();
      }  
   }
</script>
