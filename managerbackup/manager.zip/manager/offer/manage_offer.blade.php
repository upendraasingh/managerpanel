<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Marketplace</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Marketplace</li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">                  
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                            <th>Sr.No.</th>                          
                            <th>Client Name</th>
                            <th>ID N0</th>                             
                            <th>Product</th> 
                            <th>Purchase Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($marketplace as $key => $data)  
                            <tr class="gradeX">                         
                                <td>{{ ++$key }}</td>
                                <?php 
                                 $client = DB::table('users')->where('id', $data->user_id)->first();
                                 $product = DB::table('product')->where('id', $data->watch_id)->first();
                                ?>
                                <td id="clientname{{$data->id}}">{{ $client->name }}</td>
                                <td id="idno{{$data->id}}">{{ $product->id_no ?? ''}}</td>
                                <td id="modelname{{$data->id}}">{{ $product->model_name }}</td>
                                <input type="hidden" id="watchprice{{$data->id}}" value="{{ $product->price }}"> 
                                <input type="hidden" id="client_id{{$data->id}}" value="{{ $data->user_id }}">
                                <input type="hidden" id="watch_id{{$data->id}}" value="{{ $data->watch_id }}"> 
                                @php $date = new DateTime($data->created_at);@endphp

                                <td>{{ $date->format('d-m-Y') }}</td>  
                                <td class="actions">
                                    <a href="javascript:void(0);" class="on-default edit-row"  onclick="addaoffer({{ $data->id }})" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="add a offer"><i class="fa fa-plus"></i></a> 
                                    &nbsp;&nbsp;&nbsp;

                                    <a href="{{URL::to('view-watch-offer',$data->watch_id)}}" class="on-default edit-row"data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="view offer"><i class="fas fa-eye"></i></a> 
                                    &nbsp;&nbsp;&nbsp;

                                    <!-- <a href="{{ URL::to('delete-product',$data->id) }}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a> -->
                                </td>                             
                            </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div><!-- end card-body -->
            </div>
         </div><!-- container -->
      </div>
   </div>
</div>
<!-- content -->
<div id="Addoffer" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title mt-0">Add a Offer</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <!-- {{ url('add-offer') }} -->
            <form  action="{{ url('add-offer') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
            @csrf
            <?php
                $country = DB::table('country')->get();
            ?>
            <input type="hidden" name="ids" id="ids">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Client</label>
                            <input type="text" id="client" name="client" class="form-control" readonly="">
                            <input type="hidden" id="client_idform" name="client_idform">
                            <input type="hidden" id="watch_idform" name="watch_idform"> 
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Watch ID</label>
                            <input type="text" id="idnoform" name="idnoform" class="form-control" readonly=""> 
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Modal</label>
                            <input type="text" id="modalform" name="modalform" class="form-control" readonly=""> 
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Price to Buy($)</label>
                            <input type="text" id="priceform" name="priceform" class="form-control" readonly=""> 
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Country</label>
                            <select id="country" name="country" class="form-control">
                                @foreach($country as $co)
                                    <option value="{{$co->country_name}}">{{$co->country_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Offer Type</label>
                            <select id="offertype" name="offertype" class="form-control" onchange="selectPurchasetype();">
                                <option value="">Select OfferType</option>
                                <option value="percentage">Percentage</option>
                                <option value="amount">Amount</option>
                            </select> 
                        </div>
                    </div> 
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Offer</label>
                            <input type="text" id="offer" name="offer" class="form-control"> 
                        </div>
                    </div>
                    <div class="col-md-6" style="display:none;" id="pricecalculated">
                        <div class="form-group">
                            <label>Calculated Price</label>
                            <input type="text" id="calculatedprice" name="calculatedprice" class="form-control"> 
                        </div>
                    </div>                
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" id="submitbtn" class="btn btn-primary">Add offer</button> 
                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button> 
            </div>
            </form>
      </div>
    </div>
</div>
<script type="text/javascript">
    $("#checkAll").click(function () {
        $('input:checkbox').not(this).prop('checked', this.checked);
    });
</script>

<script type="text/javascript">
    function addaoffer(id)
    {  
        var clientname  = $('#clientname'+id).text();
        var idno        = $('#idno'+id).text();
        var modelname   = $('#modelname'+id).text(); 
        var watchprice  = $('#watchprice'+id).val();  
        var client_id   = $('#client_id'+id).val(); 
        var watch_id    = $('#watch_id'+id).val();        
        $('#client').val(clientname);
        $('#client_idform').val(client_id);
        $('#watch_idform').val(watch_id);
        $('#idnoform').val(idno);
        $('#modalform').val(modelname);
        $('#priceform').val(watchprice);
        $('#ids').val(id);
        $('#Addoffer').modal('show');
    }
    function selectPurchasetype()
    {
        var offertype = $('#offertype').val();
        if(offertype=='percentage'){
            $('#pricecalculated').show();
        }else{
            $('#pricecalculated').hide();
        }
        
    }
        
    $(document).on("keypress keyup change", "#offer", function() {
        $('#calculatedprice').val();
        var main    = $('#priceform').val();
        var disc    = $('#offer').val();
        var res     = disc.length;
        var calres  = disc.substring(1, 3);

        if(calres.length>=2){
            var specialchar  = disc.substring(0, 1);            
            var mult = (main/100)*calres;
            if(specialchar=='+'){
                var discont = parseFloat(main) + parseFloat(mult);
            }   else{
                var discont = parseFloat(main) - parseFloat(mult);
            }
            
            $('#calculatedprice').val(discont);
        }
    });    
    $(document).ready(function() {
        $('[data-toggle="popover"]').popover({
           placement: 'top',
           trigger: 'hover'
        });
    });
    
</script>
