<?php //echo "hi";die;
   use App\User;
   $sessionId =  Session::get('gorgID');
   $users = DB::table('users')->where('id', $sessionId)->first();
?>

<link href="{{ asset('public/assets/css/page_css/home.css') }}" rel="stylesheet" type="text/css" />
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <div class="">
         <div class="">
            <!-- Page-Title -->
            <div class="row">
               <div class="col-sm-12">
                  <h3 class="pull-left page-title">Welcome, {{ $users->name ?? ''}}.!</h3>
                  <ol class="breadcrumb pull-right">
                     <li><a href="#">Manager</a></li>
                     <li class="active">Dashboard</li>
                  </ol>
               </div>
            </div>
            <div class="row dashboard_boxes">
               @if(Session::get('userRole') == 1)
               <!-- White Labels  -->
               <div class="col-md-6 col-xl-6">
                  <a href="#">
                     <div class="mini-stat clearfix bg-success bx-shadow" style="justify-content: left;background:#28a745 !important;">
                        <span class="mini-stat-icon"><i class="fa fa-users"></i></span>
                        <div class="mini-stat-info">
                           <h3 style="color:white;">Sales</h3>
                        </div>
                        <div class="mini-stat-info" style="justify-content: right;padding-left: 50%;">
                           <span class="counter"  style="color:white;">${{ $whitelabel ?? ''}}</span>
                        </div>
                     </div>
                  </a>
               </div>
               <!-- Managers  -->
               <div class="col-md-6 col-xl-6">
                  <a href="#">
                     <div class="mini-stat clearfix bg-danger bx-shadow" style="justify-content: left;background:#ffb509ad !important;">
                        <span class="mini-stat-icon"><i class="fa fa-users"></i></span>
                        <div class="mini-stat-info">
                           <h3  style="color:white;">Orders</h3>
                        </div>
                        <div class="mini-stat-info" style="justify-content: right;padding-left: 50%;">
                           <span class="counter" style="color:white;">${{ $whitelabel ?? ''}}</span>
                        </div>
                     </div>
                  </a>
               </div>
                <!-- Employees  -->
               <div class="col-md-6 col-xl-6">
                  <a href="#">
                     <div class="mini-stat clearfix bg-success bx-shadow" style="justify-content: left;background:#28a745 !important;">
                        <span class="mini-stat-icon"><i class="fa fa-users"></i></span>
                        <div class="mini-stat-info">
                           <h3 style="color:white;">Sales</h3>
                        </div>
                        <div class="mini-stat-info" style="justify-content: right;padding-left: 50%;">
                           <span class="counter"  style="color:white;">${{ $whitelabel ?? ''}}</span>
                        </div>
                     </div>
                  </a>
               </div>
               <!-- Managers  -->
               <div class="col-md-6 col-xl-6">
                  <a href="#">
                     <div class="mini-stat clearfix bg-danger bx-shadow" style="justify-content: left;background:#ffb509ad !important;">
                        <span class="mini-stat-icon"><i class="fa fa-users"></i></span>
                        <div class="mini-stat-info">
                           <h3  style="color:white;">Orders</h3>
                        </div>
                        <div class="mini-stat-info" style="justify-content: right;padding-left: 50%;">
                           <span class="counter" style="color:white;">${{ $whitelabel ?? ''}}</span>
                        </div>
                     </div>
                  </a>
               </div>
                <!-- Clients  -->
                <?php 
                    $client = User::where('users_role', 5)->get();
                    
                    $onlie = User::where('logged_in', 1)->count();
                    foreach ($client as $key => $value) {
                        $activeuser1[] = User::isOnline($value->id);                    
                    }
                    //dd($activeuser1);
                    //$onlie = count($activeuser1);
                    /*dd($onlie);*/
                    /* print_r($onlie); die;*/
                ?>
               <!-- online Clients -->
               <div class="col-md-6 col-xl-6">
                  <a href="#">
                     <div class="mini-stat clearfix bg-success bx-shadow" style="justify-content: left;background:#28a745 !important;">
                        <span class="mini-stat-icon"><i class="fa fa-users"></i></span>
                        <div class="mini-stat-info">
                           <h3 style="color:white;">Sales</h3>
                        </div>
                        <div class="mini-stat-info" style="justify-content: right;padding-left: 50%;">
                           <span class="counter"  style="color:white;">${{ $whitelabel ?? ''}}</span>
                        </div>
                     </div>
                  </a>
               </div>
               <!-- Managers  -->
               <div class="col-md-6 col-xl-6">
                  <a href="#">
                     <div class="mini-stat clearfix bg-danger bx-shadow" style="justify-content: left;background:#ffb509ad !important;">
                        <span class="mini-stat-icon"><i class="fa fa-users"></i></span>
                        <div class="mini-stat-info">
                           <h3  style="color:white;">Orders</h3>
                        </div>
                        <div class="mini-stat-info" style="justify-content: right;padding-left: 50%;">
                           <span class="counter" style="color:white;">${{ $whitelabel ?? ''}}</span>
                        </div>
                     </div>
                  </a>
               </div>
               @endif
            </div>
            <!-- Report status -->
            <div class="row">
               <div class="col-md-12">
            <div class="card service_management">
               <div class="card-body">
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap management_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Driver ID</th>
                           <th>Driver Name</th>
                           <th>Mobile NO</th>
                           <th>Email </th>
                           <th>Status</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $categorydata = DB::table('driveuser')->where('isactive', 1)->get(); ?>
                        @foreach($categorydata as $key => $data)
                        <?php $driver_vehicle = DB::table('driver_vehicle')->where('driver_id', $data->id)->first(); ?>
                        <tr class="gradeX">
                           <td>{{ $key+1 }}</td>
                           <td>{{ $data->firstname }}</td>
                           <td>{{ $data->mobile }}</td>
                           <td>{{ $data->email }}</td>
                           @if($data->isactive == 1)
                           <td>
                              <p class="mb-0">
                                 <span class="badge badge-success">Active</span>
                              </p>
                           </td>
                           @else
                           <td>
                              <p class="mb-0">
                                 <span class="badge badge-danger">Inactive</span>
                              </p>
                           </td>
                           @endif
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
            </div>
            <!-- End status -->
         </div>
      </div>
   </div>
</div>