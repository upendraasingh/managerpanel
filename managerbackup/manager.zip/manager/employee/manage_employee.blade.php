<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Manage Employee </h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Manage Employee </li>
            </ol>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                 
                  <form  action="{{ URL::to('filter-employee') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                    <?php 
                        $whitelabel_id = $whitelabel_id ?? '';
                        $manager_id = $manager_id ?? '';
                        if (session::get('userRole') == 1) {
                           $whitelabel = DB::table('users')->where('users_role', 2)->orderBy('name', 'asc')->get(); 
                           $manager = DB::table('users')->where('users_role', 3)->orderBy('name', 'asc')->get(); 
                        }else {
                           $manager = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 3)->orderBy('name', 'asc')->get(); 
                        }
                     ?>
                     @if(session::get('userRole') == 1 || session::get('userRole') == 2)
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        @if($whitelabel_id)
                        <a href="{{URL::to('view-employee')}}">
                          <h3><i class="icon-filter icon-stack-base"></i>
                              <i class="icon-remove"></i> Filter
                          </h3>
                        </a>
                        @else
                          <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                        @endif
                     </div>                     
                     <hr>
                     @endif
                     @if(session::get('userRole') == 1)
                     <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="whitelabel_id" id="whitelabel_id" class="form-control" required="">
                             <option value="">-- Select White Label --</option>
                              @foreach($whitelabel as $data)
                                <option value="{{ $data->id }}" {{($data->id == $whitelabel_id ) ? "selected" : ""}}>{{ $data->name }}</option>
                              @endforeach
                          </select>
                        </div>
                     </div>
                     @endif
                     @if(session::get('userRole') == 1 || session::get('userRole') == 2) 
                      <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="manager_id" id="manager_id" class="form-control" required="">
                             <option value="">-- Select Manager --</option>
                              @foreach($manager as $data)
                                <option value="{{ $data->id }}" {{($data->id == $manager_id ) ? "selected" : ""}}>{{ $data->name }}</option>
                              @endforeach
                          </select>
                        </div>
                     </div>                      
                    @endif
                    @if(session::get('userRole') == 1 || session::get('userRole') == 2) 
                     <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                       <a href="{{URL::to('view-employee')}}" class="btn btn-primary">Refresh</a>
                     </div>
                     <hr>
                     @endif

                  </div>
               </form>
               
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr.No.</th>
                           @if(Session::get('userRole') == 1)
                           <th>White Label</th>
                           <th>Manager</th>
                           @elseif(Session::get('userRole') == 2)
                           <th>Manager</th>
                           @endif
                           <th>Employee Name</th>
                           <th>Email</th>
                           <th>Phone</th>
                           <th>Image</th>
                           <th>Gender</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($employee as $key => $data)
                        <?php 
                           $uploder = DB::table('users')->where('id', $data->upload_by ?? '')->first();
                           $whitelabel = DB::table('users')->where('id', $uploder->upload_by ?? '')->first();
                        ?>
                        @if($data->upload_by!='')
                        <tr class="gradeX">
                           <td>{{ $key+1 }}</td>
                           @if(Session::get('userRole') == 1)
                           <td>
                              {{ $whitelabel->name ?? '' }}
                           </td>
                           <td>{{ $uploder->name ?? ''}}</td>
                           @elseif(Session::get('userRole') == 2)
                           <td>{{ $uploder->name ?? ''}}</td>
                           @endif
                           <td>{{ $data->name ?? ''}}</td>
                           <td>{{ $data->email }}</td>
                           <td>{{ $data->phone }}</td>
                           <td>
                              @if($data->profile_image!='')
                              <a href="{{asset('public/profile_image/').'/'.$data->profile_image}}" target="_blank">
                              <img src="{{asset('public/profile_image/').'/'.$data->profile_image}}" alt="profile Image" height="50" width="50"> 
                              </a>
                              @else
                              <img src="{{asset('public/no-image.jpg')}}" alt="Brand Image" height="50" width="50">
                              @endif
                           </td>
                           @if($data->gender == 0)
                           <td>
                              <p class="mb-0">
                                 Male
                              </p>
                           </td>
                           @else
                           <td>
                              <p class="mb-0">
                                 Female
                              </p>
                           </td>
                           @endif
                           <td class="actions">
                              <a href="{{ URL::to('edit-employee',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i></a> 
                              &nbsp;&nbsp;&nbsp;
                              <a href="{{ URL::to('delete-user',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                           </td>
                        </tr>
                        @endif
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->


<!-- Get manager -->
<script type="text/javascript">
   $('#whitelabel_id').change(function()
   {
      var whitelabel_ID = $(this).val();
      if(whitelabel_ID){
         $.ajax({
            type:"GET",
            url:"{{url('get-whitelabeldata/')}}"+'/'+whitelabel_ID, 
            success:function(res)
            {               
               if(res){
                  $("#manager_id").empty();
                  $("#manager_id").append('<option value="">-- Choose Manager --</option>');
                  $.each(res,function(key,value){
                     $("#manager_id").append('<option value="'+value.id+'">'+value.name+'</option>');
                  });
               }
               else{
                  $("#manager_id").empty();
               }
            }
         });
      }
      else{
         $("#manager_id").empty();
      } 
   });
</script>