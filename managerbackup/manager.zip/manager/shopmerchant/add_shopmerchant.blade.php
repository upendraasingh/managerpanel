<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Shop Merchant Management</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="https://162.241.87.160/duradrive/public/images/back_arrow.jpg" alt="back_arrow">Back</a></li>
            </ol>
         </div>
      </div>
      <div class="add_country_heading">
         <div class="row">
            <div class="col-md-12 col-sm-12">
               <h3>Add Shop Merchant</h3>
            </div>
         </div>
      </div>
      <form  action="{{ URL::to('add-banners') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card country_management">
                  <div class="card-body">
                     <div class="row"> 
                        <div class="col-md-12">
                            <b>Business Information</b><br><br><br>
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Business Name<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Email Address<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Password<font color="red">*</font></label>
                                    <input type="password" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Phone Number<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Business Logo<font color="red">*</font></label>
                                    <input type="file" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <b>Local Information</b><br><br><br>
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Country<font color="red">*</font></label>
                                    <select>
                                        <option>Select Country</option>
                                        <option></option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Area<font color="red">*</font></label>
                                    <select>
                                        <option>Select Area</option>
                                        <option></option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Landmark<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Address<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Latitude<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Longitude<font color="red">*</font></label>
                                    <input type="password" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <b>Opening Details</b><br><br><br>
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Average Price<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Delivery Time<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Commission<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <label class="control-label">See week Days<font color="red">*</font></label>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Sun</label>
                                </div>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Mon</label>
                                </div>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Tue</label>
                                </div>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Wed</label>
                                </div>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Thu</label>
                                </div>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Fri</label>
                                </div>
                                <div class="col-md-1 col-sm-1">
                                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                        <label for="vehicle1"> Sat</label>
                                </div>
                            </div>
                        </div><br><br><br>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Opening Time<font color="red">*</font></label>
                                    <input type="time" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Closing Time<font color="red">*</font></label>
                                    <input type="time" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <b>Bank Details</b><br><br><br>
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Bank Name<font color="red">*</font></label>
                                    <select>
                                        <option>Select Name</option>
                                        <option></option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Landmark<font color="red">*</font></label>
                                    <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Service City<font color="red">*</font></label>
                                    <select>
                                        <option>Select City</option>
                                        <option></option>
                                    </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">  
                                    <label class="control-label">Bank Branch<font color="red">*</font></label>
                                    <select>
                                        <option>Select Branch</option>
                                        <option></option>
                                    </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn cancel_btn">Cancel</button>
                       <button type="submit" id="submitbtn" class="btn save_btn">Save & Add</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
