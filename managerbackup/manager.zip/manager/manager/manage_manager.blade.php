
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Country Management</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ url('add-country') }}" class="back_btn"><img src="https://162.241.87.160/duradrive/public/images/plus_icon.jpg" alt="plus_icon">Add New</a></li>
            </ol>
         </div>
      </div>
      <div class="search_part">
        <div class="row">
          <div class="col-md-7 col-sm-7">
            <form class="form-horizontal">
              <div class="form-group row">
                  <?php $Country = DB::table('country')->get(); ?>
                <label for="inputEmail3" class="col-sm-2 control-label">Search by :</label>
                <div class="col-sm-4">
                    <select class="form-control" id="searchcountry_id" name="searchcountry_id">
                        <option value="">-- Choose Country --</option>
                        @foreach($Country as $data)
                        <option value="{{ $data->id }}">{{ $data->country_name }}</option>
                        @endforeach
                    </select>
                </div>
                <!--<div class="col-sm-4">
                  <select class="form-control">
                    <option>Select Area</option>
                    <option>Noida</option>
                    <option>Delhi</option>
                  </select>
                </div>-->
                <div class="col-sm-2">
                  <button class="search_button">Search</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card service_management">
               <div class="card-body">
                @if(Session::get('userRole') == 1)
                  <!--<form  action="{{ URL::to('filter-manager') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
                  @csrf
                  <div class="row">
                    <?php 
                      $whitelabel_id = $whitelabel_id ?? '';
                      $whitelabel = DB::table('users')->where('users_role', 2)->get(); 
                    ?>
                     @if(session::get('userRole') == 1)
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        @if($whitelabel_id)
                        <a href="{{URL::to('view-manager')}}">
                          <h3><i class="icon-filter icon-stack-base"></i>
                              <i class="icon-remove"></i> Filter
                          </h3>
                        </a>
                        @else
                          <h3><i class="fa fa-filter" aria-hidden="true"></i> Filter :</h3>
                        @endif
                     </div>
                     @endif
                     <hr>
                     <div class="col-md-3 col-sm-3 col-xs-3">
                        <div class="form-group">  
                          <select name="whitelabel_id" id="whitelabel_id" class="form-control">
                             <option value="">-- Select White Label --</option>
                              @foreach($whitelabel as $data)
                                <option value="{{ $data->id }}" {{($data->id == $whitelabel_id ) ? "selected" : ""}}>{{ $data->name }}</option>
                              @endforeach
                          </select>
                        </div>
                     </div>                      
                    
                     <div class="col-md-3 col-sm-3 col-xs-3">
                       <button type="submit" id="submitbtn" class="btn btn-primary">Search</button>
                       <a href="{{URL::to('view-manager')}}" class="btn btn-primary">Refresh</a>
                     </div>
                  </div>
               </form>-->
               @endif
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap management_table" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           @if(Session::get('userRole') == 1)
                           <th>Country</th>
                           @endif
                           <th>Area</th>
                           <th>Area Type</th>
                           <th>Bill Period</th>
                           <th>Driver's Doc.</th>
                           <th>Vehicle Doc.</th>
                           <th>Available Service</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($manager as $key => $data)
                        <tr class="gradeX">
                           <td>{{ $key+1 }}</td>
                            @if(Session::get('userRole') == 1)
                           <td>
                             <?php $uploder = DB::table('users')->where('id', $data->upload_by)->first(); ?>
                              {{ $uploder->name ?? ''}}
                           </td>
                           @endif
                           <td>{{ $data->name }}</td>
                           <td>{{ $data->email }}</td>
                           <td>{{ $data->phone }}</td>
                           <td>
                              @if($data->profile_image!='')
                              <a href="{{asset('public/profile_image/').'/'.$data->profile_image}}" target="_blank">
                              <img src="{{asset('public/profile_image/').'/'.$data->profile_image}}" alt="profile Image" height="50" width="50"> 
                              </a>
                              @else
                              <img src="{{asset('public/no-image.jpg')}}" alt="Brand Image" height="50" width="50">
                              @endif
                           </td>
                           @if($data->gender == 0)
                           <td>
                              <p class="mb-0">
                                 Male
                              </p>
                           </td>
                           @else
                           <td>
                              <p class="mb-0">
                                 Female
                              </p>
                           </td>
                           @endif
                           <td class="actions">
                                <a href="{{ URL::to('edit-country',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="Eye"><i class="fa fa-eye"></i></a> 
                                &nbsp;&nbsp;&nbsp;
                                <a href="{{ URL::to('edit-country',$data->id)}}" class="on-default edit-row"  data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="edit"><i class="fa fa-edit"></i></a> 
                                &nbsp;&nbsp;&nbsp;
                                <a href="{{ URL::to('delete-user',$data->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a>
                           </td>
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
               <!-- end card-body -->
            </div>
         </div>
         <!-- container -->
      </div>
   </div>
</div>
<!-- content -->


<script type="text/javascript">
  $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#datatable-responsive thead tr').clone(true).appendTo( '#datatable-responsive thead' );
      $('#datatable-responsive thead tr:eq(1) th').each( function (i) {
          var title = $(this).text();
          $(this).html( '<input type="text" placeholder=" '+title+'" />' );
   
          $( 'input', this ).on( 'keyup change', function () {
              if ( table.column(i).search() !== this.value ) {
                  table
                      .column(i)
                      .search( this.value )
                      .draw();
              }
          } );
      } );
   
      var table = $('#datatable-responsive').DataTable( {
          orderCellsTop: true,
          fixedHeader: true
      } );
  } );
</script>