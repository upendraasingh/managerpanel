<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Service Area Management</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="#" onclick="window.history.go(-1); return false;" class="back_btn"><img src="https://162.241.87.160/duradrive/public/images/back_arrow.jpg" alt="back_arrow">Back</a></li>
            </ol>
         </div>
      </div>
      <div class="add_country_heading">
         <div class="row">
            <div class="col-md-12 col-sm-12">
               <h3>Add Service Area</h3>
            </div>
         </div>
      </div>
      <form  action="{{ URL::to('add-services') }}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card country_management">
                  <div class="card-body">
                     <div class="row"> 
                        
                        @if(Session::get('userRole') == 1)
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">
                              <?php $whitelabel = DB::table('users')->where('users_role', 2)->get(); ?>
                              <label class="control-label">Country<font color="red">*</font></label>
                              <select class="form-control" id="upload_by" name="upload_by" required="">
                                 <option value="">Select Country</option>
                                 @foreach($whitelabel as $value)
                                 <option value="{{ $value->id }}">{{ $value->name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        @endif
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">ISD Code<font color="red">*</font></label>
                              <input type="text" id="name" name="name" class="form-control" aria-required="true" maxlength="25" placeholder="Enter ISD code of the country" required="">
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Currency<font color="red">*</font></label>
                              <input type="text" id="email" name="email" onchange="email_check()" class="form-control" placeholder="Enter Currency" required="" maxlength="25">
                              <p style="color: red; display: none;" id="email_error">Email already exists.</p>
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">ISO Code of Currency Symbol<font color="red">*</font></label>
                              <input type="password" name="password" class="form-control" maxlength="20" 
                             placeholder="Enter ISO code of currency symbol" required="">
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Distance Unit<font color="red">*</font></label>
                              <input type="text" id="phone" name="phone" class="form-control" aria-required="true" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" maxlength="10" placeholder="Enter ISO code of currency symbol" required=""> 
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">
                              <?php $Country = DB::table('country')->get(); ?>
                              <label class="control-label">Default Language<font color="red">*</font></label>
                              <select class="form-control" id="country_id" name="country_id" required="">
                                 <option value="">-- Choose Country --</option>
                                 @foreach($Country as $data)
                                 <option value="{{ $data->id }}">{{ $data->country_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Minimum Phone Number Digits<font color="red">*</font></label>
                              <input type="text" id="Phone" name="dob" class="form-control" aria-required="true" placeholder="Minimum Phone Number Digits" required=""> 
                           </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">  
                              <label class="control-label">Maximum Phone Number Digits<font color="red">*</font></label>
                              <input type="text" id="phone" name="dob" class="form-control" aria-required="true" placeholder="Maximum Phone Number Digits" required=""> 
                           </div>
                        </div> 
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group">
                              <label class="control-label">Online Transaction Code<font color="red">*</font></label>
                              <input type="text" id="phone" name="dob" class="form-control" aria-required="true" placeholder="Enter Online Transaction Code" required=""> 
                           </div>
                        </div>   
                        <div class="col-md-4 col-sm-4">
                           <div class="form-group"> 
                              <label class="control-label">Sequence<font color="red">*</font></label>
                              <input type="text" id="phone" name="dob" class="form-control" aria-required="true" placeholder="Enter Sequence" required=""> 
                           </div>
                        </div>                 
                     </div>
                     <div class="modal-footer">
                       <button type="submit" id="submitbtn" class="btn cancel_btn">Cancel</button>
                       <button type="submit" id="submitbtn" class="btn save_btn">Save & Add</button>
                     </div>                     
                  </div><!-- End card-body -->
               </div> <!-- End card -->
            </form><!-- Form End -->
         </div><!-- container -->
      </div>
