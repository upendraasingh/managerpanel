<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">view Brand</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">view Brand</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add-brand')}}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-sm-6">
                           <div class="m-b-30">
                              <button type="button" class="btn btn-primary waves-effect waves-light" onclick="window.history.go(-1); return false;"><i class="fa fa-arrow-left"></i>  Go Back </button>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                           <div class="form-group"> 
                              <img style="border: 1px solid #eae3e3;" src="{{ asset('public/brand_image/').'/'.$editdata->logo }}" alt="image" width="100" height="100">
                           </div>
                        </div>
                     
                        <div class="col-md-6">
                           <div class="form-group"> 
                              <p class="control-label"><b>Brand name</b> <font color="red">*</font></p>
                              <input  type="text" name="brand_name" class="form-control" required="" value="{{ $editdata->brand_name ?? '' }}" readonly=""> 
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">
                              <p class="control-label"><b>Status : </b> <font color="red">*</font></p>                             
                                 @if($editdata->status == 0)
                                 <input type="text" class="form-control" id="active" value="Active" readonly="">    
                                 @else
                                 <input type="text" class="form-control" id="active" value="InActive" readonly="">
                                 @endif 
                           </div>
                        </div>

                     </div> 
               </div><!-- End card-body -->
            </div> <!-- End card -->
         </form><!-- Form End -->
      </div><!-- container -->
   </div>
