<?php 
    $sessionId =  Session::get('gorgID');   
    $users = DB::table('users')->where('id', $sessionId)->first();
    $userrole = Session::get('userRole');
?>
<style>
    .slimScrollBar{
        background: rgb(13, 157, 228);
        width: 9px;
        position: absolute;
        top: -154.219px;
        opacity: 0.4;
        display: none;
        border-radius: 7px;
        z-index: 99;
        right: 1px;
        height: 74.621px;
        visibility: visible;
    }
    .menugroup{
        color: #6c757d;
        font-weight: 600;
        margin-left: 16px;
    }
</style>
<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <div class="user-details">
        </div>
        <!--- Divider -->
        <div id="sidebar-menu">        
            <ul>
               <li><a href="{{ URL::to('managerdashboard')}}" class="waves-effect"><i class="fa fa-home" style="color:red"></i><span>Dashboard</span></a>
               </li>
               <li><a href="{{ URL::to('manager_view_rides')}}" class="waves-effect"><i class="fa fa-database" style="color:red"></i><span>Order Management</span></a>
               </li>
            </ul>
            <ul>
                <li class="has_sub">
                    <a href="#" class="waves-effect"><i class="fa fa-bars"></i><span> Driver Management </span><span class="pull-right"><i class="md md-add"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="{{ url('manager-view-driver') }}" class="waves-effect"><span> Drivers </span></a>
                        <li><a href="{{ url('manager-vehicles') }}" class="waves-effect"><span> Vehicles </span></a>
                        <li><a href="{{ url('managerdriver-map') }}" class="waves-effect"><span> Map </span></a>
                    </ul>
                </li>
            </ul>
            <ul>
                <li class="has_sub">
                    <a href="#" class="waves-effect"><i class="fa fa-bars"></i><span> Delivery Management </span><span class="pull-right"><i class="md md-add"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href=" {{ url('managerride-management/ongoing-rides') }}" class="waves-effect"><span>Ongoing Rides</span></a>
                        </li>
                        <li><a href="{{ url('managerride-management/completed-rides') }}" class="waves-effect"><span>Completed Rides</span></a>
                        </li>
                        <li><a href="{{ url('managerride-management/calcelled-rides') }}" class="waves-effect"><span>Cancelled Rides</span></a>
                        </li>
                        <li><a href="{{ url('managerride-management/failed-rides') }}" class="waves-effect"><span>Failed Rides</span></a>
                        </li>
                        <li><a href="{{ url('managerride-management/auto-cancelledrides') }}" class="waves-effect"><span>Auto Cancelled Rides</span></a>
                        </li>
                        <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><span>All Rides</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul>
                <li class="has_sub">
                    <a href="#" class="waves-effect"><i class="fa fa-bars"></i><span> E-Wallet Management </span><span class="pull-right"><i class="md md-add"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="{{ url('manager-view-driver') }}" class="waves-effect"><span> E-Wallet </span></a>
                        <li><a href="{{ url('manager-vehicles') }}" class="waves-effect"><span> Cashout Requests </span></a>
                    </ul>
                </li>
            </ul>
            <!--<ul>
                <p class="menugroup">Delivery Management</p>
                <li><a href=" {{ url('managerride-management/ongoing-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Ongoing Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/completed-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Completed Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/calcelled-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/failed-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Failed Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/auto-cancelledrides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Auto Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><i class="fa fa-bars"></i><span>All Rides</span></a>
                </li>
            </ul>-->
            <!--<ul>
                <li><a href="{{ url('managerride-management/completed-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Completed Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/calcelled-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/failed-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Failed Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/auto-cancelledrides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Auto Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><i class="fa fa-bars"></i><span>All Rides</span></a>
                </li>
            </ul>
            <ul>
                <li><a href="{{ url('managerride-management/calcelled-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/failed-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Failed Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/auto-cancelledrides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Auto Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><i class="fa fa-bars"></i><span>All Rides</span></a>
                </li>
            </ul>
            <ul>
                <li><a href="{{ url('managerride-management/failed-rides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Failed Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/auto-cancelledrides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Auto Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><i class="fa fa-bars"></i><span>All Rides</span></a>
                </li>
            </ul>
            <ul>
                <li><a href="{{ url('managerride-management/auto-cancelledrides') }}" class="waves-effect"><i class="fa fa-bars"></i><span>Auto Cancelled Rides</span></a>
                </li>
                <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><i class="fa fa-bars"></i><span>All Rides</span></a>
                </li>
            </ul>
            <ul>
                <li><a href="{{ url('managerride-management/manager-view-rides') }} " class="waves-effect"><i class="fa fa-bars"></i><span>All Rides</span></a>
                </li>
            </ul>-->
            <!--<ul>
                <p class="menugroup">Driver Manager</p>
                <li class="has_sub">
                    <a href="#" class="waves-effect"><i class="fa fa-bars"></i><span> Drivers </span><span class="pull-right"><i class="md md-add"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="{{ url('view-driver') }}" class="waves-effect"><span> All Driver </span></a>
                        <li><a href="{{ url('add-driver') }}" class="waves-effect"><span> Add Driver </span></a>
                        <li><a href="{{ url('signupdriver') }}" class="waves-effect"><span> SignUp Driver </span></a>
                        <li><a href="{{ url('registereddriver') }}" class="waves-effect"><span> Registered Driver </span></a>
                        <li><a href="{{ url('pendingapp') }}" class="waves-effect"><span> Pending Approval </span></a>
                        <li><a href="{{ url('incompleteddoc') }}" class="waves-effect"><span> Incomplete Documents </span></a>
                        <li><a href="{{ url('rejectedapp') }}" class="waves-effect"><span> Rejected Applications </span></a>
                        <li><a href="{{ url('expirydoc') }}" class="waves-effect"><span> Expiry Documents </span></a>
                    </ul>
                </li>
            </ul>-->
        </div>
    </div>
</div>
<div class="content-page">