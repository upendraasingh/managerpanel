<?php

use App\User;

Route::get('clear-cache', function () {
	$exitCode = Artisan::call('config:clear');
	$exitCode = Artisan::call('cache:clear');
	$exitCode = Artisan::call('route:clear');
	$exitCode = Artisan::call('view:clear');
	$exitCode = Artisan::call('config:cache');
	Session::flash('success', 'All Clear');
	echo "DONE";
});
Route::get('privacypolicy', function () {
	return view('static_page.privacyPolicy');
});
Route::get('end-user-license-agreement', function () {
	return view('static_page.endUserLicenseAgreement');
});
Route::get('terms-and-conditions', function () {
	return view('static_page.termsAndConditions');
});
Route::get('end-user-license-agreement', function () {
	return view('static_page.endUserLicenseAgreement');
});

Route::get('terms-service-transport-delivery-logistics', function () {
	return view('static_page.termsServiceTransportDeliveryLogistics');
});
Route::get('terms-services', function () {
	return view('static_page.termsServices');
});
/*Route::get('locale/{locale}', function ($locale){
	    Session::put('locale', $locale);

	    if (request()->fullUrl() === redirect()->back()->getTargetUrl()) {
	        return redirect('/');
	    }

	    return redirect()->back();
	});*/

/* Web all Routes */
/*Route::get('dashboard', function () {
			return view('web.dashboard.dashboard');	
		});
	*/
Route::get('web-login', function () {
	//return view('web.login.login');	
});
/*Route::group(['middleware'=>'language'],function ()
	{
		Route::get('web-login', function () {
			return view('web.login.login');	
		});

	});	*/

Route::get('subscribe', function () {
	return view('web.subscribe.subscribe');
});

Route::any('loginmanager', 'ManagerController@loginmanager');
Route::any('forgotpasswordemail', 'ManagerController@forgotpasswordemail');

Route::get('user-detail', 'HomeController@profile');

/*Route::get('user-detail', function () {		
		return view('web.dashboard.myaccount.myaccount');	
	});*/

Route::get('wallet', function () {
	return view('web.dashboard.watchmarketwallet.watchmarketwallet');
});

Route::get('add-money', function () {
	return view('web.dashboard.watchmarketwallet.add_wallet_money');
});

Route::get('withdraw-money', function () {
	return view('web.dashboard.watchmarketwallet.withdraw_wallet_money');
});

Route::get('submitted_details', 'WebController@view_subscribe')->name('submitted_details');

Route::any('subscribe-user', 'WebController@subscribe_user');
/* Web all Routes End*/

/* Admin panel All routes */
Route::get('update-site', function () {
	$data['content'] = 'errors.comming-soon';
	return view('layouts.content', compact('data'));
});

Route::get('/', function () {
	return view('admin.admin-login');
});
Route::get('forgotpassword', function () {
	return view('admin.forgot_password');
});
Route::get('manager/', function () {
	return view('manager.manager-login');
});
Route::get('/managerhome', function () {
	return view('manager.home');
});
Route::any('forgotpassword_update', 'ManagerController@forgotpasswordupdate');

Auth::routes();
Route::any('forgot_password', 'ForgotPasswordController@forgot_password');
Route::any('upload-user-document', 'HomeController@upload_user_document');
Route::any('admin-update-docuemnt/{id}', 'HomeController@admin_update_document');
Route::get('user-profile', 'HomeController@UserProfile');
Route::any('edit-userprofile', 'HomeController@UpdateProfile');
Route::any('book-appointment', 'HomeController@bookAppointment');
Route::any('book-client-appointment', 'HomeController@bookClientAppointment');
Route::get('home', 'HomeController@index')->name('home');
Route::get('dashboard', 'HomeController@Dashboard');
Route::get('managerdashboard', 'HomeController@managerDashboard');
Route::any('web-dashboard', 'ProductController@web_product');
Route::any('manager-dashboard', 'ProductController@manager_product');

Route::any('customer-user', 'HomeController@customer_user');
Route::any('view-customer/{i}', 'HomeController@show_customer_user');
Route::any('driver-user', 'HomeController@driver_user');
Route::any('food-user', 'HomeController@food_user');
Route::any('shop-user', 'HomeController@shop_user');
Route::any('operator-user', 'HomeController@operator_user');

/* users all routes start */
Route::any('users', 'HomeController@user_view');
Route::any('add-user', 'HomeController@add_user');
Route::any('user-edit/{id}', 'HomeController@user_edit');
Route::any('user-view/{id}', 'HomeController@view_user');
Route::any('delete-user/{id}', 'HomeController@user_delete');
Route::any('change-password', 'HomeController@change_password');
Route::any('change-password-client', 'HomeController@change_password_client');
/* users all routes End */

/* users all routes start */
Route::any('customers', 'HomeController@customer_view');
Route::any('delete-customer/{id}', 'HomeController@customer_delete');
// Route::any('delete-user/{id}', 'HomeController@user_delete');

Route::get('add-adminuser', function () {
	$data['content'] = 'admin.systemuser.add_adminuser';
	return view('layouts.content', compact('data'));
});
Route::any('add-adminusers', 'HomeController@add_adminusers');
Route::any('view-adminuser', 'HomeController@view_adminuser');
Route::any('update_adminusers', 'HomeController@update_adminusers');
Route::any('edit-adminuser/{id}', 'HomeController@edit_adminuser');
Route::get('add-role', function () {
	$data['content'] = 'admin.systemuser.add_role';
	return view('layouts.content', compact('data'));
});
Route::any('add-roles', 'HomeController@add_role');
Route::any('view-role', 'HomeController@view_role');
Route::any('edit-role/{id}', 'HomeController@edit_role');
Route::any('general-setting', 'HomeController@general_setting');
Route::any('save-general-setting', 'HomeController@save_general_setting');
Route::any('order-request', 'HomeController@order_request');
Route::any('save-order-request', 'HomeController@save_order_request');
Route::any('addorder_requestcon', 'HomeController@addorder_requestcon');
Route::any('driver-configuration', 'HomeController@driver_configuration');
Route::any('add_driverfiguration', 'HomeController@add_driverfiguration');
Route::any('add_emailconfig', 'HomeController@add_emailconfig');
Route::any('email-configuration', 'HomeController@email_configuration');
Route::get('add-servicetype', function () {
	$data['content'] = 'admin.systemuser.add_type';
	return view('layouts.content', compact('data'));
});
Route::any('add_servicetype', 'HomeController@add_servicetype');
Route::any('view-servicetype', 'HomeController@view_type');
Route::any('edit-servicetype/{id}', 'HomeController@edit_type');
Route::any('update_servicetype', 'HomeController@update_servicetype');
Route::get('add-drawer', function () {
	$data['content'] = 'admin.systemuser.add_drawer';
	return view('layouts.content', compact('data'));
});
Route::get('app-url', function () {
	$data['content'] = 'admin.systemuser.add_appurl';
	return view('layouts.content', compact('data'));
});
Route::any('add-drawers', 'HomeController@add_drawer');
Route::any('view-drawer', 'HomeController@view_drawer');
Route::any('edit-drawer/{id}', 'HomeController@edit_drawer');
Route::any('update_drawer', 'HomeController@update_drawer');

Route::any('add-appurl', 'HomeController@add_appurl');
Route::any('view-drawer', 'HomeController@view_drawer');
Route::any('edit-drawer/{id}', 'HomeController@edit_drawer');
Route::any('update_drawer', 'HomeController@update_drawer');

Route::get('login-api', function () {
	$data['content'] = 'admin.systemuser.loginapi';
	return view('layouts.content', compact('data'));
});

Route::any('add-loginapi', 'HomeController@add_loginapi');
Route::get('add-cancellation', function () {
	$data['content'] = 'admin.systemuser.add_cancelreason';
	return view('layouts.content', compact('data'));
});
Route::any('add_cancellation', 'HomeController@add_cancellation');
Route::any('view-cancellation', 'HomeController@view_cancellation');
Route::any('update_reason', 'HomeController@update_reason');
Route::any('edit-cancellation/{id}', 'HomeController@edit_cancellation');
Route::any('consumer-support', 'HomeController@consumer_support');
Route::any('driver-support', 'HomeController@driver_support');
Route::any('manage-support', 'HomeController@manage_support');
Route::any('merchant-support', 'HomeController@merchant_support');
Route::any('top-sales', 'HomeController@top_sales');
Route::any('all-notification', 'HomeController@all_notification');
/* users all routes End */

/*  Employee all route Start */
Route::get('add-employees', function () {
	$data['content'] = 'admin.employee.add_employee';
	return view('layouts.content', compact('data'));
});
Route::any('add-employee', 'EmployeeController@add_employee');
Route::any('view-employee', 'EmployeeController@view_employee');
Route::any('edit-employee/{id}', 'EmployeeController@edit_employee');
Route::any('useremail/{y}', 'HomeController@useremail');
Route::any('get-whitelabeldata/{id}', 'EmployeeController@get_whitelabel_data');
Route::any('get-employee/{manager_id}', 'EmployeeController@get_employee_data');
Route::any('filter-employee', 'EmployeeController@filter_employee');

/*  Employee all route End */

/*  Manager all route Start */
Route::get('add-country', function () {
	$data['content'] = 'admin.country.add_country';
	return view('layouts.content', compact('data'));
});
Route::any('add-countries', 'ManagerController@addCountries');
Route::any('view-country', 'ManagerController@view_country');
Route::any('edit-country/{id}', 'ManagerController@edit_manager');
Route::any('show-country/{id}', 'ManagerController@show_country');
Route::any('update-country/{id}', 'ManagerController@update_country');
Route::any('delete-country/{id}', 'ManagerController@deleteCountry');
Route::any('filter-manager', 'ManagerController@filter_manager');
Route::any('useremail/{y}', 'HomeController@useremail');
/*  Manager all route End */

/*  service area Start */
Route::get('add-service', function () {
	$data['content'] = 'admin.service.add_service';
	return view('layouts.content', compact('data'));
});
Route::any('add-services', 'ServiceController@add_service');
Route::any('view-service', 'ServiceController@view_service');
Route::any('edit-service/{id}', 'ServiceController@edit_service');
Route::any('update-services/{id}','ServiceController@updateService');
Route::any('show-service/{id}','ServiceController@edit_service');
Route::any('delete-service/{id}','ServiceController@deleteService');

Route::any('useremail/{y}', 'HomeController@useremail');
Route::any('filter-manager', 'ServiceController@filter_manager');
/*  service area End */

/*  service area Start */
Route::get('add-foodmerchant', function () {
	$data['content'] = 'admin.foodmerchant.add_foodmerchant';
	return view('layouts.content', compact('data'));
});
Route::any('add-foodmerchants', 'ServiceController@add_foodmerchant');
Route::any('view-foodmerchant', 'ServiceController@view_foodmerchant');
Route::any('edit-foodmerchant/{id}', 'ServiceController@edit_foodmerchant');
Route::any('useremail/{y}', 'HomeController@useremail');
Route::any('filter-manager', 'ServiceController@filter_manager');
/*  service area End */

/*  service area Start */
Route::get('add-shopmerchant', function () {
	$data['content'] = 'admin.shopmerchant.add_shopmerchant';
	return view('layouts.content', compact('data'));
});
Route::any('add-shopmerchants', 'ServiceController@add_shopmerchant');
Route::any('view-shopmerchant', 'ServiceController@view_shopmerchant');
Route::any('edit-shopmerchant/{id}', 'ServiceController@edit_shopmerchant');
Route::any('useremail/{y}', 'HomeController@useremail');
Route::any('filter-manager', 'ServiceController@filter_manager');
/*  service area End */

/*  operator area Start */
Route::get('add-operatormanager', function () {
	$data['content'] = 'admin.operatormanager.add_operatormanager';
	return view('layouts.content', compact('data'));
});
Route::any('add-operatormanagers', 'ServiceController@add_operatormanager');
Route::any('view-operatormanager', 'ServiceController@view_operatormanager');
Route::any('edit-operatormanager/{id}', 'ServiceController@edit_operatormanager');
Route::any('useremail/{y}', 'HomeController@useremail');
Route::any('filter-manager', 'ServiceController@filter_manager');
/*  operator area End */

/*  ride area Start */
Route::group(['prefix' => 'ride-management'], function () {
	Route::any('view-rides', 'RideController@view_rides');
	Route::any('ongoing-rides', 'RideController@ongoing_rides');
	Route::any('completed-rides', 'RideController@completed_rides');
	Route::any('calcelled-rides', 'RideController@calcelled_rides');
	Route::any('failed-rides', 'RideController@failed_rides');
	Route::any('auto-cancelledrides', 'RideController@auto_cancelledrides');
	Route::any('edit-ride/{id}', 'RideController@edit_ride');
	Route::any('show-ride/{id}','RideController@edit_ride');
	Route::post('{id}/update', 'RideController@update');
	Route::any('edit-operatormanager/{id}', 'RideController@edit_operatormanager');


	Route::any('useremail/{y}', 'HomeController@useremail');
	Route::any('filter-manager', 'ServiceController@filter_manager');
});

/*  Manager ride area Start */
Route::group(['prefix' => 'manager-ride-management'], function () {
    
	Route::any('manager-view-rides', 'ManagerrideControllers@manager_view_rides');
	Route::any('ongoing-rides', 'ManagerrideControllers@ongoing_rides');
	Route::any('completed-rides', 'ManagerrideControllers@completed_rides');
	Route::any('calcelled-rides', 'ManagerrideControllers@calcelled_rides');
	Route::any('failed-rides', 'ManagerrideControllers@failed_rides');
	Route::any('auto-cancelledrides', 'ManagerrideControllers@auto_cancelledrides');
	Route::any('edit-ride/{id}', 'ManagerrideControllers@edit_ride');
	Route::any('show-ride/{id}','ManagerrideControllers@edit_ride');
	Route::post('{id}/update', 'ManagerrideControllers@update');
	Route::any('edit-operatormanager/{id}', 'ManagerrideControllers@edit_operatormanager');

	Route::any('useremail/{y}', 'HomeController@useremail');
	Route::any('filter-manager', 'ServiceController@filter_manager');
});

Route::group(['prefix' => 'managerride-management'], function () {
    
	Route::any('manager-view-rides', 'ManagerRideController@view_rides');
	Route::any('ongoing-rides', 'ManagerRideController@ongoing_rides');
	Route::any('completed-rides', 'ManagerRideController@completed_rides');
	Route::any('calcelled-rides', 'ManagerRideController@calcelled_rides');
	Route::any('failed-rides', 'ManagerRideController@failed_rides');
	Route::any('auto-cancelledrides', 'ManagerRideController@auto_cancelledrides');
	Route::any('edit-ride/{id}', 'ManagerRideController@edit_ride');
	Route::any('show-ride/{id}','ManagerRideController@edit_ride');
	Route::post('{id}/update', 'ManagerRideController@update');
	Route::any('edit-operatormanager/{id}', 'ManagerRideController@edit_operatormanager');

	Route::any('useremail/{y}', 'HomeController@useremail');
	Route::any('filter-manager', 'ServiceController@filter_manager');
});

    Route::any('manager_view_rides', 'ManagerrideControllers@manager_view_rides');
	Route::any('view-rides', 'RideController@view_rides');
	Route::any('ongoing-rides', 'RideController@ongoing_rides');
	Route::any('completed-rides', 'RideController@completed_rides');
	Route::any('calcelled-rides', 'RideController@calcelled_rides');
	Route::any('failed-rides', 'RideController@failed_rides');
	Route::any('auto-cancelledrides', 'RideController@auto_cancelledrides');
	Route::any('edit-ride/{id}', 'RideController@edit_ride');
	Route::any('show-ride/{id}','RideController@edit_ride');
	Route::post('{id}/update', 'RideController@update');
	Route::any('edit-operatormanager/{id}', 'RideController@edit_operatormanager');


	Route::any('useremail/{y}', 'HomeController@useremail');
	Route::any('filter-manager', 'ServiceController@filter_manager');

/*  operator area End */

/*  DriverController area Start */
Route::get('add-driver', function () {
	$data['content'] = 'admin.driver.add_driver';
	return view('layouts.content', compact('data'));
});
Route::group(['prefix' => 'vehicle-management'], function () {
	Route::any('view-vehicle', 'DriverController@view_vehicle');
});

//Start Manager vehicle
Route::any('manager-vehicles', 'ManagerDriverController@view_vehicle');
Route::any('manager-view-details/{id}', 'ManagerDriverController@showDriver');
//End Manager Vehicle
Route::any('add-drivers', 'DriverController@add_driver');
Route::any('view-driver', 'DriverController@view_driver');
Route::any('edit-driver/{id}', 'DriverController@edit_driver');
Route::any('update-drivers/{id}','DriverController@updatedriver');


Route::get('manager-add-driver', function () {
	$data['content'] = 'manager.driver.add_driver';
	return view('manager_layouts.content', compact('data'));
});
Route::any('manager-add-drivers', 'ManagerDriverController@add_driver');
Route::any('manager-view-driver', 'ManagerDriverController@view_driver');
Route::any('manager-edit-driver/{id}', 'ManagerDriverController@edit_driver');
Route::any('manager-update-drivers/{id}','ManagerDriverController@updatedriver');

Route::any('useremail/{y}', 'HomeController@useremail');
Route::any('filter-manager', 'DriverController@filter_manager');
Route::any('signupdriver', 'DriverController@signupdriver');
Route::any('registereddriver', 'DriverController@registereddriver');
Route::any('pendingapp', 'DriverController@pendingapp');
Route::any('view-details/{id}', 'DriverController@showDriver');

Route::any('incompleteddoc', 'DriverController@incompleteddoc');
Route::any('rejectedapp', 'DriverController@rejectedapp');
Route::any('expirydoc', 'DriverController@expirydoc');
Route::any('managerdriver-map', 'ManagerDriverController@view_drivermap');
Route::any('driver-map', 'DriverController@view_drivermap');
Route::any('heat-map', 'DriverController@view_heatmap');
Route::any('driver-earning', 'DriverController@driver_earning');
Route::any('food-merchant-earning', 'DriverController@foodmerchant_earning');
Route::any('shop-merchant-earning', 'DriverController@shopmerchant_earning');

/*  DriverController area End */

/*  DriverController area Start */
Route::get('add_company', function () {
	$data['content'] = 'admin.company.add_company';
	return view('layouts.content', compact('data'));
});
Route::get('addsignedup_company', function () {
	$data['content'] = 'admin.company.addsignedup_company';
	return view('layouts.content', compact('data'));
});
Route::any('add-companys', 'CompanyController@add_company');
Route::any('add-signcompanys', 'CompanyController@add_signcompany');
Route::any('view_company', 'CompanyController@view_company');
Route::any('signup_company', 'CompanyController@signup_company');
Route::any('registered_company', 'CompanyController@registered_company');
Route::any('pending_approval', 'CompanyController@pending_approval');
Route::any('incomplete_documents', 'CompanyController@incomplete_documents');
Route::any('rejected_application', 'CompanyController@rejected_application');
Route::any('delete-company/{id}', 'CompanyController@delete_company');
/*  DriverController area End */

/*  service area Start */
Route::get('add-banner', function () {
	$data['content'] = 'admin.banner.add_banner';
	return view('layouts.content', compact('data'));
});
Route::any('add-banners', 'BannerController@add_banner');
Route::any('view-banner', 'BannerController@view_banner'); 
Route::any('edit-banner/{id}', 'BannerController@edit_banner');
Route::any('show-banner/{id}','BannerController@show_banner');
Route::any('update-banner/{id}', 'BannerController@update_banner');

Route::any('filter-manager', 'BannerController@filter_manager');
/*  service area End */

/*  Client all routes start */
Route::get('client-add', function () {
	$data['content'] = 'admin.client.add_client';
	return view('layouts.content', compact('data'));
});
Route::get('agenda', 'EventController@index');
Route::get('view-comment/{id}', 'ClientController@view_comment');
Route::any('add-client', 'ClientController@add_client');
Route::any('edit-client/{id}', 'ClientController@edit_client');
Route::any('view-client', 'ClientController@view_client');
Route::any('client-view-data/{id}', 'ClientController@client_view_data');
Route::any('check/document/{id}', 'ClientController@check_client_document');
Route::any('filter-clients', 'ClientController@filter_client');
Route::any('logout', 'ClientController@logout');
Route::any('managerlogout', 'ClientController@managerlogout');
Route::any('client-password-change', 'ClientController@client_password_change');
Route::any('client-update-profile', 'ClientController@client_update_profile');
Route::any('add-issafe', 'ClientController@add_issafe');
Route::any('add-marketplace', 'ClientController@add_marketplace');
Route::any('update-status', 'OfferController@update_status');
/* Client all routes end */

/*  Offer all routes start */
Route::get('offer-add', function () {
	$data['content'] = 'admin.offer.add_offer';
	return view('layouts.content', compact('data'));
});
Route::any('add-offer', 'OfferController@add_offer');
Route::any('get_marketplace_offer/{id}', 'OfferController@get_marketplace_offer');
Route::any('view-watch-offer/{id}', 'OfferController@view_watch_offer');
Route::any('delete-offer/{id}', 'OfferController@delete_offer');
Route::any('edit-offer/{id}', 'OfferController@edit_offer');
Route::any('view-marketplace', 'OfferController@view_offer');
Route::any('offer-view-data/{id}', 'OfferController@offer_view_data');
Route::any('filter-offer', 'OfferController@filter_offer');
Route::any('offer-password-change', 'OfferController@offer_password_change');
Route::any('offer-update-profile', 'OfferController@offer_update_profile');
/* Offer all routes end */

/*  Employee all route Start */
Route::get('add-page', function () {
	$data['content'] = 'admin.cms.add_employee';
	return view('layouts.content', compact('data'));
});
Route::any('add-pagese', 'CmsController@add_page');
Route::any('view-page', 'CmsController@view_page');
Route::any('edit-page/{id}', 'CmsController@edit_page');
Route::any('get-whitelabeldata/{id}', 'CmsController@get_whitelabel_data');
Route::any('get-employee/{manager_id}', 'CmsController@get_employee_data');
Route::any('filter-employee', 'CmsController@filter_employee');

/*  Employee all route End */

/*  Employee all route Start */
Route::get('add-language', function () {
	$data['content'] = 'admin.cms.add_language';
	return view('layouts.content', compact('data'));
});
Route::get('add-notification', function () {
	$data['content'] = 'admin.cms.push_notification';
	return view('layouts.content', compact('data'));
});
Route::any('add-languages', 'CmsController@add_language');
Route::any('add-pushnotification', 'CmsController@add_pushnotification');
Route::any('view-language', 'CmsController@view_language');
Route::any('edit-language/{id}', 'CmsController@edit_language');
Route::any('get-whitelabeldata/{id}', 'CmsController@get_whitelabel_data');
Route::any('get-employee/{manager_id}', 'CmsController@get_employee_data');
Route::any('filter-employee', 'CmsController@filter_employee');

/*  Employee all route End */

/* TransactionController all Routes */
Route::any('add-transaction', function () {
	$data['content'] = 'admin.transaction.add_transaction';
	return view('layouts.content', compact('data'));
});
Route::any('add-amount', 'TransactionController@add_amount');
Route::any('withdraw-amount', 'TransactionController@withdraw_amount');
Route::any('withdraw-amount-admin', 'TransactionController@withdraw_amount_admin');
Route::any('update-transaction/{status}/{id}', 'TransactionController@update_transaction');
/* TransactionController all Routes End */

/* Lead all rolutes */
Route::get('add-lead', function () {
	$data['content'] = 'admin.lead.add_lead';
	return view('layouts.content', compact('data'));
});

Route::any('manage-leads', 'LeadController@view_lead');
Route::any('add-leads', 'LeadController@add_lead');
Route::any('lead-delete/{id}', 'LeadController@delete_lead');
Route::any('lead-edit/{id}', 'LeadController@edit_lead');
Route::any('lead-view/{id}', 'LeadController@lead_view');
Route::any('search-lead', 'LeadController@search_lead');
Route::any('search-status', 'LeadController@search_status');
Route::any('search-status-transaction', 'TransactionController@search_status_transaction');
Route::any('search-leads-bydate', 'LeadController@lead_search_by_date');
Route::any('export', 'LeadController@export');
Route::any('import-leads', 'LeadController@import_leads');

Route::get('import-excel', 'ImportExcel\ImportExcelController@index');
Route::post('import-excel', 'ImportExcel\ImportExcelController@import');
Route::get('export-excel', 'ImportExportExcel\ImportExportExcelController@export');
/* Lead all rolutes End */

/*  Prduct all route Start */
Route::get('add-products', function () {
	$data['content'] = 'admin.product.add_products';
	return view('layouts.content', compact('data'));
});
Route::any('get-model/{brandId}', 'ProductController@get_model');
Route::any('add-product', 'ProductController@add_product');
Route::any('view-product', 'ProductController@view_product');
Route::any('delete-product/{id}', 'ProductController@delete_product');
Route::any('view-products/{id}', 'ProductController@product_view');
Route::any('product-edit/{id}', 'ProductController@product_edit');
Route::any('status-change/{id}', 'ProductController@status_change');
Route::any('filter-whitelabel', 'ProductController@filter_whitelabel');
Route::any('filter_brand', 'ProductController@filter_brand');
Route::any('filter_status', 'ProductController@filter_status');
Route::any('edit-product-image', 'ProductController@edit_product_image');
Route::any('add-product-image', 'ProductController@add_product_image');

Route::any('product-image-edit/{id}', 'ProductController@product_image_edit');
Route::any('product-image-delete/{id}', 'ProductController@product_image_delete');
Route::any('product-detail/{id}', 'ProductController@product_detail');
Route::any('product-image-gallery/{productId}', 'ProductController@product_image_gallery');
Route::any('filter-brand-year', 'ProductController@filter_brand_year');
/*  Prduct all route End */

/*  Brand controller Route start */
Route::any('add-brand', 'BrandController@add_brand');
Route::any('view-brand', 'BrandController@view_brand');
Route::any('edit-brand/{id}', 'BrandController@edit_brand');
Route::any('detele-brand/{id}', 'BrandController@delete_brand');
Route::any('brand-view/{id}', 'BrandController@brand_view');
/*  Brand controller Route End */

/*  Categry controller Route start */
Route::get('add-category', function () {
	$data['content'] = 'admin.category.add_category';
	return view('layouts.content', compact('data'));
});
Route::any('add-categorys', 'CategoryController@add_model');
Route::any('view-category', 'CategoryController@manage_category');
Route::any('edit-category/{id}', 'CategoryController@editCatogary');
Route::any('update-categoryss/{id}','CategoryController@updateCatogary');
Route::any('detele-category/{id}', 'CategoryController@delete_model');
Route::any('category-view/{id}', 'CategoryController@model_view');
/*  Categry controller Route End */

/*  unit controller Route start */
Route::get('add-unit', function () {
	$data['content'] = 'admin.unit.add_unit';
	return view('layouts.content', compact('data'));
});
Route::any('add-units', 'BannerController@add_unit');
Route::any('view-unit', 'BannerController@view_unit');
Route::any('edit-unit/{id}', 'BannerController@edit_unit');
Route::any('update-units/{id}', 'BannerController@update_unit');
Route::any('detele-unit/{id}', 'BannerController@delete_unit');
/*  unit controller Route End */

/*  style controller Route start */
Route::get('add-style', function () {
	$data['content'] = 'admin.style.add_style';
	return view('layouts.content', compact('data'));
});
Route::any('add-Styles', 'BannerController@add_style');
Route::any('view-style', 'BannerController@view_style');
Route::any('edit-style/{id}', 'BannerController@edit_style');
Route::any('update-Styles/{id}', 'BannerController@updateStyle');
Route::any('detele-style/{id}', 'BannerController@delete_style');
/*  style controller Route End */

/*  options controller Route start */
Route::get('add-options', function () {
	$data['content'] = 'admin.options.add_options';
	return view('layouts.content', compact('data'));
});
Route::any('add-optionss', 'BannerController@add_options');
Route::any('view-options', 'BannerController@view_options');
Route::any('edit-options/{id}', 'BannerController@edit_options');
Route::any('update-Options/{id}', 'BannerController@updateOptions');
Route::any('detele-options/{id}', 'BannerController@delete_options');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-account', function () {
	$data['content'] = 'admin.account.add_account';
	return view('layouts.content', compact('data'));
});
Route::any('add-accounts', 'BannerController@add_account');
Route::any('view-account', 'BannerController@view_account');
Route::any('edit-account/{id}', 'BannerController@edit_account');
Route::any('update-account/{id}', 'BannerController@update_account');
Route::any('detele-account/{id}', 'BannerController@delete_account');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-type', function () {
	$data['content'] = 'admin.type.add_type';
	return view('layouts.content', compact('data'));
});
Route::any('add-types', 'TypeController@add_type');
Route::any('view-type', 'TypeController@view_type');
Route::any('store-vehicle-type', 'TypeController@storeVehicleType');
Route::any('edit-type/{id}', 'TypeController@edit_type');
Route::any('update-vehicle-type/{id}', 'TypeController@updateVehicleType');
Route::any('detele-type/{id}', 'TypeController@delete_type');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-page', function () {
	$data['content'] = 'admin.cms.add_page';
	return view('layouts.content', compact('data'));
});
Route::any('add-types', 'CmsController@add_type');
Route::any('view-page', 'CmsController@view_page');
Route::any('edit-page/{id}', 'CmsController@edit_page');
Route::any('update-page', 'CmsController@update_page');
Route::any('detele-type/{id}', 'CmsController@delete_type');
/*  options controller Route End */


/*  options controller Route start */
Route::get('add-make', function () {
	$data['content'] = 'admin.make.add_make';
	return view('layouts.content', compact('data'));
});
Route::any('add-makes', 'TypeController@add_make');
Route::any('view-make', 'TypeController@view_make');
Route::any('edit-make/{id}', 'TypeController@edit_make');
Route::any('update-make/{id}', 'TypeController@updateMake');
Route::any('detele-make/{id}', 'TypeController@delete_make');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-model', function () {
	$data['content'] = 'admin.model.add_model';
	return view('layouts.content', compact('data'));
});
Route::any('add-models', 'TypeController@add_model');
Route::any('view-modal', 'TypeController@view_model');
Route::any('edit-model/{id}', 'TypeController@edit_model');
Route::any('update-model/{id}', 'TypeController@updateModel');
Route::any('detele-model/{id}', 'TypeController@delete_modal');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-model', function () {
	$data['content'] = 'admin.model.add_model';
	return view('layouts.content', compact('data'));
});
Route::any('add-models', 'TypeController@add_model');
Route::any('view-model', 'TypeController@view_model');
Route::any('edit-model/{id}', 'TypeController@edit_model');
Route::any('detele-model/{id}', 'TypeController@delete_model');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-document', function () {
	$data['content'] = 'admin.document.add_document';
	return view('layouts.content', compact('data'));
});
Route::any('add-documents', 'TypeController@add_document');
Route::any('view-document', 'TypeController@view_document');
Route::any('edit-document/{id}', 'TypeController@edit_document');
Route::any('update-documents/{id}','TypeController@update_document');
Route::any('detele-document/{id}', 'TypeController@delete_document');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-pricing', function () {
	$data['content'] = 'admin.pricing.add_pricing';
	return view('layouts.content', compact('data'));
});
Route::any('add-pricings', 'TypeController@add_pricing');
Route::any('view-pricing', 'TypeController@view_pricing');
Route::any('edit-pricing/{id}', 'TypeController@edit_pricing');
Route::any('update-pricings/{id}','TypeController@updatePricing');
Route::any('detele-pricing/{id}', 'TypeController@delete_pricing');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-ewallet', function () {
	$data['content'] = 'admin.ewallet.add_ewallet';
	return view('layouts.content', compact('data'));
});
Route::get('ewallet_recharge', function () {
	$data['content'] = 'admin.ewallet.ewallet_recharge';
	return view('layouts.content', compact('data'));
});
Route::any('add-ewallets', 'TypeController@add_ewallet');
Route::any('view-ewallet', 'TypeController@view_ewallet');
Route::any('show-ewallet/{id}','TypeController@show_ewallet');
Route::any('edit-ewallet/{id}', 'TypeController@edit_ewallet');

Route::any('update-ewallet/{id}','TypeController@updateEwallet');

Route::any('request_posting', 'TypeController@request_posting');
Route::any('settlements', 'TypeController@settlements');

Route::any('detele-ewallet/{id}', 'TypeController@delete_ewallet');
/*  options controller Route End */

/*  options controller Route start */
Route::get('add-payment', function () {
	$data['content'] = 'admin.payment.add_payment';
	return view('layouts.content', compact('data'));
});
Route::any('add-payments', 'TypeController@add_payment');
Route::any('view-payment', 'TypeController@view_payment');
Route::any('edit-payment/{id}', 'TypeController@edit_payment');
Route::any('update-payment/{id}', 'TypeController@update_payment');
Route::any('detele-payment/{id}', 'TypeController@delete_payment');
/*  options controller Route End */

/*  standardrules controller Route start */
Route::get('add-standardrates', function () {
	$data['content'] = 'admin.standardrules.add_standardrules';
	return view('layouts.content', compact('data'));
});
Route::any('add-standardratess', 'TypeController@add_standardrules');
Route::any('view-standardrates', 'TypeController@view_standardrules');
Route::any('update-standardrates', 'TypeController@update_standardrates');
Route::any('edit-standardrates/{id}', 'TypeController@edit_standardrules');
Route::any('detele-standardrules/{id}', 'TypeController@delete_standardrules');
/*  standardrules controller Route End */

/*  standardrules controller Route start */
Route::get('add-promocode', function () {
	$data['content'] = 'admin.promocode.add_promocode';
	return view('layouts.content', compact('data'));
});
Route::any('add-promocodes', 'LeadController@addPromocode');
Route::any('view-promocode', 'LeadController@view_promocode');
Route::any('edit-promocode/{id}', 'LeadController@edit_promocode');
Route::any('detele-promocode/{id}', 'LeadController@delete_promocode');
/*  standardrules controller Route End */

/*  standardrules controller Route start */
Route::get('add-referral', function () {
	$data['content'] = 'admin.referral.add_referral';
	return view('layouts.content', compact('data'));
});
Route::any('add-referrals', 'LeadController@add_referrals');
Route::any('view-referral', 'LeadController@view_referral');
Route::any('edit-referral/{id}', 'LeadController@edit_referral');
Route::any('detele-referral/{id}', 'LeadController@delete_referral');
Route::any('update_referrals', 'LeadController@update_referrals');
/*  standardrules controller Route End */

/*  standardrules controller Route start */
Route::get('add-areservice', function () {
	$data['content'] = 'admin.areservice.add_areservice';
	return view('layouts.content', compact('data'));
});
Route::any('add-areservices', 'LeadController@add_areservice');
Route::any('view-areservice', 'LeadController@view_areservice');
Route::any('edit-areservice/{id}', 'LeadController@edit_areservice');
Route::any('update-areservices', 'LeadController@update_areservice');
Route::any('detele-areservice/{id}', 'LeadController@delete_areservice');
/*  standardrules controller Route End */

/*  Categry controller Route start */
Route::any('add-status', 'StatusController@add_status');
Route::any('listing-status', 'StatusController@listing_status');
Route::any('status-edit/{id}', 'StatusController@edit_status');
Route::any('detele-status/{id}', 'StatusController@delete_status');
Route::any('status-view/{id}', 'StatusController@status_view');
/*  Categry controller Route End */

/*  transastion all route Start */
Route::get('add-products', function () {
	$data['content'] = 'admin.product.add_products';
	return view('layouts.content', compact('data'));
});
Route::any('search-translation-bydate', 'TransactionController@search_translation_bydate');
Route::any('get-transaction/{id}', 'TransactionController@transaction_listin');
Route::any('search-transaction-bydate', 'TransactionController@search_transaction_bydate');
Route::any('client-listing', 'TransactionController@client_listing');
Route::any('add-product', 'ProductController@add_product');
Route::any('view-product', 'ProductController@view_product');
Route::any('delete-product/{id}', 'ProductController@delete_product');
Route::any('view-product/{id}', 'ProductController@product_view');
Route::any('product-edit/{id}', 'ProductController@product_edit');
Route::any('status-change/{id}', 'ProductController@status_change');
Route::any('filter-client', 'TransactionController@filter_client');
Route::any('search-client-bydate', 'ClientController@search_client_bydate');
Route::any('search-status-client', 'ClientController@search_status_client');
/*  transastion all route End */

/* Order all Routes Start */
Route::any('order-list', 'OrderController@view_all_orders');
Route::any('view-order-details/{id}', 'OrderController@view_order_details');
Route::any('admin-moveto-marketplace/{id}', 'OrderController@admin_moveto_marketplace');
/* Order all Routes End */
/* Admin panel All routes End*/
