<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\Category;
use App\Country;
use App\City;
use App\Brand;
use App\User;
use DB;
use Hash;
use Auth;

class CompanyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }
    
    public function change_password_client(Request $request)
    {
        $data = array( 'password' => Hash::make($request->password), 'view_password' =>$request->password);

        User::where('id', $request->editId)->update($data);
        Session::flash('success', 'Password Changed successfully');
        return back();
    }
    public function profile(Request $request)
    {
        $usredata = Country::get();
        $tds = $usredata->toArray();  
        $usre = City::get();
        $citys = $usre->toArray(); 

        return view('web.dashboard.myaccount.myaccount', compact('tds','citys'));
    }
    public function UpdateProfile(Request $request)
    {
        if($request->password){
          $this->validate($request, [
              'password'     => 'required',
              'new_password'     => 'required|min:8',
          ]);
            
          $data = $request->all();

            if(!\Hash::check($data['password'], auth()->user()->password)){
                Session::flash('error', 'Please Enter valid Current password');
                return back();

            }else{
                
                if($request->u_ids != '') {
                    $udata['name'] = $request->name;
                    $udata['password'] = Hash::make($request->new_password);
                    User::where('id', $request->u_ids)->update($udata);
                }
                Session::flash('success', 'Profile updated successfully');
                return back();
            }
        }else{
            $data = $request->all();
            $udata['name'] = $request->name;
            User::where('id', $request->u_ids)->update($udata);
            Session::flash('success', 'Profile updated successfully');
            return back();
        }
    }

    public function UserProfile(Request $request)
    {
        $companydata = User::where('id', Session::get('gorgID'))->first();
        $profileData = Auth()->user();

        $data['content'] = 'admin.user.user-profile';
        return view('layouts.content', compact('data'))->with(['companydata' => $companydata]);
    }

    public function Dashboard(Request $request)
    {
        $userRole = Session::get('userRole');
        $id = Session::get('gorgID');
        $OrgData = DB::table('users')->where('id', $id)->first();

        if($userRole == '1'){      
            $usredata = DB::table('users')->where('users_role', 2)->count();     
            $whitelabel = DB::table('users')->where('users_role', 2)->count();     
            $manager = DB::table('users')->where('users_role', 3)->count();     
            $employee = DB::table('users')->where('users_role', 4)->count();     
            $client = DB::table('users')->where('users_role', 5)->count();    
            $lead = DB::table('leads')->count();     
            $transaction = DB::table('wallet_transaction')->count();     
            $product = DB::table('product')->count();     
            $brand = DB::table('brand')->count();     

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'whitelabel'=>$whitelabel, 'manager'=>$manager, 'employee'=>$employee, 'client'=>$client, 'lead'=>$lead, 'transaction'=>$transaction, 'product'=>$product, 'brand'=>$brand]);
        }
        elseif($userRole == '2'){
            $usredata = DB::table('users')->count();
            $manager = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 3)->count(); 
            $employee = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 4)->count(); 
            $client = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 5)->count(); 
            $lead = DB::table('leads')->where('upload_by', Session::get('gorgID'))->count();
            $product = DB::table('product')->where('upload_by', Session::get('gorgID'))->count(); 

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata , 'manager'=>$manager, 'employee'=>$employee, 'client'=>$client, 'lead'=>$lead, 'product'=>$product]);
        }
        elseif($userRole == '3'){
            $usredata = DB::table('users')->count();
            $employee = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 4)->count(); 
            $client = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 5)->count(); 
            $lead = DB::table('leads')->where('upload_by', Session::get('gorgID'))->count();  

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'employee'=>$employee, 'client'=>$client, 'lead'=>$lead ]);
        }
        elseif($userRole == '4'){
            $usredata = DB::table('users')->count(); 
            $lead = DB::table('leads')->where('upload_by', Session::get('gorgID'))->count(); 

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'lead'=>$lead ]);
        }
        elseif($userRole == '5'){
            $usredata = DB::table('users')->count();  
            return redirect('web-dashboard');
        }
    }

    public function index()
    {
        Session::flash('success', 'login successfully..!');
        return Redirect::action('HomeController@Dashboard');
    }

    /* User routr Start */
    public function total_users(Request $request)
    {
        $total_users = User::all();

        $data['content'] = 'admin.user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata ]);
    }
    public function user_view()
    {
        $usredata = User::where('users_role', 2)->get();

        $data['content'] = 'admin.user.user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata ]);
    }
    
    public function signup_company()
    {
        $usredata = DB::table('company')->get();

        $data['content'] = 'admin.company.signup_company';
        return view('layouts.content', compact('data'))->with(['companydata' => $usredata ]);
    }
    public function registered_company()
    {
        $usredata = DB::table('company')->get();

        $data['content'] = 'admin.company.registered_company';
        return view('layouts.content', compact('data'))->with(['companydata' => $usredata ]);
    }
    public function pending_approval()
    {
        $usredata = DB::table('company')->where('status',0)->get();

        $data['content'] = 'admin.company.pending_approval';
        return view('layouts.content', compact('data'))->with(['companydata' => $usredata ]);
    }
    public function incomplete_documents()
    {
        $usredata = DB::table('company')->get();

        $data['content'] = 'admin.company.incomplete_documents';
        return view('layouts.content', compact('data'))->with(['companydata' => $usredata ]);
    }
    public function rejected_application()
    {
        $usredata = User::where('users_role', 2)->get();

        $data['content'] = 'admin.company.rejected_application';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata ]);
    }

    public function add_company(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        if($files = $request->company_photo){
            $destinationPath = public_path('/company_images/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $company_photo = $insert['photo'] = "$profileImage";
        }
        if($files = $request->front_file){
            $destinationPath = public_path('/company_images/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $front_file = $insert['photo'] = "$profileImage";
        }
        if($files = $request->back_file){
            $destinationPath = public_path('/company_images/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $back_file = $insert['photo'] = "$profileImage";
        }
        
            $data = array(
                'name' => $request->name,
                'country' => $request->country,  
                'email' => $request->email, 
                'phone' => $request->phone, 
                'city' => $request->city, 
                'address' => $request->address, 
                'doc_number' => $request->doc_number,  
                'company_photo' => $company_photo, 
                'exp_date' => $request->exp_date,
                'created_at' => $request->created_at,
                'front_file' => $front_file,
                'back_file' => $back_file
            );
        
            Session::flash('success','Inserted successfully..!');
            $insertData = DB::table('company')->insert($data);
            return back();
         
    }
    
    public function add_signcompany(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        
        if($files = $request->front_file){
            $destinationPath = public_path('/company_images/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $front_file = $insert['photo'] = "$profileImage";
        }
        if($files = $request->back_file){
            $destinationPath = public_path('/company_images/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $back_file = $insert['photo'] = "$profileImage";
        }
        
            $data = array( 
                'doc_number' => $request->doc_number,
                'exp_date' => $request->exp_date,
                'created_at' => $request->created_at,
                'front_file' => $front_file,
                'back_file' => $back_file
            );
        
            Session::flash('success','Inserted successfully..!');
            $insertData = DB::table('company')->insert($data);
            return back();
    }

    public function user_edit($id)
    {
        $editdata = User::where('id', $id)->first();
        $data['content'] = 'admin.user.edit_user';
        return view('layouts.content', compact('data'))->with(['usredata' => $editdata ]);
    }
    public function view_company()
    {
        $getdata = DB::table('company')->get();
        $data['content'] = 'admin.company.view_company';
        return view('layouts.content', compact('data'))->with(['companydata' => $getdata ]);
    }
    public function user_delete($id)
    {
        $customerdata_delete = User::where('id', $id)->delete();
        $statusnull = User::where('upload_by', $id)->get(['id']); /* Get manager lavel Data*/

        foreach ($statusnull as $key => $value) {
            $deletecustomer = User::where('upload_by', $id)->delete();
            $customerdata = User::where('upload_by', $value->id)->get();
            $product = DB::table('product')->where('upload_by', $id)->get();

            /*print_r($product); die;*/    

            foreach ($customerdata as $key => $value2) {
                $deletecustomer = User::where('upload_by', $value->id)->delete();
            }

            foreach ($product as $key => $value3) {
                $productdelete = DB::table('company')->where('upload_by', $id)->delete();
            }
        }

        Session::flash('error', 'Delete successfully.!');
        return back();
    }
    
    public function delete_company($id)
    {
        $customerdata_delete = DB::table('company')->where('id', $id)->delete();

        Session::flash('error', 'Delete successfully.!');
        return back();
    }

    /* Country section Start */
    public function view_countries()
    {
        $countrydata = DB::table('countries')->get();

        $data['content'] = 'admin.countries.manage_country';
        return view('layouts.content', compact('data'))->with(['countrydata' => $countrydata]);
    }

    public function countries_edit($id)
    {
        $data = DB::table('countries')->where('id', $id)->first();
        return Response::json($data);
    }

    public function delete_countries($id)
    {
        $delete = DB::table('countries')->where('id', $id)->delete();
        session()->flash('error', 'Deleted Successfully..!');
        return redirect()->back();
    }
    /* Country section End */

    /* Customers section start */

    public function customer_view()
    {
        $customersdata = User::where('users_role', 3)->get();

        $data['content'] = 'admin.customer.manage_customer';
        return view('layouts.content', compact('data'))->with(['customersdata' => $customersdata ]);
    }

    public function customer_delete($id)
    {
        $delete = DB::table('users')->where('id', $id)->delete();
        session()->flash('error', 'Deleted Successfully..!');
        return redirect()->back();
    }

    public function useremail($y)
    {
        $data = User::where('email', $y)->first();
        if($data!=''){
            return Response::json($data);
        }
    }

    public function upload_user_document(Request $request)
    {   
        $data =array();
        if($request->bill){
            $files = $request->bill;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bill'] = "$profileImage";
        }

        if($request->passport){
            $files = $request->passport;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['passport'] = "$profileImage";
        }

        if($request->bank){
            $files = $request->bank;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bank'] = "$profileImage";
        }        
        
        if(count($data)>0){
            Session::flash('success','Document Updated Successfully..!');
            $updateData = DB::table('users')->where('id', $request->userid)->update($data);
            return back();
        }
        else
        {
            session()->flash('error', 'Select Images..!');
            //$insertData = DB::table('users')->insert($data);
            return back();
        } 
    }

    public function admin_update_document(Request $request,$id)
    {
        $data =array();
        if($request->bill){
            $files = $request->bill;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bill'] = "$profileImage";
        }

        if($request->passport){
            $files = $request->passport;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['passport'] = "$profileImage";
        }

        if($request->bank){
            $files = $request->bank;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bank'] = "$profileImage";
        }        
        
        if(count($data)>0){
            Session::flash('success','Document Updated Successfully..!');
            $updateData = DB::table('users')->where('id', $id)->update($data);
            return back();
        }
        else
        {
            session()->flash('error', 'No Images selected..!');
            return back();
        } 
    }

/* Customers section End */
}
