<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class ProductController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        $this->middleware('role');
    }

    public function web_product(){
        $product = DB::table('product')->where('status', 0)->get();  
        $logged_in = DB::table('users')->where('id', Auth::id())->update(['logged_in'=> 1]);  
        return View("web.dashboard.web_dashboard")->with(['product' => $product]);
    }

    public function filter_brand_year(Request $request){
        /* dd($request->all());*/
        $query = DB::table('product');
        if ($request->brand_id!=0){
            $query->where('brand_id', $request->brand_id);
        }

        if ($request->year!=0){
            $query->where('year', $request->year);
        }

        $product = $query->get();
        /*dd(count($product));*/
       

        return View("web.dashboard.web_dashboard")->with(['product' => $product]);
    }

    public function product_detail($id){
        $data = DB::table('product')
        ->join('brand', 'brand.id', '=', 'product.brand_id')
        ->where('product.id', $id)
        ->select('product.*', 'brand.brand_name')
        ->first();
        return response()->json($data);
    }

    public function product_image_gallery($productId){
        $productdata = DB::table('product_gallery')->where('product_id', $productId)->get();
        return response()->json($productdata);
    }

    public function product_image_edit($id){
        $data = DB::table('product_gallery')->where('id', $id)->first();
        return response()->json($data);
    }

    public function edit_product_image(Request $request){
        if($files = $request->image){
            $destinationPath = public_path('/product_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }
        $updateimage = DB::table('product_gallery')->where('id', $request->image_id)->update(['image'=> $image]);
        Session::flash('success', 'Image update successfully..!');
        return back();
    }

    public function add_product_image(Request $request){
        if($files = $request->image){
            $destinationPath = public_path('/product_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }

        $updateimage = DB::table('product_gallery')->where('id', $request->image_id)->insert(['product_id'=>$request->product_id, 'image'=> $image]);
        Session::flash('success', 'Image insert successfully..!');
        return back();
    }

    public function product_image_delete($id){
        Session::flash('error','Data delete successfully..!');
        $editimage = DB::table('product_gallery')->where('id', $id)->delete(); 
        return back();
    }

    public function filter_whitelabel(Request $request){
        if (Session::get('userRole') == 1) {
            if($request->id!=''){
                $productdata = DB::table('product')->where('upload_by', $request->id)->orderBy('id', 'Desc')->get();
            }elseif ($request->brand_id!='') {
                $productdata = DB::table('product')->where('brand_id', $request->brand_id)->orderBy('id', 'Desc')->get();
            }elseif ($request->status!='') {
                $productdata = DB::table('product')->where('status', $request->status)->orderBy('id', 'Desc')->get();
            }
        }elseif (Session::get('userRole') == 2) {
            if ($request->brand_id!='') {
                $productdata = DB::table('product')->where('upload_by', Session::get('gorgID'))->where('brand_id', $request->brand_id)->orderBy('id', 'Desc')->get();
            }elseif ($request->status!='') {
                $productdata = DB::table('product')->where('upload_by', Session::get('gorgID'))->where('status', $request->status)->orderBy('id', 'Desc')->get();
            }
        }
        $data['content'] = 'admin.product.manage_product';
        return view('layouts.content', compact('data'))->with(['productdata' => $productdata, 'whitelabel_id'=>$request->id,'brand_id'=>$request->brand_id ]);
    }

    public function filter_status(Request $request){

        if (Session::get('userRole') == 1) {
            $productdata = DB::table('product')->where('status', $request->status)->orderBy('id', 'Desc')->get();
        }else{
            $productdata = DB::table('product')->where('upload_by', Session::get('gorgID'))->where('status', $request->status)->orderBy('id', 'Desc')->get();
        }    

        $data['content'] = 'admin.product.manage_product';
        return view('layouts.content', compact('data'))->with(['productdata' => $productdata, 'status'=>$request->status]);
    }

    public function filter_brand(Request $request){

        if (Session::get('userRole') == 1) {
            $productdata = DB::table('product')->where('brand_id', $request->brand_id)->orderBy('id', 'Desc')->get();
        }else{
            $productdata = DB::table('product')->where('upload_by', Session::get('gorgID'))->where('brand_id', $request->brand_id)->orderBy('id', 'Desc')->get();
        }
        $data['content'] = 'admin.product.manage_product';
        return view('layouts.content', compact('data'))->with(['productdata' => $productdata,'brand_id'=>$request->brand_id ]);
    }

    public function status_change($id){
        $product = DB::table('product')->where('id', $id)->first();

        if($product->status == 0){
            $updateData = DB::table('product')->where('id', $id)->update(['status' => 1]);
            Session::flash('success','Status Decline successfully..!');
            return back();
        }else{
            $updateData = DB::table('product')->where('id', $id)->update(['status' => 0]);
            Session::flash('success','Status Approved successfully..!');
            return back();
        }
    }

    public function get_model($brandId){
        $data = DB::table('category')->where('brand_id', $brandId)->get();
        return response()->json($data);
    }

    public function add_product(Request $request){
        if(Session::get('userRole') == 1){
            $status = 0;
        }else{
            $status = 1;
        }
        $features = implode(",", $request->features);
            $data = array(
                'upload_by' => Session::get('gorgID'),  
                'brand_id' => $request->brand_id,  
                'model_name' => $request->model_name,  
                'id_no' => $request->id_no,  
                'year' => $request->year,  
                'percentage' => $request->percentage,  
                'features' => $features,  
                'price' => $request->price,  
                'status' => $status,  
                'description' => $request->description,         
                'created_at' => date('Y-m-d H:i:s'),        
            );    
         
        if($request->edit_id!= ''){
            Session::flash('success','Updated successfully..!');
            $updateData = DB::table('product')->where('id', $request->edit_id)->update($data);
            return redirect('view-product');
        }
        else{     
            $insertData = DB::table('product')->insertGetId($data);

            if ($request->hasFile('image')) {
                foreach ($request->image as $item){
                    $var = date_create();
                    $time = date_format($var, 'YmdHis');
                    $imageName = $time . '-' . $item->getClientOriginalName();
                    $item->move(public_path() . '/product_image', $imageName);
                    $arr[] = $imageName;
                    $imageinsert = DB::table('product_gallery')->insert(['product_id' => $insertData, 'image' => $imageName, 'created_at' => date('Y-m-d H:i:s')]);
                }
            }
            Session::flash('success','Inserted successfully..!');
            return redirect('view-product');
        } 
    }

    public function view_product(){
        if(session::get('userRole') == 1){
            $productdata = DB::table('product')->orderBy('id', 'Desc')->get();
        }else{
            $productdata = DB::table('product')->where('upload_by', session::get('gorgID'))->orderBy('id', 'Desc')->get();
        }  

        $data['content'] = 'admin.product.manage_product';
        return view('layouts.content', compact('data'))->with(['productdata' => $productdata ]);
    }

    public function product_view($id){
        $view_product = DB::table('product')->where('id', $id)->first();
        $data['content'] = 'admin.product.view_product';
        return view('layouts.content', compact('data'))->with(['view_product' => $view_product ]);
    }

    public function product_edit($id){
        $edit_product = DB::table('product')->where('id', $id)->first();
        $data['content'] = 'admin.product.edit_products';
        return view('layouts.content', compact('data'))->with(['edit_product' => $edit_product ]);
    }

    public function delete_product($id){
        $delete = DB::table('product')->where('id', $id)->delete();
        Session::flash('error','Product data delete successfully..!');
        return back();
    }
}
