<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class ClientController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }

    public function add_issafe(Request $request)
    {        
        $data = array(
                'user_id' => $_GET['user_id'],  
                'watch_id' => $_GET['watch_id'], 
            );  
        $insertData = DB::table('issafe')->insert($data);
        if($insertData){
            return 1;
        }   else{
            return 2;
        }
        //return redirect('view-client');
    }

    public function add_marketplace()
    {
        $data = array(
                'user_id' => $_GET['user_id'],  
                'watch_id' => $_GET['watch_id'], 
            );  
        $insertData = DB::table('marketplace')->insert($data);
        $customerdelete = DB::table('issafe')->where('id',$_GET['id'])->delete();
        if($insertData){
            return 1;
        }   else{
            return 2;
        }
    }

    public function add_client(Request $request)
    {
        if($files = $request->image){
            $destinationPath = public_path('/profile_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }

        if($request->image!=''){
            $data = array(
                'name' => $request->name,  
                'upload_by' => Session::get('gorgID'),  
                'email' => $request->email, 
                'phone' => $request->phone, 
                'address' => $request->address, 
                'country_id' => $request->country_id, 
                'dob' => $request->dob, 
                'gender' => $request->gender, 
                'password' => Hash::make($request->password), 
                'view_password' => $request->password,
                'profile_image' =>  $image, 
                'created_at' => date('Y-m-d H:i:s'),
                'users_role' => 5,
            );    
        }else{
            $data = array(
                'name' => $request->name,  
                'upload_by' => Session::get('gorgID'),  
                'email' => $request->email, 
                'phone' => $request->phone, 
                'address' => $request->address, 
                'country_id' => $request->country_id,
                'dob' => $request->dob, 
                'gender' => $request->gender, 
                'password' => Hash::make($request->password), 
                'view_password' => $request->password,
                'created_at' => date('Y-m-d H:i:s'),
                'users_role' => 5,
            );
    }

        if($request->edit_id!= ''){
            Session::flash('success','Updated successfully..!');
            $updateData = DB::table('users')->where('id', $request->edit_id)->update($data);
            return redirect('view-client');
        }
        else{
            Session::flash('success','Inserted successfully..!');
            $insertData = DB::table('users')->insert($data);
            return redirect('view-client');
        } 
    }
  
    public function view_client()
    {
        if(Session::get('userRole') == 1){
            $client = User::where('users_role', 5)->get();
        }elseif(Session::get('userRole') == 2){
            $client = User::where('users_role', 5)->where('upload_by', Session::get('gorgID'))->get();
        }    

        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client ]);
    }
    
    public function search_client_bydate(Request $request)
	{
	    $from =  date("Y-m-d", strtotime($request->from_date));
        $to   = date("Y-m-d", strtotime($request->end_date));
        
	    if(Session::get('userRole') == 1){
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->get();
        }elseif(Session::get('userRole') == 2){
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->where('upload_by', Session::get('gorgID'))->get();
        }    
        
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client ]);
	}

    public function edit_client($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.client.edit_client';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }

    public function filter_client(Request $request){
        
        if($request->employee_id!=''){
            $id = $request->employee_id ?? '';
        }elseif ($request->whitelabel_id!='') {
            $id = $request->whitelabel_id ?? '';
        }elseif ($request->manager_id!='') {
            $id = $request->manager_id ?? '';
        }
        $client = User::where('users_role', 5)->where('upload_by', $request->id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid'=>$request->id ]);
    }
  
    public function client_view_data($id)
    {
        $viewclient = User::where('id', $id)->first();
        $data['content'] = 'admin.client.view_client';
        return view('layouts.content', compact('data'))->with(['viewclient' => $viewclient ]);
    }
    
    public function search_status_client(Request $request)
    {
        $client = User::where('users_role', 5)->where('status', $request->status_id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid'=>$request->id ]);
    }

    public function logout()
    {
        $logged_in = DB::table('users')->where('id', Auth::id())->update(['logged_in'=> 0]); 
        if(session::get('userRole') == 1){
            Auth::logout();
            Session::flash('success','Logout successfully..!');
            return redirect('/');
        }if(session::get('userRole') == 2){
            Auth::logout();
            return redirect('/');
        }if(session::get('userRole') == 3){
            Auth::logout();
            return redirect('/');
        }if(session::get('userRole') == 4){
            Auth::logout();
            return redirect('/');
        }if(session::get('userRole') == 5){
            Auth::logout();
            return redirect('/');
        }
    }
    
    public function managerlogout()
    {
        //$logged_in = DB::table('manager')->where('id', Auth::id())->update(['logged_in'=> 0]); 
        /*if(session::get('userRole') == 1){
            Auth::logout();
            Session::flash('success','Logout successfully..!');
            return redirect('/manager');
        }if(session::get('userRole') == 2){
            Auth::logout();
            return redirect('/manager');
        }if(session::get('userRole') == 3){
            Auth::logout();
            return redirect('/manager');
        }if(session::get('userRole') == 4){
            Auth::logout();
            return redirect('/manager');
        }if(session::get('userRole') == 5){
            Auth::logout();
            return redirect('/manager');
        }*/
        Auth::logout();
        return redirect('/manager');
    }

    public function client_password_change(Request $request)
    {
        $clientdetails = DB::table('users')->where('id', session::get('gorgID'))->first();
        $data = array(
            'password' => Hash::make($request->newpassword),
        );

        if($clientdetails!=''){
            $updateData = DB::table('users')->where('id', session::get('gorgID'))->update($data);
            return redirect()->back()->with('message', 'IT WORKS!');
        } 
    }
    public function client_update_profile(Request $request)
    {
        $data = array(
            'name'       => $request->username,  
            //'email'    => $request->email, 
            'phone'      => $request->mobile, 
            'address'    => $request->address, 
            'country_id' => $request->country,
            'city_id'    => $request->city,
        );

        $insertData = DB::table('users')->where('id', $request->userid)->update($data);        
        return redirect()->back()->with('message', 'Profile Updated successfully.');
    }

    public function view_comment(Request $request,$id)
    {
        $comment = DB::table('leadappointment')->where('event_id',$id)->get();
        $lead = DB::table('leads')->get(); 
        $client = DB::table('users')->where('users_role', 5)->get();
        $data['content'] = 'admin.client.view_comment';
        return view('layouts.content', compact('data'))->with(['comment' => $comment,'lead' => $lead,'client' => $client]);
    }

    public function check_client_document(Request $request,$id)
    {
        $document = DB::table('users')->where('id', $id)->get();
        $data['content'] = 'admin.client.manage_documents';
        return view('layouts.content', compact('data'))->with(['document' => $document]);
    }
}

