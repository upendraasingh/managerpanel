<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class CmsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }
    
    public function add_page(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
                'app' => $request->app, 
                'page_type' => $request->page_type, 
                'page_title' => $request->page_title, 
                'description' => $request->description
            );
        Session::flash('success','Added successfully..!');
        $updateData = DB::table('pages')->insert($data);
        return back();
    }
    
    public function add_pushnotification(Request $request)
    {
        $data = array(
                'web_key' => $request->web_key, 
                'rest_key' => $request->rest_key, 
                'application_key' => $request->application_key, 
                'user_rest_key' => $request->user_rest_key,
                'driver_application_key' => $request->driver_application_key, 
                'driver_rest_key' => $request->driver_rest_key, 
                'merchant_application_key' => $request->merchant_application_key, 
                'merchant_rest_key' => $request->merchant_rest_key
            );
        Session::flash('success','Added successfully..!');
        $updateData = DB::table('notification_setting')->insert($data);
        return back();
    }

    public function update_page(Request $request)
    {
        /*if($files = $request->image){
            $destinationPath = public_path('/profile_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }*/

        
        $data = array(
                'app' => $request->app, 
                'page_type' => $request->page_type, 
                'page_title' => $request->page_title, 
                'description' => $request->description
            );

        
            Session::flash('success','Updated successfully..!');
            $updateData = DB::table('pages')->where('id', $request->id)->update($data);
            return back();
        
         
    }
  
    public function view_page()
    {
        $categorydata = DB::table('pages')->get();
        $data['content'] = 'admin.cms.view_page ';
        return view('layouts.content', compact('data'))->with(['usredata' => $categorydata ]);
    }
    public function view_make()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.make.manage_make';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    
    public function view_model()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.model.manage_model';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    
    public function view_document()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.document.manage_document';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    public function view_pricing()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.pricing.manage_pricing';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    public function view_ewallet()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.ewallet.manage_ewallet';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    public function view_payment()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.payment.manage_payment';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    
    public function view_standardrules()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.standardrules.manage_standardrules';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata ]);
    }
    
    public function view_language()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.cms.language_string';
        return view('layouts.content', compact('data'))->with(['usredata' => $categorydata ]);
    }
    
    public function request_posting()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.ewallet.request_posting';
        return view('layouts.content', compact('data'))->with(['usredata' => $categorydata ]);
    }
    
    public function settlements()
    {
        $categorydata = DB::table('users')->get();
        $data['content'] = 'admin.ewallet.settlements';
        return view('layouts.content', compact('data'))->with(['usredata' => $categorydata ]);
    }
    
    public function search_client_bydate(Request $request)
	{
	    $from =  date("Y-m-d", strtotime($request->from_date));
        $to   = date("Y-m-d", strtotime($request->end_date));
        
	    if(Session::get('userRole') == 1){
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->get();
        }elseif(Session::get('userRole') == 2){
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->where('upload_by', Session::get('gorgID'))->get();
        }    
        
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client ]);
	}

    public function edit_page($id){
        
        $editclient = DB::table('pages')->where('id', $id)->first();
        $data['content'] = 'admin.cms.edit_page';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_language($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.cms.edit_language';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_make($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.make.edit_make';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    
    public function edit_model($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.model.edit_model';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_document($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.document.edit_document';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_pricing($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.pricing.edit_pricing';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_ewallet($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.ewallet.edit_ewallet';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_payment($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.payment.edit_payment';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }
    public function edit_standardrules($id){
        $editclient = User::where('id', $id)->first();
        $data['content'] = 'admin.standardrules.edit_standardrules';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient ]);
    }

    public function filter_client(Request $request){
        
        if($request->employee_id!=''){
            $id = $request->employee_id ?? '';
        }elseif ($request->whitelabel_id!='') {
            $id = $request->whitelabel_id ?? '';
        }elseif ($request->manager_id!='') {
            $id = $request->manager_id ?? '';
        }
        $client = User::where('users_role', 5)->where('upload_by', $request->id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid'=>$request->id ]);
    }
  
    public function client_view_data($id)
    {
        $viewclient = User::where('id', $id)->first();
        $data['content'] = 'admin.client.view_client';
        return view('layouts.content', compact('data'))->with(['viewclient' => $viewclient ]);
    }
    
    public function search_status_client(Request $request)
    {
        $client = User::where('users_role', 5)->where('status', $request->status_id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid'=>$request->id ]);
    }

    public function client_password_change(Request $request)
    {
        $clientdetails = DB::table('users')->where('id', session::get('gorgID'))->first();
        $data = array(
            'password' => Hash::make($request->newpassword),
        );

        if($clientdetails!=''){
            $updateData = DB::table('users')->where('id', session::get('gorgID'))->update($data);
            return redirect()->back()->with('message', 'IT WORKS!');
        } 
    }
}

