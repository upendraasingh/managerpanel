<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\Category;
use App\Brand;
use App\User;
use DB;
use Hash;
use Auth;

class TransactionController extends Controller
{
	public function withdraw_amount(Request $request){
		$permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			// Output: 54esmdr0qf
		$number =  'TRN'.substr(str_shuffle($permitted_chars), 0, 6);
		$getclient = DB::table('wallet_transaction')->where('client_id', session::get('gorgID'))->orderBy('id', 'Desc')->first();
		
		if($getclient->available_balance > $request->amount){
			if($getclient!='' && $getclient->status!=1){
			$total_balance = $getclient->available_balance - $request->amount;

			$data = array(
				'trans_id' => $number,
				'client_id' => Session::get('gorgID'), 
				'withdrawal' => $request->amount, 
				'status' => 1, 
				'cr_dr_status' => 1, 
				'available_balance' => $total_balance, 
				'date' => date('Y-m-d H:i:s'), 
			);	

			$insertData = DB::table('wallet_transaction')->insert($data);
  			return redirect('wallet');
		}else{
			//echo "Your balance not Approved By admin,Wait for admin Approval.";
			Session::flash('error','Your balance not Approved By admin,Wait for admin Approval.');
		}
		}else{
			Session::flash('error','You donot have enough Balance.');
			//echo "You don't have enough Balance";
			return back();
		}
	}

	public function withdraw_amount_admin(Request $request)
	{
		//dd($request->client_id);
		$permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			// Output: 54esmdr0qf
		$number =  'TRN'.substr(str_shuffle($permitted_chars), 0, 6);
		$getclient = DB::table('wallet_transaction')->where('client_id', $request->client_id)->orderBy('id', 'Desc')->first();
		
		if($getclient->available_balance >= $request->amount){
			if($getclient!='' && $getclient->status!=1){
			$total_balance = $getclient->available_balance - $request->amount;

			$data = array(
				'trans_id' => $number,
				'client_id' => $request->client_id, 
				'withdrawal' => $request->amount, 
				'status' => 0, 
				'cr_dr_status' => 1, 
				'available_balance' => $total_balance, 
				'date' => date('Y-m-d H:i:s'), 
			);	

			$insertData = DB::table('wallet_transaction')->insert($data);
			Session::flash('success','Money withdrawal successfully..!');
  			return back();
		}else{
			//echo "Your balance not Approved By admin,Wait for admin Approval.";
			Session::flash('error','Your balance not Approved By admin,Wait for admin Approval.');
		}
		}else{
			Session::flash('error','You donot have enough Balance.');
			//echo "You don't have enough Balance";
			return back();
		}
	}

	public function add_amount(Request $request){
		$permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		// Output: 54esmdr0qf
		$number =  'TRN'.substr(str_shuffle($permitted_chars), 0, 6);
			
		if($request->admin_add_money!=''){

			$getclient = DB::table('wallet_transaction')->where('client_id', $request->client_id)->orderBy('id', 'Desc')->first();

			if($getclient!=''){

				$total_balance = $getclient->available_balance + $request->deposit;
				
				$data = array(
					'trans_id' =>$number,
					'client_id' => $request->client_id, 
					'deposit' => $request->deposit, 
					'payment_mode' => $request->bonus,
					'status' => 0, 
					'cr_dr_status' => 0, 
					'available_balance' => $total_balance, 
					'date' => date('Y-m-d H:i:s'), 
				);	

			}	else{

				$data = array(
					'trans_id' =>$number,
					'client_id' => $request->client_id, 
					'deposit' => $request->deposit, 
					'payment_mode' => $request->bonus,
					'status' => 1, 
					'cr_dr_status' => 0, 
					'available_balance' => $request->deposit, 
					'date' => date('Y-m-d H:i:s'), 
				);

			}

			Session::flash('success','add money successfully..!');
			$insertData = DB::table('wallet_transaction')->insert($data);

			if($request->admin_add_money!=''){

				return back();	      		
	      	}else{

	      		return redirect('client-listing');
	      	}
	    }else{
	    	$getclient = DB::table('wallet_transaction')->where('client_id', session::get('gorgID'))->orderBy('id', 'Desc')->first();
	    	if($getclient!=''){
	    		$total_balance = $getclient->available_balance + $request->amount;
				$data = array(
					'trans_id' =>$number,
					'client_id' => Session::get('gorgID'), 
					'deposit' => $request->amount, 
					'status' => 1, 
					'cr_dr_status' => 0, 
					'available_balance' => $total_balance, 
					'date' => date('Y-m-d H:i:s'), 
				);	
			}else{
		    	$data = array(
		    		'trans_id' =>$number,
					'client_id' => Session::get('gorgID'), 
					'deposit' => $request->amount, 
					'status' => 1, 
					'cr_dr_status' => 0, 
					'available_balance' => $request->amount, 
					'date' => date('Y-m-d H:i:s'), 
				);
		    }
		    $insertData = DB::table('wallet_transaction')->insert($data);
		    return redirect('wallet');
			
	      }
	}

	public function transaction_listin($id){
		$transaction = DB::table('wallet_transaction')->where('client_id', $id)->orderBy('id')->get();
		/*print_r($id); die;*/		
    	$data['content'] = 'admin.transaction.manage_transaction';
    	return view('layouts.content', compact('data'))->with(['transaction' => $transaction, 'id'=> $id]);
	}

	public function client_listing(){
		/*$client = DB::table('users')->where('users_role', 5)->orderBy('name')->get();*/
		$withdrawal = DB::table('wallet_transaction')->where('withdrawal',null)->orderBy('id','DESC')->get();
		$deposit = DB::table('wallet_transaction')->where('deposit',null)->orderBy('id','DESC')->get();
		$bonus = DB::table('wallet_transaction')->where('withdrawal',null)->orderBy('id','DESC')->get();
		/*dd($withdrawal);*/
		
    	$data['content'] = 'admin.transaction.manage_client';
    	return view('layouts.content', compact('data'))->with(['bonus' => $bonus,'withdrawal' => $withdrawal,'deposit' => $deposit ]);
	}
	
	public function search_translation_bydate(Request $request)
	{
        $from =  date("Y-m-d", strtotime($request->from_date));
        $to   = date("Y-m-d", strtotime($request->end_date));
        
        $withdrawal = DB::table('wallet_transaction')->where('withdrawal',null)->whereBetween('date', [$from, $to])->orderBy('id','DESC')->get();
		$deposit = DB::table('wallet_transaction')->where('deposit',null)->whereBetween('date', [$from, $to])->orderBy('id','DESC')->get();
		$bonus = DB::table('wallet_transaction')->where('withdrawal',null)->whereBetween('date', [$from, $to])->orderBy('id','DESC')->get();
        
        $data['content'] = 'admin.transaction.manage_client';
        Session::flash('success','Record Found successfully..!');
        return view('layouts.content', compact('data'))->with(['bonus' => $bonus,'withdrawal' => $withdrawal,'deposit' => $deposit ]);
	}

	public function filter_client(Request $request){
		
		if($request->employee_id!=''){
            $id = $request->employee_id ?? '';
        }elseif ($request->whitelabel_id!='') {
            $id = $request->whitelabel_id ?? '';
        }elseif ($request->manager_id!='') {
            $id = $request->manager_id ?? '';
        }
		if (Session::get('userRole') == 1) {
			$client = DB::table('users')->where('upload_by', $request->id)->where('users_role' , 5)->orderBy('name')->get();
		}else{
			$client = DB::table('users')->where('id', $request->client_id)->where('upload_by',Session::get('gorgID'))->orderBy('name')->get();
		}
		$withdrawal = DB::table('wallet_transaction')->where('withdrawal',null)->where('client_id', $id)->orderBy('id','DESC')->get();
		$deposit = DB::table('wallet_transaction')->where('deposit',null)->where('client_id', $id)->orderBy('id','DESC')->get();
		$bonus = DB::table('wallet_transaction')->where('withdrawal',null)->where('client_id', $id)->orderBy('id','DESC')->get();
		
    	$data['content'] = 'admin.transaction.manage_client';
    	return view('layouts.content', compact('data'))->with(['bonus' => $bonus,'client' => $client,'withdrawal' => $withdrawal,'deposit' => $deposit,'whitelabel_id'=>$request->whitelabel_id, 'manager_id'=>$request->manager_id, 'employee_id'=>$request->employee_id ]);
	}
	
	public function search_status_transaction(Request $request){
		
		if (Session::get('userRole') == 1) {
			$client = DB::table('users')->where('upload_by', $request->id)->where('users_role' , 5)->orderBy('name')->get();
		}else{
			$client = DB::table('users')->where('id', $request->client_id)->where('upload_by',Session::get('gorgID'))->orderBy('name')->get();
		}
		$withdrawal = DB::table('wallet_transaction')->where('withdrawal',null)->where('status', $request->status_id)->orderBy('id','DESC')->get();
		$deposit = DB::table('wallet_transaction')->where('deposit',null)->where('status', $request->status_id)->orderBy('id','DESC')->get();
		$bonus = DB::table('wallet_transaction')->where('withdrawal',null)->where('status', $request->status_id)->orderBy('id','DESC')->get();
		
    	$data['content'] = 'admin.transaction.manage_client';
    	return view('layouts.content', compact('data'))->with(['bonus' => $bonus,'client' => $client,'withdrawal' => $withdrawal,'deposit' => $deposit,'status_id'=>$request->status_id]);
	}
	public function update_transaction(Request $request,$status,$id)
	{
		if($status==1){

			$data = array(
				'status' => 0,
			);

		}	else{

			$data = array(
				'status' => 1,
			);	
		}	

		if($status != '' && $id != ''){
			$updateData = DB::table('wallet_transaction')->where('id', $id)->update($data);
			Session::flash('success','Updated successfully..!');			
			return redirect('client-listing');
		}
    }

    public function search_transaction_bydate(Request $request) {

		$from =  date("Y-m-d", strtotime($request->from_date));
		$to   =  date("Y-m-d", strtotime($request->end_date));

		//$leads = DB::table('leads')->whereBetween('created_at', [$from, $to])->get();

		if (Session::get('userRole') == 1) {
			$client = DB::table('users')->where('upload_by', $request->id)->where('users_role' , 5)->orderBy('name')->get();
		}else{
			/*echo "hello"; die;*/
			$client = DB::table('users')->where('id', $request->client_id)->where('upload_by',Session::get('gorgID'))->orderBy('name')->get();
		}

		$withdrawal = DB::table('wallet_transaction')->where('withdrawal',null)->whereBetween('date', [$from, $to])->orderBy('id','DESC')->get();
		$deposit = DB::table('wallet_transaction')->where('deposit',null)->whereBetween('date', [$from, $to])->orderBy('id','DESC')->get();
		$bonus = DB::table('wallet_transaction')->where('withdrawal',null)->whereBetween('date', [$from, $to])->orderBy('id','DESC')->get();

		//if(sizeof($withdrawal)>0){
			$data['content'] = 'admin.transaction.manage_client';
			Session::flash('success','Record Found successfully..!');
			return view('layouts.content', compact('data'))->with(['bonus' => $bonus,'client' => $client,'withdrawal' => $withdrawal,'deposit' => $deposit]);
		//}else{
			/*Session::flash('error','No Record Found..!');
			$data['content'] = 'admin.transaction.manage_client';
			return view('layouts.content', compact('data'))->with(['client' => $client,'withdrawal' => $withdrawal,'deposit' => $deposit]);*/
		//}
	} 
}