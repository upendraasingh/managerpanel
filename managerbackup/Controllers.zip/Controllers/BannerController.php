<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\Banner;
use App\UnitsMeasurement;
use App\AccountType;
use App\Options;
use App\Styles;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class BannerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }
    public function add_issafe(Request $request)
    {
        $data = array(
            'user_id' => $_GET['user_id'],
            'watch_id' => $_GET['watch_id'],
        );
        $insertData = DB::table('issafe')->insert($data);
        if ($insertData) {
            return 1;
        } else {
            return 2;
        }
        //return redirect('view-client');
    }

    public function add_marketplace()
    {
        $data = array(
            'user_id' => $_GET['user_id'],
            'watch_id' => $_GET['watch_id'],
        );
        $insertData = DB::table('marketplace')->insert($data);
        $customerdelete = DB::table('issafe')->where('id', $_GET['id'])->delete();
        if ($insertData) {
            return 1;
        } else {
            return 2;
        }
    }
    public function add_unit(Request $request)
    {
        // dd($request->all());
        // $validator = Validator::make($request->all(), [
        //     'bannerName'         =>  'required',
        //     'bannerDescription'          =>  'required',
        //     'status'              => 'required',
        // ]);
        // if ($validator->fails()) {
        //     return back()->withErrors($validator)->withInput();
        // }
        try {
            $bannerData =  UnitsMeasurement::create([
                'unitName'                => $request->unitName,
                'unitDescription'         => $request->unitDescription,
                'status'           => $request->status,
            ]);
            return redirect('/view-unit')->with(array('status' => 'success', 'message' => 'New Unit Successfully created!'));
        } catch (\Exception $e) {
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }

    public function add_banner(Request $request)
    {
        // dd($request->all());
        // $validator = Validator::make($request->all(), [
        //     'bannerName'         =>  'required',
        //     'bannerDescription'          =>  'required',
        //     'status'              => 'required',
        // ]);
        // if ($validator->fails()) {
        //     return back()->withErrors($validator)->withInput();
        // }
        try {
            $bannerData =  Banner::create([
                'bannerName'                => $request->bannerName,
                'bannerDescription'         => $request->bannerDescription,
                'status'           => $request->status,
            ]);

            if ($request->hasFile('bannerImage')) {
                $user = Banner::find($bannerData->id);
                $file = $request->file('bannerImage');
                $filename = date('YmdHis') . "-" . $file->getClientOriginalName();
                $file->move('public/uploads/bannerImage/', $filename);
                $user->bannerImage = $filename;
                $user->save();
            }
            return redirect('/view-banner')->with(array('status' => 'success', 'message' => 'New Banner Successfully created!'));
        } catch (\Exception $e) {
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }


        /*  if($files = $request->image){
            $destinationPath = public_path('/profile_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }

        if($request->image!=''){
            $data = array(
                'name' => $request->name,  
                'upload_by' => Session::get('gorgID'),  
                'email' => $request->email, 
                'phone' => $request->phone, 
                'address' => $request->address, 
                'country_id' => $request->country_id, 
                'dob' => $request->dob, 
                'gender' => $request->gender, 
                'password' => Hash::make($request->password), 
                'view_password' => $request->password,
                'profile_image' =>  $image, 
                'created_at' => date('Y-m-d H:i:s'),
                'users_role' => 5,
            );    
        }else{
            $data = array(
                'name' => $request->name,  
                'upload_by' => Session::get('gorgID'),  
                'email' => $request->email, 
                'phone' => $request->phone, 
                'address' => $request->address, 
                'country_id' => $request->country_id,
                'dob' => $request->dob, 
                'gender' => $request->gender, 
                'password' => Hash::make($request->password), 
                'view_password' => $request->password,
                'created_at' => date('Y-m-d H:i:s'),
                'users_role' => 5,
            );
    }

        if($request->edit_id!= ''){
            Session::flash('success','Updated successfully..!');
            $updateData = DB::table('users')->where('id', $request->edit_id)->update($data);
            return redirect('view-client');
        }
        else{
            Session::flash('success','Inserted successfully..!');
            $insertData = DB::table('users')->insert($data);
            return redirect('view-banner');
        } */
    }

    public function view_banner(Request $request)
    {
        if($request->bannerName !=''){
            $categorydata = DB::table('banners')->where('bannerName',$request->bannerName)->get();
        }else{
            $categorydata = DB::table('banners')->get();
        }
        //$categorydata = Banner::all();
       
        $data['content'] = 'admin.banner.manage_banner';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function show_banner($id){
        $editclient = Banner::where('id', $id)->first();
        $data['content'] = 'admin.banner.show_banner';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }

    public function view_unit(Request $request)
    {
        if($request->view_unit !=''){
            $categorydata = DB::table('units_measurement')->where('view_unit',$request->view_unit)->get();  
        }else{
            $categorydata = DB::table('units_measurement')->get();
        }
        
        // dd($categorydata);
        $data['content'] = 'admin.unit.manage_unit';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }

    public function view_style(Request $request)
    {
        if($request->style_name !=''){
            $categorydata = Styles::where('style_name',$request->style_name)->get();
        }else{
            $categorydata = Styles::all();
        }
        // dd($categorydata);
        $data['content'] = 'admin.style.manage_style';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function add_style(Request $request)
    {
        // dd($request->all());
        $validator = Validator::make($request->all(), [
            'style_name'          => 'required',
            'description'         => 'required',
            'status'         =>  'required'
        ]);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        try {
            $universityData =  Styles::create([
                'style_name'      => strip_tags($request->style_name),
                'description'     => strip_tags($request->description),
                "status"          => $request->status,
            ]);
            return redirect('/view-style')->with(array('status' => 'success', 'message' => 'New Style Successfully created!'));
        } catch (\Exception $e) {
            // return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }
    public function edit_style($id)
    {
        $editclient = Styles::find($id);
        $data['content'] = 'admin.style.edit_style';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function updateStyle(Request $request, $id)
    {
        // dd($request->all());
        try {
            $stylesData = Styles::find($id);
            $updateData = array(
                "style_name" => $request->has('style_name') ? strip_tags($request->style_name) : "",
                "description" => $request->has('description') ? strip_tags($request->description) : "",
                "status" => $request->has('status') ? $request->status : "",

            );
            $stylesData->update($updateData);

            return redirect('/view-style')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }
    public function add_options(Request $request)
    {
        try {
            $optionsData =  Options::create([
                'options_mame'      => strip_tags($request->options_mame),
                'description'       => strip_tags($request->description),
                "status"            => $request->status,
            ]);

            return redirect('/view-options')->with(array('status' => 'success', 'message' => 'New Options Successfully created!'));
        } catch (\Exception $e) {
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }

    public function view_options(Request $request)
    {
        if ($request->options_name != '') {
            $categorydata = Options::where('options_name',$request->options_name)->get();
        } else {
            $categorydata = Options::all();
        }
        $data['content'] = 'admin.options.manage_options';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }

    public function edit_options($id)
    {
        $editclient = Options::find($id);
        // dd($editclient);
        $data['content'] = 'admin.options.edit_options';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function updateOptions(Request $request, $id)
    {
        // dd($id);
        try {
            $optionsData = Options::find($id);
            $updateData = array(
                "options_name" => $request->has('options_name') ? strip_tags($request->options_name) : "",
                "description" => $request->has('description') ? strip_tags($request->description) : "",
                "status" => $request->has('status') ? $request->status : "",
            );
            $optionsData->update($updateData);
            return redirect('/view-options')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }

    public function view_account(Request $request)
    {
        //dd($request->all());
        if($request->accountName !=''){
            $categorydata = DB::table('account_type')->where('accountName',$request->accountName)->get();
        }else{
            $categorydata = DB::table('account_type')->get();
        }
        
        //dd($categorydata);
        $data['content'] = 'admin.account.manage_account';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function add_account(Request $request)
    {
        // dd($request->all());
        // $validator = Validator::make($request->all(), [
        //     'accountName'         =>  'required',
        //     'description'          =>  'required',
        //     'status'              => 'required',
        //     'email'             => 'required',
        //     'phone'             =>  'required',
        // ]);
        // if ($validator->fails()) {
        //     return back()->withErrors($validator)->withInput();
        // }
        try {
            $studentData =  AccountType::create([
                'accountName'      => strip_tags($request->accountName),
                'description'       => strip_tags($request->description),
                'status'           => $request->status,
            ]);

            return redirect('/view-account')->with(array('status' => 'success', 'message' => 'New Acount Type Successfully created!'));
        } catch (\Exception $e) {
            //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }

    public function edit_account($id)
    {
        $editclient = DB::table('account_type')->where('id', $id)->first();
        $data['content'] = 'admin.account.edit_account';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function update_account(Request $request, $id)
    {
        // dd($request->all());
        try {
            $accountData = AccountType::find($id);
            $updateData = array(
                "accountName"     => $request->has('accountName') ? strip_tags($request->accountName) : "",
                "description"      => $request->has('description') ? strip_tags($request->description) : "",
                "status"          => $request->has('status') ? $request->status : "",
            );
            $accountData->update($updateData);
            return redirect('/view-account')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }

    public function search_client_bydate(Request $request)
    {
        $from =  date("Y-m-d", strtotime($request->from_date));
        $to   = date("Y-m-d", strtotime($request->end_date));

        if (Session::get('userRole') == 1) {
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->get();
        } elseif (Session::get('userRole') == 2) {
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->where('upload_by', Session::get('gorgID'))->get();
        }

        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client]);
    }

    public function edit_banner($id)
    {
        $editclient = Banner::where('id', $id)->first();
        $data['content'] = 'admin.banner.edit_banner';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function update_banner(Request $request, $id)
    {
        // dd($request->all());
        // $validator = Validator::make($request->all(), array(
        //     'firstName'     => 'required',
        //     'lastName'      => 'required',
        //     'name'          => 'required',
        //     'email'         => 'required',
        //     'phone'         => 'required',
        // ));
        // if ($validator->fails()) {
        //     return back()->withErrors($validator)->withInput();
        // }
        try {
            $bannerData = Banner::find($id);
            $updateData = array(
                "bannerName"            => $request->has('bannerName') ? $request->bannerName : "",
                "bannerDescription"     => $request->has('bannerDescription') ? $request->bannerDescription : "",
                "status"                  => $request->has('status') ? $request->status : "",
            );
            $bannerData->update($updateData);
            if ($request->hasFile('bannerImage')) {
                $user = Banner::find($bannerData->id);
                $file = $request->file('bannerImage');
                $filename = date('YmdHis') . "-" . $file->getClientOriginalName();
                $file->move('public/uploads/bannerImage/', $filename);
                $user->bannerImage = $filename;
                $user->save();
            }

            return redirect('/view-banner')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }

    public function edit_unit($id)
    {
        $editclient = UnitsMeasurement::where('id', $id)->first();
        $data['content'] = 'admin.unit.edit_unit';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function update_unit(Request $request, $id)
    {
        // dd($request->all());
        try {
            $unitrData = UnitsMeasurement::find($id);
            $updateData = array(
                "unitName"            => $request->has('unitName') ? $request->unitName : "",
                "unitDescription"     => $request->has('unitDescription') ? $request->unitDescription : "",
                "status"                  => $request->has('status') ? $request->status : "",
            );
            $unitrData->update($updateData);
            return redirect('/view-unit')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UnitsMeasurement  $unitsMeasurement
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete_unit(UnitsMeasurement  $unitsMeasurement, $id)
    {
        UnitsMeasurement::where('id', $id)->delete();
        UnitsMeasurement::find($id)->delete();
    }






    public function filter_client(Request $request)
    {

        if ($request->employee_id != '') {
            $id = $request->employee_id ?? '';
        } elseif ($request->whitelabel_id != '') {
            $id = $request->whitelabel_id ?? '';
        } elseif ($request->manager_id != '') {
            $id = $request->manager_id ?? '';
        }
        $client = User::where('users_role', 5)->where('upload_by', $request->id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid' => $request->id]);
    }

    public function client_view_data($id)
    {
        $viewclient = User::where('id', $id)->first();
        $data['content'] = 'admin.client.view_client';
        return view('layouts.content', compact('data'))->with(['viewclient' => $viewclient]);
    }

    public function search_status_client(Request $request)
    {
        $client = User::where('users_role', 5)->where('status', $request->status_id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid' => $request->id]);
    }

    public function client_password_change(Request $request)
    {
        $clientdetails = DB::table('users')->where('id', session::get('gorgID'))->first();
        $data = array(
            'password' => Hash::make($request->newpassword),
        );

        if ($clientdetails != '') {
            $updateData = DB::table('users')->where('id', session::get('gorgID'))->update($data);
            return redirect()->back()->with('message', 'IT WORKS!');
        }
    }
}
