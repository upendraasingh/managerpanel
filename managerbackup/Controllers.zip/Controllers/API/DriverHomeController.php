<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
//use  App\User;
use  App\DuraPickupShedule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use URL;
use DB;
use Carbon\Carbon;
use DateTime;

class DriverHomeController extends Controller
{
    public function __construct()
    {
        $this->middleware(['assign.guard:driverapi','jwt.auth']);
    }
    public function dashboard(Request $request)
    {
        
        $validatedData = $this->validate($request, [
            
            'driver_id'   =>'required',
            
            
        ]);

        try {

            $driver = DuraPickupShedule::where('driver_id',$request->driver_id)->first();
            
            $today_total_trip = DuraPickupShedule::where('driver_id',$request->driver_id)->whereDate('created_at', Carbon::today())->count();
            $today_total_price = DuraPickupShedule::where('driver_id',$request->driver_id)->whereDate('created_at', Carbon::today())->sum('price');
            $avgrating = DB::table('driveuserrating')
                      ->where('driverid',$request->driver_id)
                      ->whereDate('created_at', Carbon::today())
                      ->groupBy('driverid')
                      ->avg('rating');
                      

           
            $data['today_total_trip'] = $today_total_trip;
            $data['today_total_price'] = $today_total_price;
            $data['avgrating'] = round($avgrating,0);
            $data['service_type'] = 'Dura Express';
            $data['pickup_location1'] = $driver->pickup_address1;
            $data['pickup_location2'] = $driver->pickup_address2;
            $data['dropup_location1'] = $driver->destination_address1;
            $data['dropup_location2'] = $driver->destination_address2;
            $data['stop_location1'] = $driver->stop_address1;
            $data['stop_location2'] = $driver->stop_address2;
            $data['pickup_lat'] = $driver->pickuplat;
            $data['pickup_lang'] = $driver->pickuplon;
            $data['dropup_lat'] = $driver->destinationlat;
            $data['dropup_lang'] = $driver->destinationlon;
            $data['stop_lat'] = $driver->stoplat;
            $data['stop_lang'] = $driver->stoplon;
            $data['total_distance'] ="NA";
            $data['delivery_time'] = "NA";
            $data['created_at'] = $driver->created_at;
            
            
            return response()->json(["StatusCode" => "200", 'status' => 'Success','data' => $data], 200);

        } catch (\Exception $e) {

            return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => $e], 500);
        }
    }

    

}