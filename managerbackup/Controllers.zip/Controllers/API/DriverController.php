<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use  App\Vehicle;
use  App\DriverUser;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use URL;
use DB;

class DriverController extends Controller
{
    public function register(Request $request)
    {
        
        $this->validate($request, [
            //'first_name' => 'required|string',
            //'last_name' => 'required|string',
            'mobile' => 'required|integer',
            'email' => 'required|email',
            'password' => 'nullable|required_with:password_confirmation|string|confirmed',
            'password_confirmation' => 'required',
            //'user_type' => 'required|integer',
        ]);

        try 
        {  
            
            $userEmail = DB::table('driveuser')->where('email', $request->email)->first();
            
            $userdMobile = DB::table('driveuser')->where('mobile', $request->mobile)->first();
            
            if(empty($userEmail) && empty($userdMobile))
            {
               
                if($file = $request->file('frontlicensephoto')) {
                    $destinationPath = base_path('public/driver_document/');
                    $frontlicensephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                    
                    $path = $file->move($destinationPath, $frontlicensephoto);
                }
                if($file = $request->file('backlicensephoto')) {
                    $destinationPath = base_path('public/driver_document/');
                    $backlicensephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $backlicensephoto);
                }
                if($file = $request->file('plno')) {
                    $destinationPath = base_path('public/driver_document/');
                    $plno = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $plno);
                }
                if($file = $request->file('crno')) {
                    $destinationPath = base_path('public/driver_document/');
                    $crno = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $crno);
                }
                if($file = $request->file('vehiclephoto')) {
                    $destinationPath = base_path('public/driver_document/');
                    $vehiclephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $vehiclephoto);
                }
                if($file = $request->file('profilephoto_url')) {
                    $destinationPath = base_path('public/driver_profile_image/');
                    $profilephoto_url = uniqid('file') . "-" . $file->getClientOriginalName();
                    
                    $path = $file->move($destinationPath, $profilephoto_url);
                }
                //echo $profilephoto_url;die;
                $plainPassword          = app('hash')->make($request->input('password'));
                
                $datass =array(
                    'firstname'        => $request->input('firstname'),
                    'middlename'       => $request->input('middlename'),
                    'lastname'         => $request->input('lastname'),
                    'mobile'            => $request->input('mobile'),
                    'email'            => $request->input('email'),
                    'referralcode'     => $request->input('referralcode'),
                    'manager_account_no'     => $request->input('manageraccountno'),
                    'g_cash_accont_name'          => $request->input('accname'),
                    'g_cash_no'          => $request->input('gcashno'),
                    'dob'              => $request->input('dob'),
                    'dura_bag_id'              => $request->input('dura_bag_id'),
                    
                    'profilephoto_url' => isset($profilephoto_url) ? $profilephoto_url : "",
                    'isactive'           => 0,
                    'password'         => $plainPassword,
                );
                //echo "hi";die;
                $addData = DB::table('driveuser')->insertGetId($datass);
                
                //echo $addData;die;
                $docdata = array(
                    'driver_id'         => $addData,
                    'frontlicensephoto' => isset($frontlicensephoto) ?  $frontlicensephoto :"", 
                    'backlicensephoto'  => isset($backlicensephoto)  ? $backlicensephoto :"" ,
                    'plno'              => isset($plno)  ? $plno  :"",
                    'crno'              => isset($crno) ? $crno :"",
                    'vehiclephoto'      => isset($vehiclephoto) ? $vehiclephoto :"",
                    'vehicle_id'        => $request->vehicle,
                    'licence_no'              => $request->licence_no,
                    'cr_no'              => $request->cr_no,
                    'police_clearance_no'              => $request->police_clearance_no,
                );
                $addDataId = array(
                    'driver_id'         => $addData,
                    
                );
                $addDatadoc = DB::table('drivepersonaldoc')->insertGetId($docdata);
                if($request->input('mobile')){

                    $credentials = $request->only(['mobile','password']);
                   
                }
                
                if ($token = Auth::guard('driverapi')->attempt($credentials)) {
        
                    
                    
                    $addDataId['login_data'] =  $this->respondWithToken($token);
                    
                }
                
                $data = collect(["StatusCode" => "200", "Status" => "Success", "data" => $addDataId]);
                return response()->json($data, 200);
            }
            else{
                return response()->json(['StatusCode' => 404,'Status' => 'Failed','message' => 'Driver already registered'], 200);
            }
            
            

        }   catch (\Exception $e) {
           dd($e);
            return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => 'Driver Registration Failed!'], 500);
        }
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'mobile' => 'required',
            'password' => 'required',
        ]);

        
        $credentials = $request->only(['mobile', 'password']);
        //$check = DB::table('driveuser')->where('mobile', '=', $request->mobile)->get();
        
        /*if (Hash::check($request->password, $check->password)) { */
         
            if (! $token = Auth::guard('driverapi')->attempt($credentials)) {
            
            return response()->json(['message' => 'Invalid credentials', 'status' => 201], 401);
            
            }else{
                
                

                $finalData = array();
                
                $userd = DriverUser::where('mobile', $request->mobile)->first();
                DB::table('driveuser')
                ->where('mobile', $request->mobile)  // find your user by their email
                ->limit(1)  // optional - to ensure only one record is updated.
                ->update(array('latitude' => $request->latitude,'longitude' => $request->longitude));  // update the record in the DB. 
                
                $finalData =  array('token'        =>$this->respondWithToken($token));
                        
                //print_r($finalData);die;        $this->respondWithToken($token)->getData()->token            
                $data = collect(["StatusCode" => "200", "Status" => "Success",'message' => 'Driver login successfully!', 'driver_id'       =>$userd['id'],
                                                                            'first_name'    =>$userd['firstname'],
                                                                            'last_name'     =>$userd['lastname'],
                                                                            'email'         =>$userd['email'],
                                                                            'phone'         =>$userd['phone'],
                                                                            'profile_image' =>URL::to('/')."/public/Media/".$userd['profile_image'],
                                                                            "data"          =>$this->respondWithToken($token)]);
                return response()->json($data, 200);
            }
        /*}*/
        
        
        
    }

    protected function respondWithToken($token)
    {
        return response()->json([  
            'success' => true, 
            'access_token' => $token,
            'token_type' => 'bearer',
        ]);
    }  
    
    public function generateNumericOTP($n) { 
    // Take a generator string which consist of 
    // all numeric digits 
    $generator = "1357902468"; 
  
    // Iterate for n-times and pick a single character 
    // from generator and append it to $result 
      
    // Login for generating a random character from generator 
    //     ---generate a random number 
    //     ---take modulus of same with length of generator (say i) 
    //     ---append the character at place (i) from generator to result 
  
    $result = ""; 
  
    for ($i = 1; $i <= $n; $i++) { 
        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
    } 
  
    // Return result 
    return $result; 
    } 
    
    
    public function send_otp(Request $request){
        
        
            $user = DriverUser::orwhere('mobile', $request->phone)->first();

            if($user !=null && $request->api_type == "register")
            {
                return response()->json(['StatusCode' => "422",'Status' => 'Failed','message' => 'User is already exist'], 200);
                
            }
            
            if(!empty($request->get('phone'))){
    
                $credentials = $request->only(['phone']);
    
            }
            
            
     
            if (!$credentials) {
    
                return response()->json(['StatusCode' => "422",'Status' => 'Failed','message'=>'Invalid credentials'], 200);
                
            }else {

                try {
                    
                    $otp = $this->generateNumericOTP(6);
                    $msg = "Your code for otp varification ".$otp;
                    
                    
                    if($request->get('phone')){
                        
                        $otpDetail[] = [
                           $request->get('phone'),
                           $otp,
                           
                        ];
    
                        //$this->sendTwilioSms($otpDetail);
                        
                    }
                    
                    // use wordwrap() if lines are longer than 70 characters
                    $msg = wordwrap($msg,70);
    
                    // send email
                    //mail($request->input('email'),"Otp code from wmc",$msg);
                    $id = DB::table('driver_otp')->insertGetId(['otp' => $otp,'phone' => $request->input('phone')]);
                    $otpData = DB::table('driver_otp')->where('id',$id)->first();
                    $data = collect(["StatusCode" => "200", 'status' => 'Success', "message" => "Otp send successfully", "data"=>$otpData]);
                    return response()->json($data, 200); 
                    
                }catch (\Exception $e) {          
                    
                    return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => $e], 500);
                }
            }
        
       
    }
    
    public function varify_otp(Request $request){
        
        
        if(!empty($request->get('phone'))){

            $credentials = $request->only(['phone']);

        }
        
        
 
        if (!$credentials) {

            return response()->json(['StatusCode' => "422",'Status' => 'Failed','message'=>'Invalid credentials'], 200);
            
        }else {
        $rules = [
            
            'otp' => 'required'                  
        ];
        $validator = Validator::make($request ->all(), $rules);
        if ($validator->fails()){
            return response()->json(['StatusCode' => "422",'Status' => 'Failed','message'=>$validator->messages() ], 200);
        } 
        else 
        {
            /*try 
            {*/
                $row = DB::table('driver_otp')->where('otp','=',$request->input('otp'))->where('phone','=',$request->input('phone'))->first();
                if($row!=null)
                {
                    $data = collect(["StatusCode" => "200", 'status' => 'Success', "message" => "otp varified", "data"=>$row]);
                    return response()->json($data, 200); 
                }
                
                $data = collect(["StatusCode" => "200", 'status' => 'Success', "message" => "Wrong code", "data"=>$row]);
                return response()->json($data, 200); 
                
            /*}
            catch (\Exception $e) 
            {               
                return response()->json(['StatusCode' => 422, 'Status' => 'Failed','message' => $e], 409);
            }*/
        }
        }
    }
    
    public function resetPassword(Request $request){
        
        $rules = [
            'phone' => 'required',  
            'password' => 'nullable|required_with:password_confirmation|string|confirmed',
            'password_confirmation' => 'required',
        ];

        $validator = Validator::make($request ->all(), $rules);
        if ($validator->fails()){
            return response()->json(['StatusCode' => 400,'Status' => 'Failed','message'=>$validator->messages() ], 200);
        } 
        else 
        {
            try {
                
                // $row = DB::table('driver')->where('otp','=',$request->otp)->where('email','=',$request->email)->get()->first();
                /*if($row!=null)
                {  */ 
                    $enc_pass = app('hash')->make($request->input('password'));
                    
                    $driver= DriverUser::where('mobile','=',$request->phone)->first();
                    $driver->password = $enc_pass;
                    $driver->save();
                    
                    $driverId['driver_id'] = $driver->id;
                    
                    $data = collect(["StatusCode" => "200", 'status' => 'Success', "message" => "Password updated successfully!", "data"=>$driverId]);
                    return response()->json($data, 200); 
                /*}*/
                /*$data = collect(["StatusCode" => "200", 'status' => 'Success', "message" => "Wrong code", "data"=>$row]);
                return response()->json($data, 200); */
                
            }catch (\Exception $e) {     
                
                return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => $e], 500);
            }
        }
    }
    
    
    public function showDriverDetail(Request $request)
    {
        $validatedData = $this->validate($request, [
            
            'driver_id'   =>'required',
            
            
        ]);

        

            $driver = DriverUser::find($request->driver_id);
            $d['driver_id'] = $driver->id;
            $d['firstname'] = $driver->firstname;
            $d['middlename'] = $driver->middlename;
            $d['lastname'] = $driver->lastname;
            $d['mobile'] = $driver->mobile;
            $d['dob'] = $driver->dob;
            $d['email'] = $driver->email;
            $d['password'] = $driver->password;
            $d['manager_account_no'] = $driver->manager_account_no;
            $d['g_cash_accont_name'] = $driver->g_cash_accont_name;
            $d['g_cash_no'] = $driver->g_cash_no;
            $d['lastupdatedatetime'] = $driver->lastupdatedatetime;
            $d['dura_bag_id'] = $driver->dura_bag_id;
            $d['created_datetime'] = $driver->created_datetime;
            $d['isactive'] = $driver->isactive;
            $d['isvarified'] = $driver->isvarified;
            $d['dura_bag_id'] = $driver->dura_bag_id;
            $d['referralcode'] = $driver->referralcode;
            $d['isbusinessaccout'] = $driver->isbusinessaccout;
            $d['latitude'] = $driver->latitude;
            $d['longitude'] = $driver->longitude;
            
            $d['profilephoto_url'] = url('/public/driver_document/'.$driver->profilephoto_url);
            $d['cardtypeid'] = $driver->driver_document->cardtypeid;
            $d['frontlicensephoto'] = url('/public/driver_document/'.$driver->driver_document->frontlicensephoto);
            $d['backlicensephoto'] = url('/public/driver_document/'.$driver->driver_document->backlicensephoto);
            $d['plno'] = url('/public/driver_document/'.$driver->driver_document->plno);
            $d['crno'] = url('/public/driver_document/'.$driver->driver_document->crno);
            $d['vehiclephoto'] = url('/public/driver_document/'.$driver->driver_document->vehiclephoto);
            $d['vehicle_id'] = $driver->driver_document->vehicle_id;
            $d['licence_no'] = $driver->driver_document->licence_no;
            $d['cr_no'] = $driver->driver_document->cr_no;
            $d['police_clearance_no'] = $driver->driver_document->police_clearance_no;
            
            
            /*$data['company_name'] = $company->company_name;
            $data['category_id'] = $company->category_id;
            $data['address'] = $company->address;
            $data['city'] = $company->city;
            $data['zip_code'] = $company->zip_code;
            $data['vat_uid_number'] = $company->vat_uid_number;
            $data['general_loyality_point'] = $company->general_loyality_point;*/
            return response()->json(["StatusCode" => "200", 'status' => 'Success','data' => $d], 200);

       
       
    }
    public function showVehicleList(Request $request)
    {
        

        try {

            $vehicle = Vehicle::get();
            
            return response()->json(["StatusCode" => "200", 'status' => 'Success','data' => $vehicle], 200);
            
        } catch (\Exception $e) {

            return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => $e], 500);
        }
       
       
    }
    
    public function updateDriverDetail(Request $request)
    {
        
        $validatedData = $this->validate($request, [
            
            'driver_id'   =>'required',
            
            
        ]);
        
        try {
            
            $driverDetail = DriverUser::where('id',$request->driver_id)->first();
            
            if($driverDetail){
               
                if($file = $request->file('frontlicensephoto')) {
                        $destinationPath = base_path('public/driver_document/');
                        $frontlicensephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                        $path = $file->move($destinationPath, $frontlicensephoto);
                    }
                    if($file = $request->file('backlicensephoto')) {
                        $destinationPath = base_path('public/driver_document/');
                        $backlicensephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                        $path = $file->move($destinationPath, $backlicensephoto);
                    }
                    if($file = $request->file('plno')) {
                        $destinationPath = base_path('public/driver_document/');
                        $plno = uniqid('file') . "-" . $file->getClientOriginalName();
                        $path = $file->move($destinationPath, $plno);
                    }
                    if($file = $request->file('crno')) {
                        $destinationPath = base_path('public/driver_document/');
                        $crno = uniqid('file') . "-" . $file->getClientOriginalName();
                        $path = $file->move($destinationPath, $crno);
                    }
                    if($file = $request->file('vehiclephoto')) {
                        $destinationPath = base_path('public/driver_document/');
                        $vehiclephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                        $path = $file->move($destinationPath, $vehiclephoto);
                    }
                    if($file = $request->file('profilephoto_url')) {
                        $destinationPath = base_path('public/driver_profile_image/');
                        $profilephoto_url = uniqid('file') . "-" . $file->getClientOriginalName();
                        $path = $file->move($destinationPath, $profilephoto_url);
                    }
                    //echo $profilephoto_url;die;
                    $plainPassword          = app('hash')->make($request->input('password'));
                    
                    $datass =array(
                        'firstname'        => $request->get('firstname'),
                        'middlename'       => $request->get('middlename'),
                        'lastname'         => $request->get('lastname'),
                        'mobile'            => $request->get('mobile'),
                        'email'            => $request->get('email'),
                        'referralcode'     => $request->get('referralcode'),
                        'manager_account_no'     => $request->input('manageraccountno'),
                        'g_cash_accont_name'          => $request->input('accname'),
                        'g_cash_no'          => $request->input('gcashno'),
                        'dob'              => $request->input('dob'),
                        'dura_bag_id'              => $request->input('dura_bag_id'),
                        'profilephoto_url' => isset($profilephoto_url) ? $profilephoto_url : "",
                        'isactive'           => 0,
                        'password'         => $plainPassword,
                        
                    );
                    //echo "hi";die;
                    $addData = DB::table('driveuser')->where('id',$request->driver_id)->update($datass);
                    
                    
                    
                    //echo $addData;die;
                    $docdata = array(
                    
                            'frontlicensephoto' => isset($frontlicensephoto) ? $frontlicensephoto:"", 
                            'backlicensephoto'  => isset($backlicensephoto) ,
                            'plno'              => isset($plno) ,
                            'crno'              => isset($crno),
                            'vehiclephoto'      => isset($vehiclephoto),
                            'vehicle_id'        => $request->vehicle,
                            'licence_no'              => $request->licence_no,
                            'cr_no'              => $request->cr_no,
                            'police_clearance_no'              => $request->police_clearance_no,
                        );
                    /*$addDataId = array(
                        'driver_id'         => $addData,
                        
                    );*/
                    $addDatadoc = DB::table('drivepersonaldoc')->where('driver_id',$request->driver_id)->update($docdata);
                    $driver = DriverUser::where('id',$addData)->first();
                    $d['driver_id'] = $driver->id;
                    $d['firstname'] = $driver->firstname;
                    $d['middlename'] = $driver->middlename;
                    $d['lastname'] = $driver->lastname;
                    $d['mobile'] = $driver->mobile;
                    $d['dob'] = $driver->dob;
                    $d['email'] = $driver->email;
                    $d['password'] = $driver->password;
                    $d['manager_account_no'] = $driver->manager_account_no;
                    $d['g_cash_accont_name'] = $driver->g_cash_accont_name;
                    $d['g_cash_no'] = $driver->g_cash_no;
                    $d['lastupdatedatetime'] = $driver->lastupdatedatetime;
                    $d['dura_bag_id'] = $driver->dura_bag_id;
                    $d['created_datetime'] = $driver->created_datetime;
                    $d['isactive'] = $driver->isactive;
                    $d['isvarified'] = $driver->isvarified;
                    $d['dura_bag_id'] = $driver->dura_bag_id;
                    $d['referralcode'] = $driver->referralcode;
                    $d['isbusinessaccout'] = $driver->isbusinessaccout;
                    $d['latitude'] = $driver->latitude;
                    $d['longitude'] = $driver->longitude;
                    
                    $d['profilephoto_url'] = url('/public/driver_/profile_image'.$driver->profilephoto_url);
                    $d['cardtypeid'] = $driver->driver_document->cardtypeid;
                    $d['frontlicensephoto'] = url('/public/driver_document/'.$driver->driver_document->frontlicensephoto);
                    $d['backlicensephoto'] = url('/public/driver_document/'.$driver->driver_document->backlicensephoto);
                    $d['plno'] = url('/public/driver_document/'.$driver->driver_document->plno);
                    $d['crno'] = url('/public/driver_document/'.$driver->driver_document->crno);
                    $d['vehiclephoto'] = url('/public/driver_document/'.$driver->driver_document->vehiclephoto);
                    $d['vehicle_id'] = $driver->driver_document->vehicle_id;
                    
            }
            $data1 = collect(["StatusCode" => "200", "Status" => "Success",'message' => 'Driver detail updated successfully!', "data" => $d]);
            return response()->json($data1, 200);
             
        } catch (\Exception $e) {

            return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => $e], 500);
        }
    }
    
    public function approvalStatus(Request $request)
    {
        $validatedData = $this->validate($request, [
            
            'driver_id'   =>'required',
            
            
        ]);

        try {

            $driver = DriverUser::select('isactive')->where('id',$request->driver_id)->first();
            
            $data['driver_id'] = $driver->id;
            $data['approval_status'] = $driver->isactive;
            
            if($driver->isactive == 0){
                
                $message = 'The driver is not approved!';
            }else{
                
                $message = 'The driver is approved!';
            }
            
            return response()->json(["StatusCode" => "200", 'status' => 'Success','message' => $message,'data' => $data], 200);

        } catch (\Exception $e) {

            return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => $e], 500);
        }
       
    }

}