<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
//use  App\User;
use  App\Manager;
use  App\DriverUser;
use App\Http\Resources\DriverUserRatingResource;
use App\Http\Resources\SalesRecordsResource;
use App\DuraPickupShedule;
use App\Http\Resources\SalesByVehicleResource;
use App\Vehicle;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use URL;
use DB;
use Carbon;

class ManagersController extends Controller
{
    public function login(Request $request)
    {
        DB::beginTransaction();
        
        $validation= Validator::make(
            $request->all(),
             [
                'mobile' => 'required',
                'manager_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            $messages = $validation->messages();
            $error='';
            foreach ($messages->all(':message') as $message)
            {
                $error .=$message;
            }
            return response()->json(['message' => $error, 'status' => 201], 401);
            return $this->respondWithValidationError($valid);
        }
        /*$this->validate($request, [
            'mobile' => 'required',
            'manager_id' => 'required',
        ]);*/
        $credentials = $request->only(['mobile','manager_id']);
        $user = Manager::where(['mobile'=> $request->mobile,'id'=>$request->manager_id])->first();
        if(!empty($user)){
            $otp = rand(1000,9999);
            $valid_time = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s")." +3 minutes"));
            
            $user->otp=$otp;
            $user->otp_valid_until=date('Y-m-d H:i:s',strtotime($valid_time));
            $user->save();
            DB::commit();
            $mobile=$request->mobile;
            $data = collect(["StatusCode" => 200, "Status" => "Success",'message' => "OTP sent successfully for mobile number $mobile . ","otp"=>$otp ]);
            return response()->json($data, 200);
        }else{
            DB::rollBack();
            return response()->json(['message' => 'Invalid Number', 'status' => 400], 401);
        }
    }
    public function check_otp(Request $request)
    {
        DB::beginTransaction();
        $this->validate($request, [
            'otp' => 'required',
        ]);
        //$credentials = $request->only(['mobile']);
        $user = Manager::where('otp', $request->otp)->where('otp_valid_until','>',date("Y-m-d H:i:s"))->first();
        if(!empty($user)){
            
            $user->otp='';
            $user->otp_valid_until='';
            $user->save();
            DB::commit();
            $data = collect(["StatusCode" => 200, "Status" => "Success",'message' => "OTP matched successfully",'user'=>$user ]);
            return response()->json($data, 200);
        }else{
            DB::rollBack();
            return response()->json(['message' => 'Invalid otp', 'status' => 201], 401);
        }
    }
    
    public function getManagersList(Request $request)
    {
        $data=  Manager::all();
        $data = collect(["StatusCode" => 200, "Status" => "Success",'message' => "Managers List",'data'=>$data ]);
        return response()->json($data, 200);
    }
    public function topRatedDrivers(Request $request)
    {
        $limit = isset($request['length']) ? $request['length'] : 10;
        $request['page'] = isset($request['page']) ? $request['page'] : 1;
        $items=DriverUser::whereHas('driver_ratings')->paginate($limit);
        
        $items = DriverUserRatingResource::collection($items);
          $json_data = array(
                    "draw"            => intval($request['draw']),  
                    "recordsTotal"    => $items->total(),  
                    "recordsFiltered" => $items->total(), 
                    "data"            => $items,
                    'current_page' => $items->currentPage(),
                    'next' => $items->nextPageUrl(),
                    'previous' => $items->previousPageUrl(),
                    'per_page' => $items->perPage(),   
                    'message' => "Top Rated Drivers List",
                     "Status" => "Success",
                     "StatusCode" => 200,
                    );
        
        //$data = collect(['data'=>$json_data ]);
        return response()->json($json_data, 200);
    }
    public function allDriversStatus(Request $request)
    {
        $query = DB::table('driveuser')
                 ->select('isactive', DB::raw('count(*) as total'))
                 ->groupBy('isactive')
                 ->get();
        $arr=array();
        $arr['active']=0;    
        $arr['inactive']=0;    
        $arr['total']=0;    
        foreach($query as $row)
        {   
            if($row->isactive==1)
            {
                $arr['active']=$row->total;    
            }else{
                $arr['inactive']=$row->total;    
            }
            $arr['total'] +=$row->total;    
        }
        $data = collect(["StatusCode" => 200, "Status" => "Success",'message' => "All Drivers List",'data'=>$arr ]);
        return response()->json($data, 200);
    }
    public function todayList()
    {
        
        $arr=array(
            array(
                'key'=>  'today',
                'value'=>'Today'
            ),
            array(
                'key'=>  'week',
                'value'=>'This week'
            ),
            array(
                'key'=>  'month',
                'value'=>'This Month'
            ),
            array(
                'key'=>  'year',
                'value'=>'This Year'
            ),
                
        );
        $data = collect(["StatusCode" => 200, "Status" => "Success",'message' => "All Drivers List",'data'=>$arr ]);
        return response()->json($data, 200);
    }
    
    public function salesData(Request $request)
    {
        $limit = isset($request['length']) ? $request['length'] : 10;
        $request['page'] = isset($request['page']) ? $request['page'] : 1;
        
        $where=array();
        $query=DuraPickupShedule::where($where);
        
        if(isset($request['from']) && $request['from']=='today')
        {
            $query->whereDate('created_at',date('Y-m-d'));
        }
        else if(isset($request['from']) && $request['from']=='week')
        {
            $query->whereRaw('DATE(created_at) >= DATE(NOW()) - INTERVAL 7 DAY');
        }
        else if(isset($request['from']) && $request['from']=='month')
        {
            $query->whereRaw('DATE(created_at) >= DATE(NOW()) - INTERVAL 1 MONTH');
        }
        else if(isset($request['from']) && $request['from']=='year')
        {
            $query->whereYear('created_at',date('Y'));
        }else{
            $query->whereDate('created_at',date('Y-m-d'));
        }
        $items=$query->paginate($limit);
        $items=SalesRecordsResource::collection($items);
        $json_data = array(
                    "draw"            => intval($request['draw']),  
                    "recordsTotal"    => $items->total(),  
                    "recordsFiltered" => $items->total(), 
                    "data"            => $items,
                    'current_page' => $items->currentPage(),
                    'next' => $items->nextPageUrl(),
                    'previous' => $items->previousPageUrl(),
                    'per_page' => $items->perPage(),   
                    'message' => "Sales Data List",
                     "Status" => "Success",
                     "StatusCode" => 200,
                    );
        
        
        return response()->json($json_data, 200);
    }
    public function salesByVehicle(Request $request)
    {
        $limit = isset($request['length']) ? $request['length'] : 10;
        $request['page'] = isset($request['page']) ? $request['page'] : 1;
        
        $where=array();
        
        $query=Vehicle::with(['vehicle_sales' => function($q) use($request) {
            
            if(isset($request['from']) && $request['from']=='today')
            {
                $q->whereDate('durapickupshedule.created_at',date('Y-m-d'));
            }
            else if(isset($request['from']) && $request['from']=='week')
            {
                $q->whereRaw('DATE(durapickupshedule.created_at) >= DATE(NOW()) - INTERVAL 7 DAY');
            }
            else if(isset($request['from']) && $request['from']=='month')
            {
                $q->whereRaw('DATE(durapickupshedule.created_at) >= DATE(NOW()) - INTERVAL 1 MONTH');
            }
            else if(isset($request['from']) && $request['from']=='year')
            {
                $q->whereYear('durapickupshedule.created_at',date('Y'));
            }else{
                $q->whereDate('durapickupshedule.created_at',date('Y-m-d'));
            }
            
        }]);
        
        $items= $query->paginate($limit);
        
        
        $items=SalesByVehicleResource::collection($items);
        $json_data = array(
                    "draw"            => intval($request['draw']),  
                    "recordsTotal"    => $items->total(),  
                    "recordsFiltered" => $items->total(), 
                    "data"            => $items,
                    'current_page' => $items->currentPage(),
                    'next' => $items->nextPageUrl(),
                    'previous' => $items->previousPageUrl(),
                    'per_page' => $items->perPage(),   
                    'message' => "Sales by vehicle",
                     "Status" => "Success",
                     "StatusCode" => 200,
                    );
        
        
        return response()->json($json_data, 200);
    }
    
    public function salesByService(Request $request)
    {
        $limit = isset($request['length']) ? $request['length'] : 10;
        $request['page'] = isset($request['page']) ? $request['page'] : 1;
        
        $where=array();
        
        $query=Vehicle::with(['vehicle_sales' => function($q) use($request) {
            
            if(isset($request['from']) && $request['from']=='today')
            {
                $q->whereDate('durapickupshedule.created_at',date('Y-m-d'));
            }
            else if(isset($request['from']) && $request['from']=='week')
            {
                $q->whereRaw('DATE(durapickupshedule.created_at) >= DATE(NOW()) - INTERVAL 7 DAY');
            }
            else if(isset($request['from']) && $request['from']=='month')
            {
                $q->whereRaw('DATE(durapickupshedule.created_at) >= DATE(NOW()) - INTERVAL 1 MONTH');
            }
            else if(isset($request['from']) && $request['from']=='year')
            {
                $q->whereYear('durapickupshedule.created_at',date('Y'));
            }else{
                $q->whereDate('durapickupshedule.created_at',date('Y-m-d'));
            }
            
        }]);
        
        $items= $query->paginate($limit);
        
        
        $items=SalesByVehicleResource::collection($items);
        $json_data = array(
                    "draw"            => intval($request['draw']),  
                    "recordsTotal"    => $items->total(),  
                    "recordsFiltered" => $items->total(), 
                    "data"            => $items,
                    'current_page' => $items->currentPage(),
                    'next' => $items->nextPageUrl(),
                    'previous' => $items->previousPageUrl(),
                    'per_page' => $items->perPage(),   
                    'message' => "Sales by vehicle",
                     "Status" => "Success",
                     "StatusCode" => 200,
                    );
        
        
        return response()->json($json_data, 200);
    }
}
?>