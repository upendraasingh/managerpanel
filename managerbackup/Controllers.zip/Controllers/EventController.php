<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Calendar;
use App\Event;
use URL;
use DB;

class EventController extends Controller
{
    public function index()
    {
        $events = [];
        $data = Event::all();
        if($data->count()) {
            foreach ($data as $key => $value) {
            	$template = DB::table('leadappointment')->where('event_id', $value->id)->first();
            	$title = explode(" ",$value->title);
            	if($template!=null){
                    if($title[0]=='Client-'){
                        $link = [
                                    'color' => '#f05050',
                                    'url' => URL::to('/').'/client-view-data/'.$template->client_id,
                                ];
                    }   else{
                        $link = [
                                    'color' => '#f05050',
                                    'url' => URL::to('/').'/lead-view/'.$template->lead_id,
                                ];
                    }
            	//dd(new \DateTime($value->start_date));
                    $events[] = Calendar::event(
                        $value->title,
                        true,
                        new \DateTime($value->start_date),
                        new \DateTime($value->end_date.' +1 day'),
                        null,
                        // Add color and link on event
                        $link                    
                    );
                }
            }
        }
        $calendar = Calendar::addEvents($events);
        return view('fullcalender', compact('calendar'));
    }
}
?>