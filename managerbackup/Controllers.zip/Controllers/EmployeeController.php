<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\Mail\SendMail;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class EmployeeController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth');
    $this->middleware('role');
  }

  public function filter_employee(Request $request){
    if ($request->manager_id) {
      $employee = DB::table('users')->where('users_role', 4)->where('upload_by', $request->manager_id)->get();
    }

    $data['content'] = 'admin.employee.manage_employee';
    return view('layouts.content', compact('data'))->with(['employee' => $employee,  'manager_id' => $request->manager_id,  'whitelabel_id' => $request->whitelabel_id]);
  }

  public function add_employee(Request $request){
    if($request->admin_upload_by!=''){
      $uploadBy = $request->admin_upload_by;
    }
    else{
      if(Session::get('userRole') == 2){
        $uploadBy = $request->upload_by;
      }else{
        $uploadBy = Session::get('gorgID');
      }
    }
    if($files = $request->image){
      $destinationPath = public_path('/profile_image/');
      $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
      $path =  $files->move($destinationPath, $profileImage);
      $image = $insert['photo'] = "$profileImage";
    }

    if(Session::get('userRole') == 2){
      $whitelabelId = Session::get('gorgID');
    }else{
        $whitelabelId = $request->whitelabel_id;
    }

    if($request->image!=''){
      $data = array(
        'name' => $request->name,  
        'white_label_id' => $whitelabelId ?? '',  
        'upload_by' => $uploadBy,
        'users_role' => 4,  
        'email' => $request->email, 
        'phone' => $request->phone, 
        'address' => $request->address, 
        'country_id' => $request->country_id, 
        'dob' => $request->dob, 
        'gender' => $request->gender, 
        'password' => Hash::make($request->password), 
        'profile_image' =>  $image, 
        'created_at' => date('Y-m-d H:i:s'),
      );    
    }else{
      $data = array(
        'name' => $request->name, 
        'white_label_id' => $whitelabelId ?? '', 
        'upload_by' => $uploadBy, 
        'users_role' => 4,  
        'email' => $request->email, 
        'phone' => $request->phone, 
        'address' => $request->address, 
        'country_id' => $request->country_id,
        'dob' => $request->dob, 
        'gender' => $request->gender, 
        'password' => Hash::make($request->password), 
        'created_at' => date('Y-m-d H:i:s'),     
      );
    }
    /*Mail::to('saurabh.kumar199305@gmail.com')->send(new SendMail($data));*/

    if($request->edit_id!= ''){
      Session::flash('success','Updated successfully..!');
      $updateData = DB::table('users')->where('id', $request->edit_id)->update($data);
      return redirect('view-employee');
    }
    else{
      Session::flash('success','Inserted successfully..!');
      $insertData = DB::table('users')->insert($data);
      return redirect('view-employee');
    } 
  }

  public function view_employee(){
    if(Session::get('userRole') == 1){
      $employee = User::where('users_role', 4)->orderBy('id', 'Desc')->get();
    }elseif(Session::get('userRole') == 2){
      $employee = User::where('white_label_id', Session::get('gorgID'))->where('users_role',4)->orderBy('id', 'Desc')->get();      
    }elseif(Session::get('userRole') == 3){
      $employee = User::where('upload_by', Session::get('gorgID'))->where('users_role',4)->orderBy('id', 'Desc')->get();
    }   
    $data['content'] = 'admin.employee.manage_employee';
    return view('layouts.content', compact('data'))->with(['employee' => $employee ]);
  }

  public function edit_employee($id) {
    $editemployee = User::where('id', $id)->first();
    $data['content'] = 'admin.employee.edit_employee';
    return view('layouts.content', compact('data'))->with(['editemployee' => $editemployee ]);
  }

  public function get_whitelabel_data($whitelabel_ID){
    $data = User::where('upload_by', $whitelabel_ID)->where('users_role', 3)->get();
    return response()->json($data);
  }

  public function get_employee_data($manager_id){
    $data = User::where('upload_by', $manager_id)->get();
    return response()->json($data);
  }
}
