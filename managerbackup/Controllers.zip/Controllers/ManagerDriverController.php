<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\Vehicle;
use App\DriverUser;
use App\DriverDocument;
use App\DriverVehicle;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class ManagerDriverController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
        //$this->middleware('role');
    }
    public function filter_manager(Request $request)
    {
        try {
            $manager = DB::table('users')->where('users_role', 3)->where('upload_by', $request->whitelabel_id)->get();
            $data['content'] = 'manager.manager.manage_manager';
            return view('layouts.content', compact('data'))->with(['manager' => $manager, 'whitelabel_id' => $request->whitelabel_id]);
        } catch (Throwable $e) {
            report($e);
            return false;
        }
    }
    public function add_service(Request $request)
    {
        if ($files = $request->image) {
            /*
            $destinationPath = public_path('/profile_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
            */
        }
        $data = array(
            'name' => $request->name,
            'upload_by' => $uploadBy,
            'users_role' => 3,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'country_id' => $request->country_id,
            'dob' => $request->dob,
            'gender' => $request->gender,
            'password' => Hash::make($request->password),
            'profile_image' =>  $image,
            'created_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('users')->insert($data);
        return redirect('view-countrym');
    }
    public function view_service()
    {
        if (Session::get('userRole') == 1) {
            $manager = User::where('users_role', 3)->get();
        } else {
            $manager = User::where('upload_by', Session::get('gorgID'))->where('users_role', 3)->get();
        }
        /*
        $status = User::isOnline($manager->id);
        print_r($status); die;
        */
        $data['content'] = 'manager.service.manage_service';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function view_foodmerchant()
    {
        $manager = User::where('users_role', 3)->get();
        $data['content'] = 'manager.foodmerchant.manage_foodmerchant';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function view_operatormanager()
    {
        $manager = User::where('users_role', 3)->get();
        $data['content'] = 'manager.operatormanager.manage_operatormanager';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function view_shopmerchant()
    {
        $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $data['content'] = 'manager.shopmerchant.manage_shopmerchant';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function view_driver()
    {
        $manager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        //  dd($manager);

        // $manager = DriverUser::all();
        $data['content'] = 'manager.driver.manage_driver';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    
    public function add_driver(Request $request)
    {
       
        try {
            $driverData =  DriverUser::create([
                'firstname'         => $request->firstname,
                'email'             => $request->email,
                'mobile'            => $request->mobile,
                'city'              => $request->city,
                "address"           => $request->address,
                "created_datetime"  => date('Y-m-d')
            ]);
            if ($request->hasFile('profilephoto_url')) {
                $user       = DriverUser::find($driverData->id);
                $file       = $request->file('profilephoto_url');
                $filename   = 'profilephoto-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/profilephoto/', $filename);
                $user->profilephoto_url = $filename;
                $user->save();
            }
            $docsData =  DriverDocument::create([
                'driver_id'             => $driverData->id,
                'document_type'         => $request->document_type,
                'docsExpire'            => $request->docsExpire,
                'docs_status'           => $request->docs_status,
                "createddate"           => $request->docs_upload_date,
            ]);

            if ($request->hasFile('document_file')) {
                $user           = DriverDocument::find($docsData->id);
                $file           = $request->file('document_file');
                $filename       = 'document_file-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/driver_document/', $filename);
                $user->document_file = $filename;
                $user->save();
            }
            if ($request->hasFile('frontlicensephoto')) {
                $user           = DriverDocument::find($docsData->id);
                $file           = $request->file('frontlicensephoto');
                $filename       = 'frontlicensephoto-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/frontlicensephoto/', $filename);
                $user->frontlicensephoto = $filename;
                $user->save();
            }

            $driverVehicle = DriverVehicle::create([
                'driver_id'             => $driverData->id,
                'vehicle_type'          => $request->vehicle_type,
                'vehicle_ser_type'      => $request->vehicle_ser_type,
                'veh_doc_expire'        => $request->veh_doc_expire,
                'veh_doc_status'        => $request->veh_doc_status,
                'veh_doc_type'          => "static",
                'veh_doc_upload_at'     => $request->veh_doc_upload_at,
            ]);

            if ($request->hasFile('vehicle_image')) {
                $user = DriverVehicle::find($driverVehicle->id);
                $file = $request->file('vehicle_image');
                $filename = 'vehicle_image-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/vehicle_images/', $filename);
                $user->vehicle_image = $filename;
                $user->save();
            }
            if ($request->hasFile('vehicle_plate_image')) {
                $user = DriverVehicle::find($driverVehicle->id);
                $file = $request->file('vehicle_plate_image');
                $filename = 'vehicle_plate_image-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/vehicle_plate_image/', $filename);
                $user->vehicle_plate_image = $filename;
                $user->save();
            }
            if ($request->hasFile('veh_doc_image')) {
                $user = DriverVehicle::find($driverVehicle->id);
                $file = $request->file('veh_doc_image');
                $filename = 'veh_doc_image-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/veh_doc_image/', $filename);
                $user->veh_doc_image = $filename;
                $user->save();
            }

            return redirect('/manager-view-driver')->with(array('status' => 'success', 'message' => 'New Driver Successfully created!'));
        } catch (\Exception $e) {
            //print_r($e);die;
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }
    public function signupdriver()
    {
        $manager = DriverUser::all();
        $manager = DB::table('driveuser as du')
                    ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
                    ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
                    ->select(
                        'du.*',
                        'dd.driver_id',
                        'dd.document_type',
                        'dd.docsExpire',
                        'dd.docs_status',
                        'dd.document_file',
                        'dd.frontlicensephoto',
                        'dv.vehicle_type',
                        'dv.vehicle_image',
                        'dv.vehicle_plate_image',
                        'dv.vehicle_ser_type',
                        'dv.veh_doc_type',
                        'dv.veh_doc_expire',
                        'dv.veh_doc_image',
                        'dv.veh_doc_status',
                        'dv.veh_doc_upload_at'
                    )->get();
        //$manager  = DB::table('users')->where('users_role', 3)->where('upload_by', $request->whitelabel_id)->get();
        $data['content'] = 'manager.driver.signupdriver';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function registereddriver()
    {
        $manager = DriverUser::all();
        $manager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        $data['content'] = 'manager.driver.registereddriver';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function pendingapp()
    {
        // $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $manager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        $data['content'] = 'manager.driver.pendingapp';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function edit_driver($id)
    {
        $editmanager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->where('du.id', '=', $id)
            ->select(
                'du.*',
                'dd.document_type',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.cardtypeid',
                'dd.licence_no',
                'dd.cr_no',
                'dd.police_clearance_no',
                'dd.frontlicensephoto',
                'dd.backlicensephoto',
                /*'dd.plno',
                'dd.crno',*/
                'dd.vehiclephoto',
                'dd.vehicle_id',
                'dd.isactive',
                'dd.createddate',
                'dv.driver_id',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->first();
        $data['content'] = 'manager.driver.edit_driver';
        return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
    public function updatedriver(Request $request, $id)
    {
        if ($request->hasFile('profilephoto_url')) {
            $file       = $request->file('profilephoto_url');
            $filename   = 'profilephoto-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move('public/uploads/profilephoto/', $filename);
            $profilephoto_url = $filename;
            $driverData =  array(
                'firstname'         => $request->firstname,
                'email'             => $request->email,
                'mobile'            => $request->mobile,
                'city'              => $request->city,
                "address"           => $request->address,
                "profilephoto_url"  => $profilephoto_url
            );
            
        }else{
            $driverData =  array(
                'firstname'         => $request->firstname,
                'email'             => $request->email,
                'mobile'            => $request->mobile,
                'city'              => $request->city,
                "address"           => $request->address,
                "profilephoto_url"  => $profilephoto_url
            );
        }
        
        

        if ($request->hasFile('document_file')) {
            $file           = $request->file('document_file');
            $filename       = 'document_file-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move('public/uploads/driver_document/', $filename);
            $document_file = $filename;
        }
        if ($request->hasFile('frontlicensephoto')) {
            $file           = $request->file('frontlicensephoto');
            $filename       = 'frontlicensephoto-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move('public/uploads/frontlicensephoto/', $filename);
            $frontlicensephoto = $filename;
        }
        
        $docsData =  array(
            'document_type'         => $request->document_type,
            'docsExpire'            => $request->docsExpire,
            'docs_status'           => $request->docs_status,
            "createddate"           => $request->docs_upload_date,
            'document_file'         => $document_file,
            "frontlicensephoto"     => $frontlicensephoto,
        );
        
        if ($request->hasFile('vehicle_image')) {
            $file = $request->file('vehicle_image');
            $filename = 'vehicle_image-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move('public/uploads/vehicle_images/', $filename);
            $vehicle_image = $filename;
        }
        if ($request->hasFile('vehicle_plate_image')) {
            $file = $request->file('vehicle_plate_image');
            $filename = 'vehicle_plate_image-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move('public/uploads/vehicle_plate_image/', $filename);
            $vehicle_plate_image = $filename;
        }
        if ($request->hasFile('veh_doc_image')) {
            $file = $request->file('veh_doc_image');
            $filename = 'veh_doc_image-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move('public/uploads/veh_doc_image/', $filename);
            $veh_doc_image = $filename;
        }
        
        
        $driverVehicle = array(
            'vehicle_type'          => $request->vehicle_type,
            'vehicle_ser_type'      => $request->vehicle_ser_type,
            'veh_doc_expire'        => $request->veh_doc_expire,
            'veh_doc_status'        => $request->veh_doc_status,
            'veh_doc_type'          => $request->veh_doc_type,
            'veh_doc_upload_at'     => $request->veh_doc_upload_at,
            'vehicle_image'         => $vehicle_image,
            'vehicle_plate_image'   => $vehicle_plate_image,
            'veh_doc_image'         => $veh_doc_image
        );
        
        
        $updateData = DB::table('driver_vehicle')->where('driver_id', $id)->update($driverVehicle);
        $updateData = DB::table('drivepersonaldoc')->where('driver_id', $id)->update($docsData);
        $updateData = DB::table('driveuser')->where('id', $id)->update($driverData);
        
        Session::flash('success', 'Updated successfully..!');
        return redirect('manager-view-driver');
    }
    public function incompleteddoc()
    {
        // $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $manager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        $data['content'] = 'manager.driver.incompleteddoc';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function driver_earning()
    {
        // $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $data['content'] = 'manager.driver.driver_earning';
        return view('manager_layouts.content', compact('data'))->with(['usredata' => $manager]);
    }
    public function showDriver(Request $request, $id) 
    {
        $driveuserData = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dd.updated_at as doc_updated_at',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->where('du.id',$id)
            ->first();
           // dd($manager);
        $data['content'] = 'manager.driver.show_details';
        return view('manager_layouts.content', compact('data'))->with(['driveuserData' => $driveuserData]);
    }
    public function shopmerchant_earning()
    {
        // $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $data['content'] = 'manager.driver.shopmerchant_earning';
        return view('manager_layouts.content', compact('data'))->with(['usredata' => $manager]);
    }
    public function foodmerchant_earning()
    {
        // $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $data['content'] = 'manager.driver.foodmerchant_earning';
        return view('manager_layouts.content', compact('data'))->with(['usredata' => $manager]);
    }
    public function rejectedapp()
    {
        // $manager = User::where('users_role', 3)->get();
        $manager = DriverUser::all();
        $manager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        $data['content'] = 'manager.driver.rejectedapp';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function expirydoc()
    {
        $manager = DriverUser::all();
        $manager = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        $data['content'] = 'manager.driver.expirydoc';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    /*public function view_vehicletest()
    {
        $manager = DB::table('driver_vehicle')->get();
        $data['content'] = 'manager.vehicle.manage_vehicle';
        return view('manager_layouts.content', compact('data'))->with(['managerdata' => $manager]);
    }*/
    
    public function view_vehicle()
    {
        $manager = DB::table('driver_vehicle')->get();
        $data['content'] = 'manager.vehicle.manage_vehicle';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function view_drivermap()
    {
        $manager = DB::table('driveuser')->select('firstname','middlename','lastname','latitude','longitude')->where('latitude','!=',"")->where('isactive',1)->get();
        //return redirect('view-countrym');
        $data['content'] = 'manager.map.driver_map';
        return view('manager_layouts.content', compact('data'))->with(['drivermap' => $manager]);
    }
    public function view_heatmap()
    {
        $manager = User::where('users_role', 3)->get();
        $data['content'] = 'manager.map.heat_map';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function edit_service($id)
    {
        $editmanager = User::where('id', $id)->first();
        $data['content'] = 'manager.service.edit_service';
        return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
    public function edit_vehicle($id)
    {
        $editmanager = User::where('id', $id)->first();
        $data['content'] = 'manager.vehicle.view_vehicle';
        return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
    public function edit_foodmerchant($id)
    {
        $editmanager = User::where('id', $id)->first();
        $data['content'] = 'manager.foodmerchant.edit_foodmerchant';
        return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
    public function edit_shopmerchant($id)
    {
        $editmanager = User::where('id', $id)->first();
        $data['content'] = 'manager.shopmerchant.edit_shopmerchant';
        return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
    public function edit_operatormanager($id)
    {
        $editmanager = User::where('id', $id)->first();
        $data['content'] = 'manager.operatormanager.edit_operatormanager';
        return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
}