<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\ServicesArea;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class ServiceController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth');
    $this->middleware('role');
  }
  public function filter_manager(Request $request)
  {
    try {
      $manager = DB::table('users')->where('users_role', 3)->where('upload_by', $request->whitelabel_id)->get();
      $data['content'] = 'admin.manager.manage_manager';
      return view('layouts.content', compact('data'))->with(['manager' => $manager, 'whitelabel_id' => $request->whitelabel_id]);
    } catch (Throwable $e) {
      report($e);
      return false;
    }
  }
  public function add_service(Request $request)
  {
    // dd($request->all());
    $insertData =  ServicesArea::create([
      'service_name' => $request->service_name,
      'country' => $request->country,
      'area' => $request->area,
      'timezone' => $request->timezone,
      'vehicle_service' => $request->vehicle_service,
      // 'sequence' => $request->sequence,
      'driver_minbal' => '',
      'delivery_area' => '',
      'max_tollprice' => '',
      'bill_method' => '',
      'latitute' => '',
      'longitute' => '',
    ]);
    if ($request->hasFile('vehicle_doc')) {
      $user = ServicesArea::find($insertData->id);
      $file = $request->file('vehicle_doc');
      $filename = 'vehicle_doc-' . time() . '.' . $file->getClientOriginalExtension();
      $file->move('public/upload/vehicleDoc/', $filename);
      $user->vehicle_doc = $filename;
      $user->save();
    }

    if ($request->hasFile('driver_doc')) {
      $user = ServicesArea::find($insertData->id);
      $file = $request->file('driver_doc');
      $filename = 'driver_doc-' . time() . '.' . $file->getClientOriginalExtension();
      $file->move('public/upload/driverDoc/', $filename);
      $user->driver_doc = $filename;
      $user->save();
    }
    Session::flash('success', 'Inserted successfully..!');
    return redirect('view-service');


    /*
     if ($files = $request->image) {
     $destinationPath = public_path('/profile_image/');
      $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
      $path =  $files->move($destinationPath, $profileImage);
      $image = $insert['photo'] = "$profileImage";
    }
    $data = array(
      'name' => $request->name,
      'upload_by' => $uploadBy,
      'users_role' => 3,
      'email' => $request->email,
      'phone' => $request->phone,
      'address' => $request->address,
      'country_id' => $request->country_id,
      'dob' => $request->dob,
      'gender' => $request->gender,
      'password' => Hash::make($request->password),
      'profile_image' =>  $image,
      'created_at' => date('Y-m-d H:i:s'),
    );
    Session::flash('success', 'Inserted successfully..!');
    $insertData = DB::table('users')->insert($data);
    return redirect('view-countrym');
    */
  }
  public function updateService(Request $request, $id)
  {
    // dd($request->all());
    $data = array(
      'service_name' => $request->service_name,
      'country' => $request->country,
      'area' => $request->area,
      'timezone' => $request->timezone,
      'vehicle_service' => $request->vehicle_service,
      // 'sequence' => $request->sequence,
      'driver_minbal' => '',
      'delivery_area' => '',
      'max_tollprice' => '',
      'driver_minbal' => '',
      'bill_method' => '',
      'latitute' => '',
      'longitute' => '',
      'created_at' => date('Y-m-d H:i:s'),
      'updated_at' => date('Y-m-d H:i:s')
    );
    $insertData = DB::table('service_area')->where('id', $id)->update($data);
    if ($request->hasFile('vehicle_doc')) {
      $user = ServicesArea::find($id);
      $file = $request->file('vehicle_doc');
      $filename = 'vehicle_doc-' . time() . '.' . $file->getClientOriginalExtension();
      $file->move('public/upload/vehicleDoc/', $filename);
      $user->vehicle_doc = $filename;
      $user->save();
    }

    if ($request->hasFile('driver_doc')) {
      $user = ServicesArea::find($id);
      $file = $request->file('driver_doc');
      $filename = 'driver_doc-' . time() . '.' . $file->getClientOriginalExtension();
      $file->move('public/upload/driverDoc/', $filename);
      $user->driver_doc = $filename;
      $user->save();
    }
    Session::flash('success', 'Update successfully..!');
    return redirect('view-service');
  }
  public function deleteService(ServicesArea $servicesArea, $id)
  {
    ServicesArea::find($id)->delete();
    Session::flash('success', 'deleted successfully..!');
    return redirect('view-service');
  }

  public function view_service(Request $request)
  {
    if ($request->country != '') {
      $manager = DB::table('service_area')->where('country', $request->country)->get();
    } else {
      $manager = DB::table('service_area')->get();
    }

    $data['content'] = 'admin.service.manage_service';
    return view('layouts.content', compact('data'))->with(['manager' => $manager]);
  }

  public function edit_service($id)
  {
    $editmanager = DB::table('service_area')->where('id', $id)->first();
    $data['content'] = 'admin.service.edit_service';
    return view('layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }

  public function view_foodmerchant()
  {
    $manager = User::where('users_role', 3)->get();
    $data['content'] = 'admin.foodmerchant.manage_foodmerchant';
    return view('layouts.content', compact('data'))->with(['manager' => $manager]);
  }

  public function view_operatormanager()
  {
    $manager = User::where('users_role', 3)->get();
    $data['content'] = 'admin.operatormanager.manage_operatormanager';
    return view('layouts.content', compact('data'))->with(['manager' => $manager]);
  }
  public function view_shopmerchant()
  {
    $manager = User::where('users_role', 3)->get();
    $data['content'] = 'admin.shopmerchant.manage_shopmerchant';
    return view('layouts.content', compact('data'))->with(['manager' => $manager]);
  }
  public function edit_foodmerchant($id)
  {
    $editmanager = User::where('id', $id)->first();
    $data['content'] = 'admin.foodmerchant.edit_foodmerchant';
    return view('layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
  public function edit_shopmerchant($id)
  {
    $editmanager = User::where('id', $id)->first();
    $data['content'] = 'admin.shopmerchant.edit_shopmerchant';
    return view('layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
  public function edit_operatormanager($id)
  {
    $editmanager = User::where('id', $id)->first();
    $data['content'] = 'admin.operatormanager.edit_operatormanager';
    return view('layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
}
