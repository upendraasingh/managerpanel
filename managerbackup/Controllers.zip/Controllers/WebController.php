<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\Category;
use App\Brand;
use App\User;
use DB;
use Hash;
use Auth;

class WebController extends Controller
{
	public function view_subscribe()
	{
		/*echo "hello"; die;*/
		return view('web.subscribe.submitted_details');
	}

	public function subscribe_user(Request $request)
	{
		$cehckemail = DB::table('leads')->where('email', $request->email)->first();

		if($cehckemail!=''){
			return redirect('submitted_details');
		}else{
			$data = array(
				'name' => $request->username, 
				'email' => $request->email, 
				'phone' => $request->mobile, 
				'address' => $request->address, 			
				'password' => 123456788, 			
				'status' => 1, 			
			);

			$insertData = DB::table('leads')->insertGetId($data);			
			/*return View::make('web.subscribe.submitted_details')->with('id', 1);*/

			return view('web.subscribe.submitted_details')->with('insertData', 'insertData');
		}
	}
}