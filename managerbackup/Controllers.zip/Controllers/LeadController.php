<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use App\Exports\ExportContacts;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;
use App\Lead;



class LeadController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }
    
    public function add_referrals(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
            'area' => $request->area,
            'signup_valid' => $request->signup_valid,
            'discount_applicable' => $request->discount_applicable,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'offer_type' => $request->offer_type,
            'discount' => $request->discount,
            'offer_applicablefor' => $request->offer_applicablefor,
            'created_at' => date('Y-m-d H:i:s'),
         );

    
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('referral_configuration')->insert($data);
        return back();
    }

  public function add_lead(Request $request)
  {
    if ($files = $request->image) {
      $destinationPath = public_path('/profile_image/');
      $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
      $path =  $files->move($destinationPath, $profileImage);
      $image = $insert['photo'] = "$profileImage";
    }

    if ($request->image != '') {
      $data = array(
        'name' => $request->name,
        'upload_by' => Session::get('gorgID'),
        'email' => $request->email,
        'phone' => $request->phone,
        'address' => $request->address,
        'country_id' => $request->country_id,
        'dob' => $request->dob,
        'gender' => $request->gender,
        'status_id' => $request->status_id,
        'image' =>  $image,
        'created_at' => date('Y-m-d H:i:s'),
      );
    } else {
      $data = array(
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
        'address' => $request->address,
        'country_id' => $request->country_id,
        'dob' => $request->dob,
        'gender' => $request->gender,
        'status_id' => $request->status_id,
        'created_at' => date('Y-m-d H:i:s'),
      );
    }

    if ($request->edit_id != '') {
      Session::flash('success', 'Updated successfully..!');
      $updateData = DB::table('leads')->where('id', $request->edit_id)->update($data);
      return redirect('manage-leads');
    } else {
      Session::flash('success', 'Inserted successfully..!');
      $insertData = DB::table('leads')->insert($data);
      return redirect('manage-leads');
    }
  }
    public function update_referrals(Request $request)
    {
        $data = array(
            'area' => $request->area,
            'signup_valid' => $request->signup_valid,
            'discount_applicable' => $request->discount_applicable,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'offer_type' => $request->offer_type,
            'discount' => $request->discount,
            'offer_applicablefor' => $request->offer_applicablefor
         );
        
        Session::flash('success', 'Updated successfully..!');
        $updateData = DB::table('referral_configuration')->where('id', $request->id)->update($data);
        return back();
    }
  
    public function update_areservice(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
            'country' => $request->country,
            'area'    => $request->area,
            'sun'     => $request->sun,
            'mon'     => $request->mon,
            'tue'     => $request->tue,
            'wed'     => $request->wed,
            'thu'     => $request->thu,
            'fri'     => $request->fri,
            'sat'     => $request->sat,
            'sunday_start_time'   => $request->sunday_start_time,
            'sunday_end_time'     => $request->sunday_end_time,
            'monday_start_time'   => $request->monday_start_time,
            'monday_end_time'     => $request->monday_end_time,
            'tuesday_start_time'  => $request->tuesday_start_time,
            'tuesday_end_time'    => $request->tuesday_end_time,
            'wednesday_start_time'=> $request->wednesday_start_time,
            'wednesday_end_time'  => $request->wednesday_end_time,
            'thursday_start_time' => $request->thursday_start_time,
            'thursday_end_time'   => $request->thursday_end_time,
            'friday_start_time'   => $request->friday_start_time,
            'friday_end_time'     => $request->friday_end_time,
            'saturday_start_time' => $request->saturday_start_time,
            'saturday_end_time'   => $request->saturday_end_time
        );
        
        Session::flash('success', 'Updated successfully..!');
        $updateData = DB::table('areservice')->where('id', $request->id)->update($data);
        return back();
    }
  
    public function add_areservice(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
            'country'      => $request->country,
            'area'         => $request->area,
            'sun'          => $request->sun,
            'mon'          => $request->mon,
            'tue'          => $request->tue,
            'wed'          => $request->wed,
            'thu'          => $request->thu,
            'fri'          => $request->fri,
            'sat'          => $request->sat,
            'sunday_start_time'   => $request->sunday_start_time,
            'sunday_end_time'     => $request->sunday_end_time,
            'monday_start_time'   => $request->monday_start_time,
            'monday_end_time'     => $request->monday_end_time,
            'tuesday_start_time'   => $request->tuesday_start_time,
            'tuesday_end_time'     => $request->tuesday_end_time,
            'wednesday_start_time'   => $request->wednesday_start_time,
            'wednesday_end_time'     => $request->wednesday_end_time,
            'thursday_start_time'   => $request->thursday_start_time,
            'thursday_end_time'     => $request->thursday_end_time,
            'friday_start_time'   => $request->friday_start_time,
            'friday_end_time'     => $request->friday_end_time,
            'saturday_start_time'   => $request->saturday_start_time,
            'saturday_end_time'     => $request->saturday_end_time,
            'created_at' => date('Y-m-d H:i:s')
        );

    
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('areservice')->insert($data);
        return back(); 
    }

  public function view_lead()
  {
    if (session::get('userRole') == 1) {
      $leads = DB::table('leads')->get();
    } else {
      $leads  = DB::table('leads')->where('upload_by', session::get('gorgID'))->get();
    }
    $data['content'] = 'admin.lead.manage_lead';
    return view('layouts.content', compact('data'))->with(['leads' => $leads]);
  }
  public function addPromocode(Request $request)
  {

  }
  public function view_promocode()
  {
    $leads = DB::table('promocode')->get();
    $data['content'] = 'admin.promocode.manage_promocode';
    return view('layouts.content', compact('data'))->with(['manager' => $leads]);
  }
  public function view_referral()
  {

    $leads = DB::table('referral_configuration')->get();

    $data['content'] = 'admin.referral.manage_referral';
    return view('layouts.content', compact('data'))->with(['manager' => $leads]);
  }
  public function view_areservice()
  {

    $leads = DB::table('areservice')->get();

    $data['content'] = 'admin.areservice.manage_areservice';
    return view('layouts.content', compact('data'))->with(['manager' => $leads]);
  }

  public function edit_lead($id)
  {
    $editlead = DB::table('leads')->where('id', $id)->first();
    $data['content'] = 'admin.lead.edit_lead';
    return view('layouts.content', compact('data'))->with(['editlead' => $editlead]);
  }

  public function edit_promocode($id)
  {
    $editlead = DB::table('leads')->where('id', $id)->first();
    $data['content'] = 'admin.promocode.edit_promocode';
    return view('layouts.content', compact('data'))->with(['manager' => $editlead]);
  }

  public function edit_referral($id)
  {
    $editlead = DB::table('referral_configuration')->where('id', $id)->first();
    $data['content'] = 'admin.referral.edit_referral';
    return view('layouts.content', compact('data'))->with(['manager' => $editlead]);
  }
  public function edit_areservice($id)
  {
    $editlead = DB::table('areservice')->where('id', $id)->first();
    $data['content'] = 'admin.areservice.edit_areservice';
    return view('layouts.content', compact('data'))->with(['manager' => $editlead]);
  }

  public function lead_view($id)
  {
    $viewlead = DB::table('leads')->where('id', $id)->first();
    $data['content'] = 'admin.lead.view_lead';
    return view('layouts.content', compact('data'))->with(['viewlead' => $viewlead]);
  }
  
    public function delete_referral($id)
    {
        $delete = DB::table('leads')->where('id', $id)->delete();
        Session::flash('error', 'Lead data delete successfully..!');
        return back();  
    }

  public function delete_lead($id)
  {
    $delete = DB::table('leads')->where('id', $id)->delete();
    Session::flash('error', 'Lead data delete successfully..!');
    return back();
  }

  public function search_lead(Request $request)
  {
    if ($request->employee_id != '') {
      $id = $request->employee_id ?? '';
    } elseif ($request->whitelabel_id != '') {
      $id = $request->whitelabel_id ?? '';
    } elseif ($request->manager_id != '') {
      $id = $request->manager_id ?? '';
    }

    $leads = DB::table('leads')->where('upload_by', $id)->get();
    $data['content'] = 'admin.lead.manage_lead';
    return view('layouts.content', compact('data'))->with(['leads' => $leads, 'whitelabel_id' => $request->whitelabel_id, 'manager_id' => $request->manager_id, 'employee_id' => $request->employee_id]);
  }

  public function search_status(Request $request)
  {
    if (Session::get('userRole') == 1) {
      $leads = DB::table('leads')->where('status_id', $request->status_id)->get();
    } else {
      $leads = DB::table('leads')->where('status_id', $request->status_id)->where('upload_by', Session::get('gorgID'))->get();
    }

    $data['content'] = 'admin.lead.manage_lead';
    return view('layouts.content', compact('data'))->with(['leads' => $leads, 'status_id' => $request->status_id]);
  }

  public function lead_search_by_date(Request $request)
  {
    $from =  date("Y-m-d", strtotime($request->from_date));
    $to = date("Y-m-d", strtotime($request->end_date));

    $leads = DB::table('leads')->whereBetween('created_at', [$from, $to])->get();

    if (sizeof($leads) > 0) {
      $data['content'] = 'admin.lead.manage_lead';
      Session::flash('success', 'Record Found successfully..!');
      return view('layouts.content', compact('data'))->with(['leads' => $leads, 'fromdate' => $request->from_date, 'enddate' => $request->end_date]);
    } else {
      Session::flash('error', 'No Record Found..!');
      $data['content'] = 'admin.lead.manage_lead';
      return view('layouts.content', compact('data'))->with(['leads' => $leads]);
    }
  }

  public function export()
  {
    return Excel::download(new ExportContacts, 'Leads.xlsx');
  }
}
