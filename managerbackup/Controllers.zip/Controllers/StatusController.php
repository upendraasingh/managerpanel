<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;
use App\Lead;


class StatusController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth');
    $this->middleware('role');
  }

  public function add_status(Request $request){
    $data = array(
      'status_name' => $request->status_name,  
      'upload_by' => Session::get('gorgID'),        
      'status' => $request->status,          
      'created_at' => date('Y-m-d H:i:s'),
    );     
    
    if($request->ids!= ''){
      Session::flash('success','Updated successfully..!');
      $updateData = DB::table('status')->where('id', $request->ids)->update($data);
      return redirect('listing-status');
    }
    else{
      Session::flash('success','Inserted successfully..!');
      $insertData = DB::table('status')->insert($data);
      return redirect('listing-status');
    } 
  }
  
  public function listing_status(){
    $statusdata = DB::table('status')->get();
    $data['content'] = 'admin.status.manage_status';
    return view('layouts.content', compact('data'))->with(['statusdata' => $statusdata ]);
  }

  public function model_view($id){
    $modeldata = DB::table('category')->where('id', $id)->first();
    $data['content'] = 'admin.category.view_category';
    return view('layouts.content', compact('data'))->with(['modeldata' => $modeldata ]);
  }

  public function edit_status($id) {
    $data = DB::table('status')->where('id', $id)->first();
    return response()->json($data);
  }

  public function delete_status($id){
    $delete = DB::table('status')->where('id', $id)->delete();
    Session::flash('error','Data delete successfully..!');
    return back();
  } 
}
