<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//use  App\User;
use  App\Manager;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use URL;
use DB;

class ManagerController extends Controller
{
    public function register(Request $request)
    {
        
        $this->validate($request, [
            //'first_name' => 'required|string',
            //'last_name' => 'required|string',
            'mobile' => 'required|integer',
            'email' => 'required|email',
            'password' => 'nullable|required_with:password_confirmation|string|confirmed',
            'password_confirmation' => 'required',
            //'user_type' => 'required|integer',
        ]);

        try 
        {  
            
            $userd = DB::table('driveuser')->where('email', $request->email)->first();
            
            if($userd ==null)
            {
               
                if($file = $request->file('frontlicensephoto')) {
                    $destinationPath = base_path('public/Media/');
                    $frontlicensephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $frontlicensephoto);
                }
                if($file = $request->file('backlicensephoto')) {
                    $destinationPath = base_path('public/Media/');
                    $backlicensephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $backlicensephoto);
                }
                if($file = $request->file('plno')) {
                    $destinationPath = base_path('public/Media/');
                    $plno = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $plno);
                }
                if($file = $request->file('crno')) {
                    $destinationPath = base_path('public/Media/');
                    $crno = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $crno);
                }
                if($file = $request->file('vehiclephoto')) {
                    $destinationPath = base_path('public/Media/');
                    $vehiclephoto = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $vehiclephoto);
                }
                if($file = $request->file('profilephoto_url')) {
                    $destinationPath = base_path('public/Media/');
                    $profilephoto_url = uniqid('file') . "-" . $file->getClientOriginalName();
                    $path = $file->move($destinationPath, $profilephoto_url);
                }
                //echo $profilephoto_url;die;
                $plainPassword          = app('hash')->make($request->input('password'));
                
                $datass =array(
                    'firstname'        => $request->input('firstname'),
                    'middlename'       => $request->input('middlename'),
                    'lastname'         => $request->input('lastname'),
                    'mobile'            => $request->input('mobile'),
                    'email'            => $request->input('email'),
                    'referralcode'     => $request->input('referralcode'),
                    'accname'          => $request->input('accname'),
                    'gcashno'          => $request->input('gcashno'),
                    'dob'              => $request->input('dob'),
                    'profilephoto_url' => isset($profilephoto_url),
                    'isactive'           => 0,
                    'password'         => $plainPassword,
                );
                //echo "hi";die;
                $addData = DB::table('driveuser')->insertGetId($datass);
                
                //echo $addData;die;
                $docdata = array(
                    'driver_id'         => $addData,
                    'frontlicensephoto' => $request->frontlicensephoto, 
                    'backlicensephoto'  => $request->backlicensephoto ,
                    'plno'              => $request->plno ,
                    'crno'              => $request->crno,
                    'vehiclephoto'      => $request->vehiclephoto,
                    'vehicle_id'        => $request->vehicle,
                );
                $addDataId = array(
                    'driver_id'         => $addData,
                    
                );
                $addDatadoc = DB::table('drivepersonaldoc')->insertGetId($docdata);
                if($request->input('mobile')){

                    $credentials = $request->only(['mobile','password']);
                   
                }
                
                if ($token = Auth::guard('driverapi')->attempt($credentials)) {
        
                    
                    
                    $addDataId['login_data'] =  $this->respondWithToken($token);
                    
                }
                
                $data = collect(["StatusCode" => "200", "Status" => "Success", "data" => $addDataId]);
                return response()->json($data, 200);
            }
            else{
                return response()->json(['StatusCode' => 404,'Status' => 'Failed','message' => 'Driver already registered'], 200);
            }
            
            

        }   catch (\Exception $e) {
           
            return response()->json(['StatusCode' => "422", 'Status' => 'Failed','message' => 'Driver Registration Failed!'], 500);
        }
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'email' => 'required',
            'password' => 'required',
        ]);

        
        $credentials = $request->only(['email', 'password']);
        //$check = DB::table('driveuser')->where('mobile', '=', $request->mobile)->get();
        
        /*if (Hash::check($request->password, $check->password)) { */
         
            if (! $token = Auth::guard('manager')->attempt($credentials)) {
            
            return response()->json(['message' => 'Invalid credentials', 'status' => 201], 401);
            
            }else{
                
                

                $finalData = array();
                
                $userd = DriverUser::where('email', $request->mobile)->first();
                DB::table('driveuser')
                ->where('mobile', $request->mobile)  // find your user by their email
                ->limit(1)  // optional - to ensure only one record is updated.
                ->update(array('latitude' => $request->latitude,'longitude' => $request->longitude));  // update the record in the DB. 
                
                $finalData =  array('token'        =>$this->respondWithToken($token));
                        
                //print_r($finalData);die;        $this->respondWithToken($token)->getData()->token            
                $data = collect(["StatusCode" => "200", "Status" => "Success",'message' => 'Driver login successfully!', 'driver_id'       =>$userd['id'],
                                                                            'first_name'    =>$userd['first_name'],
                                                                            'last_name'     =>$userd['last_name'],
                                                                            'email'         =>$userd['email'],
                                                                            'phone'         =>$userd['phone'],
                                                                            'profile_image' =>URL::to('/')."/public/Media/".$userd['profile_image'],
                                                                            "data"          =>$this->respondWithToken($token)]);
                return response()->json($data, 200);
            }
        /*}*/
        
        
        
    }

    protected function respondWithToken($token)
    {
        return response()->json([  
            'success' => true, 
            'access_token' => $token,
            'token_type' => 'bearer',
        ]);
    }  

}