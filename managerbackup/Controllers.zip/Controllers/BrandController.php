<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;
use App\Lead;


class BrandController extends Controller
{

  public function __construct()
  {
    $this->middleware('auth');
    $this->middleware('role');
  }

  public function add_brand(Request $request)
  {
    /*print_r($request->all()); die;*/
    if($files = $request->logo){
      $destinationPath = public_path('/brand_image/');
      $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
      $path =  $files->move($destinationPath, $profileImage);
      $image = $insert['photo'] = "$profileImage";
    }

    if($request->logo!=''){
      $data = array(
        'brand_name' => $request->brand_name,
        'status' => $request->status,
        'logo' =>  $image,   
        'upload_by' => Session::get('gorgID'),
        'created_at' => date('Y-m-d H:i:s'),
      );    
    }else{
      $data = array(
        'brand_name' => $request->brand_name,       
        'upload_by' => Session::get('gorgID'),
        'status' => $request->status,
        'created_at' => date('Y-m-d H:i:s'),
      );
    }
    
    if($request->ids!= ''){
      Session::flash('success','Updated successfully..!');
      $updateData = DB::table('brand')->where('id', $request->ids)->update($data);
      return redirect('view-brand');
    }
    else{
      Session::flash('success','Inserted successfully..!');
      $insertData = DB::table('brand')->insert($data);
      return redirect('view-brand');
    } 
  }
  
  public function view_brand()
  {
    $brand = DB::table('brand')->get();
    $data['content'] = 'admin.brand.manage_brand';
    return view('layouts.content', compact('data'))->with(['brand' => $brand ]);
  }

  public function brand_view($id)
  {
   /**/
      $editdata = DB::table('brand')->where('id', $id)->first();
       /*print_r($editdata); die;*/
      $data['content'] = 'admin.brand.view_brand';
      return view('layouts.content', compact('data'))->with(['editdata' => $editdata ]);
  }

  public function edit_brand($id)
  {
    /*print_r($id); die;*/
    $editdata = DB::table('brand')->where('id', $id)->first();
    $data['content'] = 'admin.brand.edit_brand';
    return view('layouts.content', compact('data'))->with(['editdata' => $editdata ]);
  }

  public function delete_brand($id)
  {
    $delete = DB::table('brand')->where('id', $id)->delete();
    Session::flash('error','Data delete successfully..!');
    return back();
  }
}
