<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\DuraPickupShedule;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;


class ManagerrideControllers extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
        //$this->middleware('role');
    }

    public function manager_view_rides(Request $request)
    {
        $manager = DB::table('durapickupshedule')
                    ->select('durapickupshedule.*', 'driveuser.firstname', 'driveuser.middlename', 'driveuser.mobile', 'vehicle.id as vid', 'vehicle.vehicle_type')
                    ->join('driveuser', 'durapickupshedule.driver_id', '=', 'driveuser.id')
                    ->join('vehicle', 'durapickupshedule.vehicle_id', '=', 'vehicle.id')
                    // ->where('durapickupshedule.status', '=', 'success')
                    ->get();
        
        $data['content'] = 'manager.rides.view_rides';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
    public function auto_cancelledrides()
    {
        //$manager = User::where('users_role', 3)->get();
        $manager = DB::table('durapickupshedule')
          ->select('durapickupshedule.*', 'driveuser.firstname', 'driveuser.middlename', 'driveuser.mobile', 'vehicle.id as vid', 'vehicle.vehicle_type')
          ->join('driveuser', 'durapickupshedule.driver_id', '=', 'driveuser.id')
          ->join('vehicle', 'durapickupshedule.vehicle_id', '=', 'vehicle.id')
          ->where('durapickupshedule.status', '=', 'Auto Cancelled')
          ->get();
        $data['content'] = 'manager.ride.auto_cancelledrides';
        return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
    }
  public function failed_rides()
  {
    // $manager = User::where('users_role', 3)->get();
    $manager = DB::table('durapickupshedule')
      ->select(
        'durapickupshedule.*',
        'driveuser.firstname',
        'driveuser.middlename',
        'driveuser.mobile',
        'vehicle.id as vid',
        'vehicle.vehicle_type'
      )
      ->join('driveuser', 'durapickupshedule.driver_id', '=', 'driveuser.id')
      ->join('vehicle', 'durapickupshedule.vehicle_id', '=', 'vehicle.id')
      ->where('durapickupshedule.status', '=', 'Failed')
      ->get();
    $data['content'] = 'manager.ride.failed_rides';
    return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
  }
  public function calcelled_rides()
  {
    $manager = DB::table('durapickupshedule')
      ->select('durapickupshedule.*', 'driveuser.firstname', 'driveuser.middlename', 'driveuser.mobile', 'vehicle.id as vid', 'vehicle.vehicle_type')
      ->join('driveuser', 'durapickupshedule.driver_id', '=', 'driveuser.id')
      ->join('vehicle', 'durapickupshedule.vehicle_id', '=', 'vehicle.id')
      ->where('durapickupshedule.status', '=', 'Cancelled')
      ->get();
    $data['content'] = 'manager.ride.calcelled_rides';
    return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
  }
  public function completed_rides()
  {
    //$manager = User::where('users_role', 3)->get();
    $manager = DB::table('durapickupshedule')
      ->select('durapickupshedule.*', 'driveuser.firstname', 'driveuser.middlename', 'driveuser.mobile', 'vehicle.id as vid', 'vehicle.vehicle_type')
      ->join('driveuser', 'durapickupshedule.driver_id', '=', 'driveuser.id')
      ->join('vehicle', 'durapickupshedule.vehicle_id', '=', 'vehicle.id')
      ->where('durapickupshedule.status', '=', 'Completed')
      ->get();
    $data['content'] = 'manager.ride.completed_rides';
    return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
  }
  public function ongoing_rides()
  {
    $manager = DB::table('durapickupshedule')
      ->select('durapickupshedule.*', 'driveuser.firstname', 'driveuser.middlename', 'driveuser.mobile', 'vehicle.id as vid', 'vehicle.vehicle_type')
      ->join('driveuser', 'durapickupshedule.driver_id', '=', 'driveuser.id')
      ->join('vehicle', 'durapickupshedule.vehicle_id', '=', 'vehicle.id')
      ->where('durapickupshedule.status', '=', 'Item pickedup')
      ->get();
      //dd($manager);
    $data['content'] = 'manager.ride.ongoing_rides';
    return view('manager_layouts.content', compact('data'))->with(['manager' => $manager]);
  }


  public function edit_shopmerchant($id)
  {
    $editmanager = User::where('id', $id)->first();
    $data['content'] = 'manager.shopmerchant.edit_shopmerchant';
    return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
  public function edit_operatormanager($id)
  {
    $editmanager = User::where('id', $id)->first();
    $data['content'] = 'manager.operatormanager.edit_operatormanager';
    return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
  public function edit_driver($id)
  {
    $editmanager = User::where('id', $id)->first();
    $data['content'] = 'manager.driver.edit_driver';
    return view('manager_layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
  public function edit_ride($id)
  {
    $editmanager = DB::table('durapickupshedule')
      ->where('durapickupshedule.id', '=', $id)
      ->first();
    $driverData = DB::table('driveuser')
      ->get()->toArray();

    $vehicleData = DB::table('vehicle')
      ->get()->toArray();
    $data['content'] = 'manager.ride.edit_rides';
    return view('manager_layouts.content', compact('data'))->with([
      'editmanager' => $editmanager,
      'driverData' => $driverData,
      'vehicleData' => $vehicleData
    ]);
  }
  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
    //dd($request->all());
    $validator = Validator::make($request->all(), array(
      'pickup_address1'     => 'required',
      'pickup_name'         => 'required',
      'status'              => 'required'

    ));
    if ($validator->fails()) {
      return back()->withErrors($validator)->withInput();
    }
    try {
      $editmanager = DuraPickupShedule::find($id);
      $updateData = array(
        "pickup_address1" => $request->has('pickup_address1') ? $request->pickup_address1 : "",
        "pickup_address2" => $request->has('pickup_address2') ? $request->pickup_address2 : "",
        "pickup_name" => $request->has('pickup_name') ? $request->pickup_name : "",
        "pickup_mobile" => $request->has('pickup_mobile') ? $request->pickup_mobile : "",
        "destination_address1" => $request->has('destination_address1') ? $request->destination_address1 : "",
        "destination_address2" => $request->has('destination_address2') ? $request->destination_address2 : "",
        "destination_name" => $request->has('destination_name') ? $request->destination_name : "",
        "type" => $request->has('type') ? $request->type : "",
        "pdate" => $request->has('pdate') ? $request->pdate : "",
        "stop_address1" => $request->has('stop_address1') ? $request->stop_address1 : "",
        "stop_address2" => $request->has('stop_address2') ? $request->stop_address2 : "",
        "stop_name" => $request->has('stop_name') ? $request->stop_name : "",
        "stop_mobile" => $request->has('stop_mobile') ? $request->stop_mobile : "",
        "price" => $request->has('price') ? $request->price : "",
        "drivernote" => $request->has('drivernote') ? $request->drivernote : "",
        "tip" => $request->has('tip') ? $request->tip : "",
        "itemtype" => $request->has('itemtype') ? $request->itemtype : "",
        "coupon" => $request->has('coupon') ? $request->coupon : "",        
        "status" => $request->has('status') ? $request->status : "",
      );
      $editmanager->update($updateData);

      return redirect('manager-ride-management/view-rides')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
    } catch (\exception $e) {
      return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
      return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
    }
  }
}
