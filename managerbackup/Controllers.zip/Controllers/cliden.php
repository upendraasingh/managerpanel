<style type="text/css">
   .colerclass{
   color: #317eeb;
   }
   .menustyle{
   margin: 10px;
   }
</style>
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Add Products</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Add Products</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add/product')}}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <input type="hidden" name="ids" id="ids">
                     <div class="row">

                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Product Name : <font color="red">*</font></label>
                              <input  type="text" id="product_name" name="product_name" class="form-control" required="" aria-required="true" placeholder="" autocomplete="off"> 
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Product Price : <font color="red">*</font></label>
                              <input  type="text" id="product_price" name="product_price" class="form-control" required="" aria-required="true" placeholder="" maxlength="9"> 
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $brand = DB::table('brand')->get(); ?>
                              <label class="control-label">Brand : <font color="red">*</font></label>
                              <select class="form-control" id="brand_id" name="brand_id" required="">
                                <!--  @if($productData->brand_name ?? '')
                                 <option> {{ $productData->category_name }} </option>
                                 @endif -->
                                 <option value=""> Choose Brand</option>
                                 @foreach($brand as $value)
                                 <option value="{{ $value->id }}">{{ $value->brand_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $category = DB::table('category')->get(); ?>
                              <label class="control-label">Category : <font color="red">*</font></label>
                              <select class="form-control" id="category_id" name="category_id" required="">
                                <!--  @if($productData->brand_name ?? '')
                                 <option> {{ $productData->category_name }} </option>
                                 @endif -->
                                 <option value=""> Choose Category</option>
                                 @foreach($category as $value)
                                 <option value="{{ $value->id }}">{{ $value->category_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $branch = DB::table('branches')->get(); ?>
                              <label class="control-label">Branch : <font color="red">*</font></label>
                              <select class="form-control" id="branch_id" name="branch_id" required="">
                                <!--  @if($productData->brand_name ?? '')
                                 <option> {{ $productData->category_name }} </option>
                                 @endif -->
                                 <option value=""> Choose Branch</option>
                                 @foreach($branch as $value)
                                 <option value="{{ $value->id }}">{{ $value->branch_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Inventory <font color="red">*</font></label>
                              <input type="text" id="inventory" name="inventory" class="form-control" required="" aria-required="true" placeholder=""> 
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group"> 
                              <label class="control-label">Image <font color="red">*</font></label><input  type="file" id="image" name="image[]" class="form-control" required="" aria-required="true" accept="image/x-png,image/gif,image/jpeg"  multiple>
                              <div id="image_preview" style="width: 25%;"></div>
                           </div>
                        </div>
                       <!--  <div class="col-md-6">
                           <div class="form-group">
                              <p class="control-label"><b>Status</b> <font color="red">*</font></p>
                              <div class="radio radio-info form-check-inline">
                                 <input type="radio" id="active" value="0" name="status" checked="">
                                 <label for="inlineRadio1"> Active </label>
                              </div>
                              <div class="radio radio-info form-check-inline">
                                 <input type="radio" id="inactive" value="1" name="status">
                                 <label for="inlineRadio1"> Inactive </label>
                              </div>
                           </div>
                        </div> -->
                     </div>

                     <hr>
                     <h3>Specification</h3>

                     <p>
                        <button class="btn btn-primary waves-effect btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"></i><span>Basic Specification </span><span class="pull-right"><i class="md md-add"></i></span></button>
                     </p>
                     <div class="collapse" id="collapseExample">
                        <div class="card card-body">
                           <div class="row" id="main_speci_id">
                              <div class="col-md-5">
                                 <div class="form-group">
                                    <?php $basic_speci = DB::table('basic_specification')->get(); ?>
                                    <select class="form-control" id="main_specification" name="main_specification[]" required="">
                                      <!--  @if($productData->brand_name ?? '')
                                       <option> {{ $productData->category_name }} </option>
                                       @endif -->
                                       <option value=""> Choose Basic Specification</option>
                                       @foreach($basic_speci as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-md-5">
                                 <div class="form-group">  
                                    <input  type="text" id="basic_speci_value" name="basic_speci_value[]" class="form-control" required="" aria-required="true" placeholder=""> 
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addCF btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                     <hr>

                     <p>
                        <button class="btn btn-primary waves-effect btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseExample2" aria-expanded="false" aria-controls="collapseExample2"></i><span>Engine </span><span class="pull-right"><i class="md md-add"></i></span></button>
                     </p>
                     <div class="collapse" id="collapseExample2">
                        <div class="card card-body">
                           <div class="row" id="engine_section">
                              <div class="col-md-5">
                                 <div class="form-group">
                                    <?php $engine = DB::table('engine')->get(); ?>
                                    <select class="form-control" id="engine" name="engine[]" required="">
                                      <!--  @if($productData->brand_name ?? '')
                                       <option> {{ $productData->category_name }} </option>
                                       @endif -->
                                       <option value="">Choose Engine</option>
                                       @foreach($engine as $value)
                                       <option value="{{ $value->id }}">{{ $value->engine_key_name }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-md-5">
                                 <div class="form-group">  
                                    <input  type="text" id="engine_value_name" name="engine_value_name[]" class="form-control" required="" aria-required="true" placeholder=""> 
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addENG btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                     <hr>

                     <p>
                        <button class="btn btn-primary waves-effect btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseExample3" aria-expanded="false" aria-controls="collapseExample3"></i><span>Chasis </span><span class="pull-right"><i class="md md-add"></i></span></button>
                     </p>
                     <div class="collapse" id="collapseExample3">
                        <div class="card card-body">
                           <div class="row" id="chasis_section">
                              <div class="col-md-5">
                                 <div class="form-group">
                                    <?php $chasis = DB::table('chasis')->get(); ?>
                                    <select class="form-control" id="chasis" name="chasis[]" required="">
                                      <!--  @if($productData->brand_name ?? '')
                                       <option> {{ $productData->category_name }} </option>
                                       @endif -->
                                       <option value="">Choose Chasis</option>
                                       @foreach($chasis as $value)
                                       <option value="{{ $value->id }}">{{ $value->chasis_key_name }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-md-5">
                                 <div class="form-group">  
                                    <input  type="text" id="chasis_value_name" name="chasis_value_name[]" class="form-control" required="" aria-required="true" placeholder=""> 
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addCHA btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                     <hr>

                     <p>
                        <button class="btn btn-primary waves-effect btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseExample4" aria-expanded="false" aria-controls="collapseExample4"></i><span>Super Comfortable </span><span class="pull-right"><i class="md md-add"></i></span></button>
                     </p>
                     <div class="collapse" id="collapseExample4">
                        <div class="card card-body">
                           <div class="row" id="sprconf_section">
                              <div class="col-md-5">
                                 <div class="form-group">
                                    <?php $super_comfortable = DB::table('super_comfortable')->get(); ?>
                                    <select class="form-control" id="super_comfortable" name="super_comfortable[]" required="">
                                      <!--  @if($productData->brand_name ?? '')
                                       <option> {{ $productData->category_name }} </option>
                                       @endif -->
                                       <option value=""> Choose Super Comfortable</option>
                                       @foreach($super_comfortable as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-md-5">
                                 <div class="form-group">  
                                    <input  type="text" id="super_comfortable_value" name="super_comfortable_value[]" class="form-control" required="" aria-required="true" placeholder=""> 
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addSPRCON btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                     <hr>

                     <p>
                        <button class="btn btn-primary waves-effect btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseExample5" aria-expanded="false" aria-controls="collapseExample5"></i><span>Multidimensional Security </span><span class="pull-right"><i class="md md-add"></i></span></button>
                     </p>
                     <div class="collapse" id="collapseExample5">
                        <div class="card card-body">
                           <div class="row" id="multi_secuarty_id">
                              <div class="col-md-5">
                                 <div class="form-group">
                                    <?php $multidimensional_security = DB::table('multidimensional_security')->get(); ?>
                                    <select class="form-control" id="multi_secuarity" name="multi_secuarity[]" required="">
                                      <!--  @if($productData->brand_name ?? '')
                                       <option> {{ $productData->category_name }} </option>
                                       @endif -->
                                       <option value=""> Choose Multidimensional Security</option>
                                       @foreach($multidimensional_security as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-md-5">
                                 <div class="form-group">  
                                    <input  type="text" id="multi_secuarity_value" name="multi_secuarity_value[]" class="form-control" required="" aria-required="true" placeholder=""> 
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addMLTSCR btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                     <hr>

                      <p>
                        <button class="btn btn-primary waves-effect btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseExample6" aria-expanded="false" aria-controls="collapseExample6"></i><span>Entertainment </span><span class="pull-right"><i class="md md-add"></i></span></button>
                     </p>
                     <div class="collapse" id="collapseExample6">
                        <div class="card card-body">
                           <div class="row" id="entertainment_id">
                              <div class="col-md-5">
                                 <div class="form-group">
                                    <?php $entertainment = DB::table('entertainment')->get(); ?>
                                    <select class="form-control" id="entertainment" name="entertainment[]" required="">
                                       <option value=""> Choose Entertainment</option>
                                       @foreach($entertainment as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-md-5">
                                 <div class="form-group">  
                                    <input  type="text" id="entertainment_value" name="entertainment_value[]" class="form-control" required="" aria-required="true" placeholder=""> 
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addENTMNT btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                                       
                     <div class="modal-footer">
                        <button type="submit" id="submitbtn" class="btn btn-primary">Submit</button>
                     </div>
                  </div>
                  <!-- End card-body -->
               </div>
               <!-- End card -->
            </div>
            <!-- end col -->
         </div>
         <!-- End row -->
      </form>
      <!-- Form End -->
   </div>
   <!-- container -->
</div>

<!-- Main Specication Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addCF").click(function(_val)
      {
         $("#main_speci_id").append('<div class="col-md-5"><div class="form-group">                                    <?php $basic_speci = DB::table('basic_specification')->get(); ?>                                    <select class="form-control" id="main_specification" name="main_specification[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value=""> Choose Basic Specification</option>                                      @foreach($basic_speci as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                    <input  type="text" id="basic_speci_value" name="basic_speci_value[]" class="form-control" required="" aria-required="true" placeholder="">                                 </div>                              </div>                              <div class="col-md-2">                                 <div class="form-group">                                     <a href="javascript:void(0);" class="remCF btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#main_speci_id").on('click','.remCF',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Engine Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addENG").click(function(_val)
      {
         $("#engine_section").append('<div class="col-md-5"><div class="form-group">                                    <?php $engine = DB::table('engine')->get(); ?>
                                    <select class="form-control" id="engine" name="engine[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value="">Choose Engine</option>                                       @foreach($engine as $value)                                       <option value="{{ $value->id }}">{{ $value->engine_key_name }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="engine_value_name" name="engine_value_name[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                 <div class="form-group"> <a href="javascript:void(0);" class="removeENG btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#engine_section").on('click','.removeENG',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Chahis Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addCHA").click(function(_val)
      {
         $("#chasis_section").append('<div class="col-md-5">                                 <div class="form-group">                                    <?php $chasis = DB::table('chasis')->get(); ?>
                                    <select class="form-control" id="chasis" name="chasis[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value="">Choose Chasis</option>                                       @foreach($chasis as $value)                                       <option value="{{ $value->id }}">{{ $value->chasis_key_name }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                             <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="chasis_value_name" name="chasis_value_name[]" class="form-control" required="" aria-required="true" placeholder="">                                 </div>                              </div>                              <div class="col-md-2"> <a href="javascript:void(0);" class="removeCHA btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#chasis_section").on('click','.removeCHA',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Super Confurtable Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addSPRCON").click(function(_val)
      {
         $("#sprconf_section").append('<div class="col-md-5">                                 <div class="form-group">                                    <?php $super_comfortable = DB::table('super_comfortable')->get(); ?>
                                    <select class="form-control" id="super_comfortable" name="super_comfortable[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value=""> Choose Super Comfortable</option>                                       @foreach($super_comfortable as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="super_comfortable_value" name="super_comfortable_value[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                <div class="form-group"> <a href="javascript:void(0);" class="removeSPRCON btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#sprconf_section").on('click','.removeSPRCON',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- MLTSERT Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addMLTSCR").click(function(_val)
      {
         $("#multi_secuarty_id").append('<div class="col-md-5">                                 <div class="form-group">                                    <?php $multidimensional_security = DB::table('multidimensional_security')->get(); ?>
                                    <select class="form-control" id="multi_secuarity" name="multi_secuarity[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value=""> Choose Multidimensional Security</option>                                       @foreach($multidimensional_security as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="multi_secuarity_value" name="multi_secuarity_value[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                <div class="form-group"> <a href="javascript:void(0);" class="removeMLTSCR btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#multi_secuarty_id").on('click','.removeMLTSCR',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Entertainment Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addENTMNT").click(function(_val)
      {
         $("#entertainment_id").append('<div class="col-md-5">                                <div class="form-group">                                    <?php $entertainment = DB::table('entertainment')->get(); ?>
                                    <select class="form-control" id="entertainment" name="entertainment[]" required="">                                       <option value=""> Choose Entertainment</option>                                       @foreach($entertainment as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="entertainment_value" name="entertainment_value[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                <div class="form-group"> <a href="javascript:void(0);" class="removeENTMNT btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#entertainment_id").on('click','.removeENTMNT',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

