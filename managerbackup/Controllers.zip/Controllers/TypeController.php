<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\VehicleType;
use App\VehicleMake;
use App\VehicleModel;
use App\WalletPackage;
use App\PaymentMode;
use App\StandardRules;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;

class TypeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }

    public function add_marketplace()
    {
        $data = array(
            'user_id' => $_GET['user_id'],
            'watch_id' => $_GET['watch_id'],
        );
        $insertData = DB::table('marketplace')->insert($data);
        $customerdelete = DB::table('issafe')->where('id', $_GET['id'])->delete();
        if ($insertData) {
            return 1;
        } else {
            return 2;
        }
    }

    public function add_banner(Request $request)
    {
        if ($files = $request->image) {
            $destinationPath = public_path('/profile_image/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }

        if ($request->image != '') {
            $data = array(
                'name' => $request->name,
                'upload_by' => Session::get('gorgID'),
                'email' => $request->email,
                'phone' => $request->phone,
                'address' => $request->address,
                'country_id' => $request->country_id,
                'dob' => $request->dob,
                'gender' => $request->gender,
                'password' => Hash::make($request->password),
                'view_password' => $request->password,
                'profile_image' =>  $image,
                'created_at' => date('Y-m-d H:i:s'),
                'users_role' => 5,
            );
        } else {
            $data = array(
                'name' => $request->name,
                'upload_by' => Session::get('gorgID'),
                'email' => $request->email,
                'phone' => $request->phone,
                'address' => $request->address,
                'country_id' => $request->country_id,
                'dob' => $request->dob,
                'gender' => $request->gender,
                'password' => Hash::make($request->password),
                'view_password' => $request->password,
                'created_at' => date('Y-m-d H:i:s'),
                'users_role' => 5,
            );
        }

        if ($request->edit_id != '') {
            Session::flash('success', 'Updated successfully..!');
            $updateData = DB::table('users')->where('id', $request->edit_id)->update($data);
            return redirect('view-type');
        } else {
            Session::flash('success', 'Inserted successfully..!');
            $insertData = DB::table('users')->insert($data);
            return redirect('view-type');
        }
    }

    public function view_type(Request $request)
    {
        if ($request->v_type != '') {
            $categorydata = DB::table('vehicle_type')->where('v_type', $request->v_type)->get();
        } else {
            $categorydata = DB::table('vehicle_type')->get();
        }

        $data['content'] = 'admin.type.manage_type';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function storeVehicleType(Request $request)
    {
        // dd($request->all());
        // $validator = Validator::make($request->all(), [
        //     'v_type'          => 'required',
        //     'v_rank'         => 'required',
        //     'v_sequence'         =>  'required',
        //     'v_for'         =>  'required',
        //     'delivery_type'         =>  'required',
        //     'v_description'         =>  'required',
        //     'v_status'         =>  'required',
        // ]);
        // if ($validator->fails()) {
        //     return back()->withErrors($validator)->withInput();
        // }
        try {
            $vehicleTypeData =  VehicleType::create([
                'v_type'            => $request->v_type,
                'v_rank'            => $request->v_rank,
                "v_sequence"        => $request->v_sequence,
                "v_for"             => $request->v_for,
                "delivery_type"     => $request->delivery_type,
                "v_description"     => $request->v_description,
                "v_status"            => $request->status,
            ]);
            if ($request->hasFile('v_image')) {
                $user = VehicleType::find($vehicleTypeData->id);
                $file = $request->file('v_image');
                $filename = 'v_image-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/vehicle_image/', $filename);
                $user->v_image = $filename;
                $user->save();
            }
            return redirect('/view-type')->with(array('status' => 'success', 'message' => 'New vehicle type Successfully created!'));
        } catch (\Exception $e) {
            // return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }

    public function edit_type($id)
    {
        $editclient = VehicleType::where('id', $id)->first();
        $data['content'] = 'admin.type.edit_type';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }

    public function updateVehicleType(Request $request, $id)
    {
        try {
            $companyData = VehicleType::find($id);
            $updateData = array(
                "v_type"            => $request->has('v_type') ? $request->v_type : "",
                "v_rank"            => $request->has('v_rank') ? $request->v_rank : "",
                "v_sequence"        => $request->has('v_sequence') ? $request->v_sequence : "",
                "v_for"             => $request->has('v_for') ? $request->v_for : "",
                "delivery_type"     => $request->has('delivery_type') ? $request->delivery_type : "",
                "v_description"     => $request->has('v_description') ? $request->v_description : "",
                "v_status"          => $request->has('v_status') ? $request->v_status : "",
            );
            $companyData->update($updateData);
            if ($request->hasFile('v_image')) {
                $user = VehicleType::find($id);
                $file = $request->file('v_image');
                $filename = 'v_image-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/vehicle_image/', $filename);
                $user->v_image = $filename;
                $user->save();
            }
            return redirect('/view-type')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }
    public function view_make(Request $request)
    {
        if ($request->vehicle_types != '') {
            $categorydata = VehicleMake::where('vehicle_types', $request->vehicle_types)->get();
        } else {
            $categorydata = VehicleMake::all();
        }

        // dd($categorydata);
        $data['content'] = 'admin.make.manage_make';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }

    public function add_make(Request $request)
    {
        try {
            $vehicleMakeData =  VehicleMake::create([
                'vehicle_types'            => $request->vehicle_types,
                'm_description'            => $request->m_description,
                'status' => $request->status,
            ]);
            if ($request->hasFile('vehicle_logo')) {
                $vehicleMakeData = VehicleMake::find($vehicleMakeData->id);
                $file = $request->file('vehicle_logo');
                $filename = 'vehicle_logo-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/vehicle_make/', $filename);
                $vehicleMakeData->vehicle_logo = $filename;
                $vehicleMakeData->save();
            }
            return redirect('/view-make')->with(array('status' => 'success', 'message' => 'New vehicle make Successfully created!'));
        } catch (\Exception $e) {
            return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }

    public function edit_make($id)
    {
        $editclient = VehicleMake::where('id', $id)->first();
        $data['content'] = 'admin.make.edit_make';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function updateMake(Request $request, $id)
    {
        //dd($request->all());
        try {
            $vehicleData = VehicleMake::find($id);
            $updateData = array(
                "vehicle_types"            => $request->has('vehicle_types') ? $request->vehicle_types : "",
                "m_description"            => $request->has('m_description') ? $request->m_description : "",
                "status"            => $request->has('status') ? $request->status : "",
            );
            $vehicleData->update($updateData);
            if ($request->hasFile('vehicle_logo')) {
                $vehicleMakeData = VehicleMake::find($id);
                $file = $request->file('vehicle_logo');
                $filename = 'vehicle_logo-' . time() . '.' . $file->getClientOriginalExtension();
                $file->move('public/uploads/vehicle_make/', $filename);
                $vehicleMakeData->vehicle_logo = $filename;
                $vehicleMakeData->save();
            }
            return redirect('/view-make')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }

    public function view_model(Request $request)
    {
        if ($request->vehicle_types != '') {
            $categorydata = VehicleModel::where('model_types', $request->vehicle_types)->get();
        } else {
            $categorydata = VehicleModel::all();
        }

        $data['content'] = 'admin.model.manage_model';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }

    public function add_model(Request $request)
    {
        // dd($request->all());

        try {
            $vehicleTypeData =  VehicleModel::create([
                'model_types'           => strip_tags($request->model_types),
                'model_makes'           => strip_tags($request->model_makes),
                "vehicles_model"        => strip_tags($request->vehicles_model),
                "description"           => strip_tags($request->description),
                "no_of_seats"           => $request->no_of_seats,
                "status"                => $request->status,
            ]);

            return redirect('/view-modal')->with(array('status' => 'success', 'message' => 'New vehicle Model Successfully created!'));
        } catch (\Exception $e) {
            // return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
        }
    }
    public function add_document(Request $request)
    {
        $data = array(
            'name' => $request->name,
            'mandatory' => $request->mandatory,
            'expiration_date' => $request->expiration_date,
            'no_required' => $request->no_required,
            'type' => 'user',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('document')->insert($data);
        return redirect('view-document');
    }

    public function view_document(Request $request)
    {
        if ($request->name != '') {
            $categorydata = DB::table('document')->where('name', $request->name)->get();
        } else {
            $categorydata = DB::table('document')->get();
        }

        $data['content'] = 'admin.document.manage_document';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function add_pricing(Request $request)
    {
        //dd($request->all());
        $data = array(
            "service" => $request->service,
            "area" => $request->area,
            "vehicle_type" => $request->vehicle_type,
            "city" => $request->city,
            "priceby" => $request->priceby,
            "baseprice" => $request->baseprice,
            "stop" => $request->stop,
            "servicefee" => $request->servicefee,
            "conviniencefor" => $request->conviniencefor,
            "conviniencefee" => $request->conviniencefee,
            "othercharges" => $request->othercharges,
            "waitingfee" => $request->waitingfee,
            "standard" => $request->standard,
            "discount" => $request->discount,
            "status" => $request->status,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('pricecard')->insert($data);
        return redirect('view-pricing');
    }
    public function view_pricing(Request $request)
    {
        if ($request->name) {
            $categorydata = DB::table('pricecard')
                ->get();
        } else {
            $categorydata = DB::table('pricecard')
                ->get();
        }


        // dd($categorydata);
        $data['content'] = 'admin.pricing.manage_pricing';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function add_ewallet(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
            'user_type'        => $request->user_type,
            'searchtext'   => $request->searchtext,
            'phone'     => $request->phone,
            'payment_method'      => $request->payment_method,
            'receipt_number'    => $request->receipt_number,
            'amount'            => $request->amount,
            'created_at'        => date('Y-m-d H:i:s'),
            'description'       => $request->description
        );
        Session::flash('success', 'Added Successfully..!');
        $insertData = DB::table('ewallet_recharge')->insert($data);
        return back();
    }
    public function view_ewallet()
    {
        $categorydata = DB::table('wallerpackage')->get();
        $data['content'] = 'admin.ewallet.manage_ewallet';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function show_ewallet(Request $request, $id)
    {
        $categorydata = DB::table('wallerpackage')->where('id', $id)->first();
        $data['content'] = 'admin.ewallet.show_ewallet';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }
    public function edit_ewallet($id)
    {
        $editclient =  DB::table('wallerpackage')->where('id', $id)->first();
        //dd($editclient);
        $data['content'] = 'admin.ewallet.edit_ewallet';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function updateEwallet(Request $request, $id)
    {
        $data = array(
            'amount' => $request->amount,
            'status' => $request->status,
            'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Updated successfully..!');
        $insertData = DB::table('wallerpackage')->where('id', $id)->update($data);
        return redirect('view-ewallet');
    }
    public function view_payment()
    {
        $paymentmodeData = DB::table('payment_mode')->get();
        $data['content'] = 'admin.payment.manage_payment';
        return view('layouts.content', compact('data'))->with(['manager' => $paymentmodeData]);
    }
    public function add_standardrules(Request $request)
    {
        $data = array(
            'vehicle_id'            => $request->vehicle_id,
            'service_area_id'       => $request->service_area_id,
            'delivery_type'         => $request->delivery_type,
            'service_type'          => implode(", ", $request->service_type),
            'base_fare'             => $request->base_fare,
            'status'                => 1,
            'created_at'            => date('Y-m-d H:i:s'),
            'updated_at'            => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Created successfully..!');
        $insertData = DB::table('standard_rules')->insert($data);
        return redirect('view-standardrates');
    }
    
    public function update_standardrates(Request $request)
    {
        // dd($id);
        $data = array(
            'vehicle_id'            => $request->vehicle_id,
            'service_area_id'       => $request->service_area_id,
            'delivery_type'         => $request->delivery_type,
            'service_type'          => implode(", ", $request->service_type),
            'base_fare'             => $request->base_fare,
            'status'                => 1
        );
        Session::flash('success', 'Updated successfully..!');
        $insertData = DB::table('standard_rules')->where('id',$request->id)->update($data);
        return back();
    }

    public function view_standardrules()
    {
        $categorydata = DB::table('standard_rules as sr')
            ->join('vehicle_type as vt', 'sr.vehicle_id', '=', 'vt.id')
            ->join('service_area as sa', 'sr.service_area_id', '=', 'sa.id')
            ->select('sr.*', 'vt.v_type', 'sa.service_name', 'sa.area')
            ->get();
        //dd($categorydata);
        $data['content'] = 'admin.standardrules.manage_standardrules';
        return view('layouts.content', compact('data'))->with(['manager' => $categorydata]);
    }

    public function request_posting()
    {
        $categorydata = DB::table('chasout_request')->get();
        $data['content'] = 'admin.ewallet.request_posting';
        return view('layouts.content', compact('data'))->with(['usredata' => $categorydata]);
    }

    public function settlements()
    {
        $categorydata = DB::table('chasout_request')->get();
        $data['content'] = 'admin.ewallet.request_posting';
        return view('layouts.content', compact('data'))->with(['usredata' => $categorydata]);
    }

    public function search_client_bydate(Request $request)
    {
        $from =  date("Y-m-d", strtotime($request->from_date));
        $to   = date("Y-m-d", strtotime($request->end_date));

        if (Session::get('userRole') == 1) {
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->get();
        } elseif (Session::get('userRole') == 2) {
            $client = User::where('users_role', 5)->whereBetween('created_at', [$from, $to])->where('upload_by', Session::get('gorgID'))->get();
        }

        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client]);
    }




    public function edit_model($id)
    {
        $editclient = VehicleModel::find($id);
        // dd($editclient);
        $data['content'] = 'admin.model.edit_model';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function updateModel(Request $request, $id)
    {
        // dd($request->all());
        try {
            $vehicleData = VehicleModel::find($id);
            $updateData = array(
                "model_types"            => $request->has('model_types') ? $request->model_types : "",
                "model_makes"            => $request->has('model_makes') ? $request->model_makes : "",
                "vehicles_model"            => $request->has('vehicles_model') ? $request->vehicles_model : "",
                "no_of_seats"            => $request->has('no_of_seats') ? $request->no_of_seats : "",
                "description"            => $request->has('description') ? strip_tags($request->description) : "",
                "status"            => $request->has('status') ? $request->status : "",
            );
            $vehicleData->update($updateData);

            return redirect('/view-model')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
        } catch (\exception $e) {
            //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
            return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
        }
    }
    public function edit_document($id)
    {
        // $editclient = User::where('id', $id)->first();
        $editclient = DB::table('document')->where('id', $id)->first();
        $data['content'] = 'admin.document.edit_document';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function update_document(Request $request, $id)
    {
        // dd($id);
        $data = array(
            'name' => $request->name,
            'mandatory' => $request->mandatory,
            'expiration_date' => $request->expiration_date,
            'no_required' => $request->no_required,
            'type' => 'user',
            'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Updated successfully..!');
        $insertData = DB::table('document')->where('id', $id)->update($data);
        return redirect('view-document');
    }
    
    public function edit_pricing($id)
    {
        $editclient = DB::table('pricecard')->where('id', $id)->first();
        // dd($editclient);
        $data['content'] = 'admin.pricing.edit_pricing';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function updatePricing(Request $request, $id)
    {
        $data = array(
            "service" => $request->service,
            "area" => $request->area,
            "vehicle_type" => $request->vehicle_type,
            "city" => $request->city,
            "priceby" => $request->priceby,
            "baseprice" => $request->baseprice,
            "stop" => $request->stop,
            "servicefee" => $request->servicefee,
            "conviniencefor" => $request->conviniencefor,
            "conviniencefee" => $request->conviniencefee,
            "othercharges" => $request->othercharges,
            "waitingfee" => $request->waitingfee,
            "standard" => $request->standard,
            "discount" => $request->discount,
            "status" => $request->status,
            'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('pricecard')->where('id', $id)->update($data);
        return redirect('view-pricing');
    }

    public function edit_payment($id)
    {
        $editclient = DB::table('payment_mode')->where('id', $id)->first();
        $data['content'] = 'admin.payment.edit_payment';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }
    public function add_payment(Request $request)
    {
        $data = array(
            "payment_method" => $request->payment_method,
            "status" => $request->status,
            // 'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('payment_mode')->insert($data);
        return redirect('view-payment');
    }
    public function update_payment(Request $request, $id)
    {
        $data = array(
            "payment_method" => $request->payment_method,
            "status" => $request->status,
            'updated_at' => date('Y-m-d H:i:s'),
        );
        Session::flash('success', 'updated successfully..!');
        $insertData = DB::table('payment_mode')->where('id', $id)->update($data);
        return redirect('view-payment');
    }
    public function edit_standardrules($id)
    {
        $editclient = User::where('id', $id)->first();
        $editclient = DB::table('standard_rules as sr')
            ->join('vehicle_type as vt', 'sr.vehicle_id', '=', 'vt.id')
            ->join('service_area as sa', 'sr.service_area_id', '=', 'sa.id')
            ->select('sr.*', 'vt.v_type', 'sa.service_name', 'sa.area')
            ->where('sr.id',$id)
            ->first();
        $data['content'] = 'admin.standardrules.edit_standardrules';
        return view('layouts.content', compact('data'))->with(['editclient' => $editclient]);
    }

    public function filter_client(Request $request)
    {

        if ($request->employee_id != '') {
            $id = $request->employee_id ?? '';
        } elseif ($request->whitelabel_id != '') {
            $id = $request->whitelabel_id ?? '';
        } elseif ($request->manager_id != '') {
            $id = $request->manager_id ?? '';
        }
        $client = User::where('users_role', 5)->where('upload_by', $request->id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid' => $request->id]);
    }

    public function client_view_data($id)
    {
        $viewclient = User::where('id', $id)->first();
        $data['content'] = 'admin.client.view_client';
        return view('layouts.content', compact('data'))->with(['viewclient' => $viewclient]);
    }

    public function search_status_client(Request $request)
    {
        $client = User::where('users_role', 5)->where('status', $request->status_id)->get();
        $data['content'] = 'admin.client.manage_client';
        return view('layouts.content', compact('data'))->with(['client' => $client, 'filterid' => $request->id]);
    }

    public function client_password_change(Request $request)
    {
        $clientdetails = DB::table('users')->where('id', session::get('gorgID'))->first();
        $data = array(
            'password' => Hash::make($request->newpassword),
        );

        if ($clientdetails != '') {
            $updateData = DB::table('users')->where('id', session::get('gorgID'))->update($data);
            return redirect()->back()->with('message', 'IT WORKS!');
        }
    }
}
