<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;

class OrderController extends Controller
{
    public function view_all_orders(){
    	$orders = DB::table('issafe')->orderBy('id', 'Desc')->get();

    	$data['content'] = 'admin.order_details.manage_orders';
    	return view('layouts.content', compact('data'))->with(['orders' => $orders]);
    }

    public function view_order_details($id){
    	$orderDetail = DB::table('order_manage')->where('id',$id)->first();

    	$data['content'] = 'admin.order_details.view_order_details';
    	return view('layouts.content', compact('data'))->with(['orderDetail' => $orderDetail]);
    }
    public function admin_moveto_marketplace($id)
    {
        $issafe = DB::table('issafe')->where('id', $id)->first();
        $data = array(
            'watch_id' => $issafe->watch_id,  
            'user_id' => $issafe->user_id,
        );

        Session::flash('success','Moved successfully..!');
        $insertData = DB::table('marketplace')->insert($data);
        $delete = DB::table('issafe')->where('id', $id)->delete();
        return back();
    }

}
