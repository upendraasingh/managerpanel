<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use App\Country;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;
use URL;

class ManagerController extends Controller
{
  public function __construct()
  {
    //$this->middleware('auth');
    //$this->middleware('role');
  }
  
  public function forgotpasswordemail(Request $request)
  {
        $messages = '<a href="{{URL::to("/")}}/forgotpasswordemail">Click on this Link to Change Password</a>';
        mail("as6017651@gmail.com","Change admin password link","Click on this link to change password:-".URL::to('/')."/forgotpassword");
        
        Session::flash('success', 'We have sent Change Password link on Registered Email');
        return back();
  }
  
    public function forgotpassword(Request $request)
    {
        
    }

  public function filter_manager(Request $request)
  {
    try {
        $manager = DB::table('users')->where('users_role', 3)->where('upload_by', $request->whitelabel_id)->get();
        $data['content'] = 'admin.manager.manage_manager';
        return view('layouts.content', compact('data'))->with(['manager' => $manager, 'whitelabel_id' => $request->whitelabel_id]);
    } catch (Throwable $e) {
        report($e);
return false;
    }
  }

  public function loginmanager(Request $request)
  {

    $rules = array(
      'email'    => 'required|email', // make sure the email is an actual email
      'password' => 'required|min:6' // password can only be alphanumeric and has to be greater than 3 characters
    );

    // run the validation rules on the inputs from the form
    $validator = Validator::make(Input::all(), $rules);

    // if the validator fails, redirect back to the form
    if ($validator->fails()) {
      return back()->withErrors($validator)->withInput();
      die;
    } else {
      //echo "login success";die;
      // create our user data for the authentication
      $userdata = array(
        'email'     => Input::get('email'),
        'password'  => Input::get('password')
      );
      // attempt to do the login
      if (Auth::attempt($userdata)) {
        //echo 'SUCCESS!';die;
        return redirect('managerdashboard');
        /*
              $data['content'] = 'manager.managerdashboard';
              return view('manager_layouts.content', compact('data'));
              */
      } else {
        // validation not successful, send back to form
        return back()->with(array('status' => 'error', 'message' =>  'Wrong Credentials.'));
        die;
      }
    }
  }

  public function add_manager(Request $request)
  {

    /*  if ($files = $request->image) {
      $destinationPath = public_path('/profile_image/');
      $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
      $path =  $files->move($destinationPath, $profileImage);
      $image = $insert['photo'] = "$profileImage";
    }
    */
    $data = array(
      'name' => $request->name,
      'upload_by' => $uploadBy,
      'users_role' => 3,
      'email' => $request->email,
      'phone' => $request->phone,
      'address' => $request->address,
      'country_id' => $request->country_id,
      'dob' => $request->dob,
      'gender' => $request->gender,
      'password' => Hash::make($request->password),
      'profile_image' =>  $image,
      'created_at' => date('Y-m-d H:i:s'),
    );

    Session::flash('success', 'Inserted successfully..!');
    $insertData = DB::table('users')->insert($data);
    return redirect('view-countrym');
  }

  public function view_country(Request $request)
  {
    $manager = DB::table('country')->get();
    if ($request->country_name != "") {
      $manager = DB::table('country')->where('country_name', $request->country_name)->get();
    }
    $data['content'] = 'admin.country.manage_country';
    return view('layouts.content', compact('data'))->with(['manager' => $manager]);
  }
  public function addCountries(Request $request)
  {
    // dd($request->all());
    $validator = Validator::make($request->all(), [
      'country_name'          => 'required|max:255|min:2|unique:country',
      //'nicename'              => 'required|max:255|min:2|unique:country',
      // 'iso'                   =>  'required',
      // 'iso3'                  =>  'required',
      // 'numcode'               =>  'required',
      // 'phonecode'             =>  'required',
    ]);
    if ($validator->fails()) {
      return back()->withErrors($validator)->withInput();
    }
    try {
      $addCountriesData =  Country::create([
        'country_name'        => $request->country_name,
        'nicename'            => $request->country_name,
        'currency'            => $request->currency,
        'isd_code'            => $request->isd_code,
        'currency_symbol'     => $request->currency_symbol,
        'distance_unit'       => $request->distance_unit,
        'default_language'    => $request->default_language,
        'min_number_digits'   => $request->min_number_digits,
        'max_number_digits'   => $request->max_number_digits,
        'online_trans_code'   => $request->online_trans_code,
        'sequence'            => $request->sequence,
        'iso'                 => '',
        'iso3'                => '',
        'numcode'             => '',
        'phonecode'           => $request->isd_code,
        'status'              => $request->status,
      ]);
      return redirect('/view-country')->with(array('status' => 'success', 'message' => 'New Country Successfully created!'));
    } catch (\Exception $e) {
      return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
      return back()->with(array('status' => 'danger', 'message' =>  'Something went wrong. Please try again later.'));
    }
  }

  public function edit_manager($id)
  {
    $editmanager = DB::table('country')->where('id', $id)->first();
    $data['content'] = 'admin.country.edit_country';
    return view('layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
  }
  public function update_country(Request $request, $id)
  {
    //dd($request->all());
    try {
      $countryData = Country::find($id);
      $updateData = array(
        "country_name"     => $request->has('country_name') ? $request->country_name : "",
        "isd_code"     => $request->has('isd_code') ? $request->isd_code : "",
        "currency"     => $request->has('currency') ? $request->currency : "",
        "currency_symbol"     => $request->has('currency_symbol') ? $request->currency_symbol : "",
        "distance_unit"     => $request->has('distance_unit') ? $request->distance_unit : "",
        "default_language"     => $request->has('default_language') ? $request->default_language : "",
        "min_number_digits"     => $request->has('min_number_digits') ? $request->min_number_digits : "",
        "max_number_digits"     => $request->has('max_number_digits') ? $request->max_number_digits : "",
        "sequence"     => $request->has('sequence') ? $request->sequence : "",
        "status"     => $request->has('status') ? $request->status : "",
        
      );
      $countryData->update($updateData);
      return redirect('/view-country')->with(array('status' => 'success', 'message' => 'Update record successfully.'));
    } catch (\exception $e) {
      //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
      return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
    }
  }
  
    public function forgotpasswordupdate(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'password' => 'required|confirmed|min:8',
        ]);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        $data = array('password' => Hash::make($request->password));

        User::where('id', '1')->update($data);
        Session::flash('success', 'Password Changed successfully');
        return back();   
    }
    public function show_country(Request $request, $id)
    {
        $editmanager = DB::table('country')->where('id', $id)->first();
        $data['content'] = 'admin.country.show_country';
        return view('layouts.content', compact('data'))->with(['editmanager' => $editmanager]);
    }
  public function deleteCountry($id)
  {
    try {
      $countryData = Country::find($id);
      Country::find($id)->delete();
      return redirect('/view-country')->with(array('status' => 'success', 'message' => 'Delete record successfully.'));
    } catch (\exception $e) {
      //return back()->with(array('status' => 'danger', 'message' =>  $e->getMessage()));
      return back()->with(array('status' => 'danger', 'message' => 'Some thing went wrong! Please try again later.'));
    }
  }
}
