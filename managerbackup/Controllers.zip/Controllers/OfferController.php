<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;
use URL;

class OfferController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }

    public function add_offer(Request $request)
    {
        /*dd($request->all());*/
        if($request->offertype=='amount'){
            $data = array(
                'watch_id' => $request->watch_idform,  
                'client_id' => $request->client_idform,  
                'country' => $request->country, 
                'modal' => $request->modalform, 
                'offertype' => $request->offertype, 
                'offer' => $request->offer,
                'finalprice' => $request->offer, 
                'realprice'  => $request->priceform,
            );
        }   else{
            $data = array(
                'watch_id' => $request->watch_idform,  
                'client_id' => $request->client_idform,  
                'country' => $request->country, 
                'modal' => $request->modalform, 
                'offertype' => $request->offertype, 
                'offer' => $request->offer,
                'finalprice' => $request->calculatedprice, 
                'realprice' => $request->priceform,
            );
        }
        

        Session::flash('success','Inserted successfully..!');
        $insertData = DB::table('offer')->insert($data);
        return redirect('view-marketplace');
    }
  
    public function view_offer(Request $request)
    {
        $marketplace = DB::table('marketplace')->get();
          

        $data['content'] = 'admin.offer.manage_offer';
        return view('layouts.content', compact('data'))->with(['marketplace' => $marketplace ]);
    }

    public function delete_offer(Request $request,$id)
    {
        $delete = DB::table('offer')->where('id', $id)->delete();
        Session::flash('error','Offer delete successfully..!');
        return back();
    }

    public function edit_offer($id){
        $editoffer = DB::table('offer')->where('id', $id)->first();
        $data['content'] = 'admin.offer.edit_offer';
        return view('layouts.content', compact('data'))->with(['editoffer' => $editoffer ]);
    }

    public function filter_offer(Request $request){
        /*dd($request->id);*/
        $offer = DB::table('offer')->where('type', $request->id)->get();
        $data['content'] = 'admin.offer.manage_offer';
        return view('layouts.content', compact('data'))->with(['offer' => $offer, 'filterid'=>$request->id ]);
        
    }
  
    public function offer_view_data($id)
    {
        $viewclient = DB::table('offer')->where('id',$id)->first();

        $data['content'] = 'admin.offer.view_offer';
        return view('layouts.content', compact('data'))->with(['editoffer' => $viewclient ]);
    }

    public function logout()
    {
        $logged_in = DB::table('users')->where('id', Auth::id())->update(['logged_in'=> 0]); 
        if(session::get('userRole') == 1){
            Auth::logout();
            Session::flash('success','Logout successfully..!');
            return redirect('login');
        }if(session::get('userRole') == 2){
            Auth::logout();
            return redirect('login');
        }if(session::get('userRole') == 3){
            Auth::logout();
            return redirect('login');
        }if(session::get('userRole') == 4){
            Auth::logout();
            return redirect('login');
        }if(session::get('userRole') == 5){
            Auth::logout();
            return redirect('web-login');
        }
    }

    public function offer_password_change(Request $request)
    {
        $clientdetails = DB::table('users')->where('id', session::get('gorgID'))->first();
        $data = array(
            'password' => Hash::make($request->newpassword),
        );

        if($clientdetails!=''){
            $updateData = DB::table('users')->where('id', session::get('gorgID'))->update($data);
            return redirect()->back()->with('message', 'IT WORKS!');
        } 
    }
    public function offer_update_profile(Request $request)
    {
        /*dd($request->all());*/
        $data = array(
            'name' => $request->username, 
            'phone' => $request->mobile, 
            'address' => $request->address, 
            'country_id' => $request->country,
            'city_id' => $request->city,
        );

        $insertData = DB::table('users')->where('id', $request->userid)->update($data);

        return redirect()->back()->with('message', 'Profile Updated successfully.');
    }

    public function get_marketplace_offer(Request $request,$id)
    {   ?>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>    
                            <th>Model</th>
                            <th>ID N0.</th>
                            <th>Brand</th>                           
                            <th>Country</th>                            
                            <th>Buy Price</th>  
                            <th>Offer</th>                           
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>  
                        <?php
                            $frontoffer = DB::table('offer')->where('watch_id',$id)->get();
                        
                        foreach($frontoffer as $fr){ 
                                $product = DB::table('product')->where('id',$fr->watch_id)->first();
                                $brand = DB::table('brand')->where('id',$product->brand_id)->first();
                            ?>
                            <tr class="gradeX" id="hidetr<?php echo $fr->id;?>">
                                <td><?php echo $product->model_name;?></td>
                                <td><?php echo $product->id_no;?></td>
                                <td><?php echo $brand->brand_name;?></td> 
                                <td><?php echo $fr->country;?></td>                           
                                <td><?php echo $product->price;?></td>  
                                <td><?php echo $fr->finalprice;?></td>                               
                                <td class="actions">
                                    <a href="javascript:void(0);" class="btn btn-primary" 
                                    onclick="updateStatus('<?php echo $fr->id;?>','1')" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View">Accept</a><br>                                    
                                    <a href="javascript:void(0);" class="btn btn-primary"  onclick="updateStatus('<?php echo $fr->id;?>','0')" data-toggle="tooltip" data-modal="modal-12" data-placement="top" title="" data-original-title="View">Refuse</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php
    }

    public function view_watch_offer($id)
    {
        $offer = DB::table('offer')->where('watch_id', $id)->get();
        $data['content'] = 'admin.offer.view_watch_offer';
        return view('layouts.content', compact('data'))->with(['offer' => $offer]);
    }

    public function update_status(Request $request)
    {        
        $permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';            
        $number =  'TRN'.substr(str_shuffle($permitted_chars), 0, 6);

        $getData = DB::table('offer')->where('id', $request->id)->first();
        $insertdata =   array(
                            'offer_id' => $request->id,
                            'user_id'  => Session::get('gorgID'),
                            'status'   => $request->status,
                        );
        $updatedata =   array(
                            'status' => $request->status,
                        );
        $getclient = DB::table('wallet_transaction')->where('client_id', session::get('gorgID'))->where('status','0')->orderBy('id', 'Desc')->first();
        
        if($getclient->available_balance){

            $total_balance = $getclient->available_balance - $getData->finalprice;
            
            $data = array(
                'trans_id' => $number,
                'client_id' => Session::get('gorgID'), 
                'withdrawal' => $getData->finalprice, 
                'status' => 0, 
                'cr_dr_status' => 0, 
                'available_balance' => $total_balance, 
                'date' => date('Y-m-d H:i:s'),
                'payment_mode' => 'watch', 
            );  

            $insertData = DB::table('wallet_transaction')->insert($data);
        }

        $insert     = DB::table('offeraction')->insert($insertdata);
        $insertData = DB::table('offer')->where('id', $request->status)->update($updatedata);
        $delete     = DB::table('marketplace')->where('watch_id', $getData->watch_id)->where('user_id', Session::get('gorgID'))->delete();
        return $request->status;

    }
}

?>