<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Session;
use Response;
use App\Category;
use App\Country;
use App\City;
use App\Brand;
use App\User;
use DB;
use Hash;
use Auth;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }

    public function change_password(Request $request)
    {
        $data = array('password' => Hash::make($request->password));

        User::where('id', $request->editId)->update($data);
        Session::flash('success', 'Password Changed successfully');
        return back();
    }
    public function change_password_client(Request $request)
    {
        $data = array('password' => Hash::make($request->password), 'view_password' => $request->password);

        User::where('id', $request->editId)->update($data);
        Session::flash('success', 'Password Changed successfully');
        return back();
    }
    public function profile(Request $request)
    {
        $usredata = Country::get();
        $tds = $usredata->toArray();
        $usre = City::get();
        $citys = $usre->toArray();

        return view('web.dashboard.myaccount.myaccount', compact('tds', 'citys'));
    }
    public function UpdateProfile(Request $request)
    {
        if ($request->password) {
            $this->validate($request, [
                'password'     => 'required',
                'new_password'     => 'required|min:8',
            ]);

            $data = $request->all();

            if (!\Hash::check($data['password'], auth()->user()->password)) {
                Session::flash('error', 'Please Enter valid Current password');
                return back();
            } else {

                if ($request->u_ids != '') {
                    $udata['name'] = $request->name;
                    $udata['password'] = Hash::make($request->new_password);
                    User::where('id', $request->u_ids)->update($udata);
                }
                Session::flash('success', 'Profile updated successfully');
                return back();
            }
        } else {
            $data = $request->all();
            $udata['name'] = $request->name;
            User::where('id', $request->u_ids)->update($udata);
            Session::flash('success', 'Profile updated successfully');
            return back();
        }
    }

    public function UserProfile(Request $request)
    {
        $companydata = User::where('id', Session::get('gorgID'))->first();
        $profileData = Auth()->user();

        $data['content'] = 'admin.user.user-profile';
        return view('layouts.content', compact('data'))->with(['companydata' => $companydata]);
    }

    public function Dashboard(Request $request)
    {
        $userRole = Session::get('userRole');
        $id = Session::get('gorgID');
        $OrgData = DB::table('users')->where('id', $id)->first();

        if ($userRole == '1') {
            $usredata = DB::table('users')->where('users_role', 1)->where('id','!=', 1)->count();
            $Activedriver = DB::table('driveuser')->where('isactive', 1)->count();
            $manager = DB::table('users')->where('users_role', 3)->count();
            $employee = DB::table('users')->where('users_role', 4)->count();
            $client = DB::table('users')->where('users_role', 5)->count();
            $lead = DB::table('leads')->count();
            $transaction = DB::table('wallet_transaction')->count();
            $product = DB::table('product')->count();
            $brand = DB::table('brand')->count();

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'Activedriver' => $Activedriver, 'manager' => $manager, 'employee' => $employee, 'client' => $client, 'lead' => $lead, 'transaction' => $transaction, 'product' => $product, 'brand' => $brand]);
        } elseif ($userRole == '2') {
            $usredata = DB::table('users')->count();
            $manager = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 3)->count();
            $employee = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 4)->count();
            $client = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 5)->count();
            $lead = DB::table('leads')->where('upload_by', Session::get('gorgID'))->count();
            $product = DB::table('product')->where('upload_by', Session::get('gorgID'))->count();

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'manager' => $manager, 'employee' => $employee, 'client' => $client, 'lead' => $lead, 'product' => $product]);
        } elseif ($userRole == '3') {
            $usredata = DB::table('users')->count();
            $employee = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 4)->count();
            $client = DB::table('users')->where('upload_by', Session::get('gorgID'))->where('users_role', 5)->count();
            $lead = DB::table('leads')->where('upload_by', Session::get('gorgID'))->count();

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'employee' => $employee, 'client' => $client, 'lead' => $lead]);
        } elseif ($userRole == '4') {
            $usredata = DB::table('users')->count();
            $lead = DB::table('leads')->where('upload_by', Session::get('gorgID'))->count();

            $data['content'] = 'admin.home';
            return view('layouts.content', compact('data'))->with(['usredata' => $usredata, 'lead' => $lead]);
        } elseif ($userRole == '5') {
            $usredata = DB::table('users')->count();
            return redirect('web-dashboard');
        }
    }


    public function managerDashboard(Request $request)
    {
        $userRole = Session::get('userRole');
        $id = Session::get('gorgID');
        $OrgData = DB::table('users')->where('id', $id)->first();

        if ($userRole == '1') {
            $usredata = DB::table('users')->where('users_role', 2)->count();
            $whitelabel = DB::table('users')->where('users_role', 2)->count();
            $manager = DB::table('users')->where('users_role', 3)->count();
            $employee = DB::table('users')->where('users_role', 4)->count();
            $client = DB::table('users')->where('users_role', 5)->count();
            $lead = DB::table('leads')->count();
            $transaction = DB::table('wallet_transaction')->count();
            $product = DB::table('product')->count();
            $brand = DB::table('brand')->count();

            $data['content'] = 'manager.home';
            return view('manager_layouts.content', compact('data'))->with(['usredata' => $usredata, 'whitelabel' => $whitelabel, 'manager' => $manager, 'employee' => $employee, 'client' => $client, 'lead' => $lead, 'transaction' => $transaction, 'product' => $product, 'brand' => $brand]);
        } 
    }

    public function index()
    {
        Session::flash('success', 'login successfully..!');
        return Redirect::action('HomeController@Dashboard');
    }

    /* User routr Start */
    public function total_users(Request $request)
    {
        $total_users = User::all();
        $data['content'] = 'admin.user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function user_view()
    {
        $usredata = User::where('users_role', 2)->get();

        $data['content'] = 'admin.user.user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }

    public function customer_user()
    {
        //$usredata = User::where('users_role', 2)->get();
        $usredata = DB::table('users')
            ->where('id', '!=', '1')->orderby('id','desc')
            ->get();

        $data['content'] = 'admin.user.customer_user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function show_customer_user(Request $request, $id)
    {
        $usredata = User::find($id);
        // dd($usredata);
        $data['content'] = 'admin.user.show_customer_user';
        return view('layouts.content', compact('data'))->with(['editdata' => $usredata]);
    }
    public function driver_user()
    {
        // $usredata = User::where('users_role', 2)->get();
        $usredata = DB::table('driveuser')->get();
        $usredata = DB::table('driveuser as du')
            ->join('drivepersonaldoc as dd', 'du.id', '=', 'dd.driver_id')
            ->join('driver_vehicle as dv', 'du.id', '=', 'dv.driver_id')
            ->select(
                'du.*',
                'dd.driver_id',
                'dd.document_type',
                'dd.docsExpire',
                'dd.docs_status',
                'dd.document_file',
                'dd.frontlicensephoto',
                'dv.vehicle_type',
                'dv.vehicle_image',
                'dv.vehicle_plate_image',
                'dv.vehicle_ser_type',
                'dv.veh_doc_type',
                'dv.veh_doc_expire',
                'dv.veh_doc_image',
                'dv.veh_doc_status',
                'dv.veh_doc_upload_at'
            )
            ->get();
        $data['content'] = 'admin.user.driver_user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function food_user()
    {
        $usredata = User::where('users_role', 2)->get();
        $data['content'] = 'admin.user.food_user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function shop_user()
    {
        $usredata = User::where('users_role', 2)->get();

        $data['content'] = 'admin.user.shop_user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function operator_user()
    {
        $usredata = User::where('users_role', 2)->get();

        $data['content'] = 'admin.user.operator_user';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function view_adminuser()
    {
        $insertData = DB::table('admin_user')->get();
        $data['content'] = 'admin.systemuser.view_adminuser';
        return view('layouts.content', compact('data'))->with(['usredata' => $insertData]);
    }
    public function view_type()
    {
        $usredata = DB::table('services')->get();
        $data['content'] = 'admin.systemuser.view_type';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function view_drawer()
    {
        $usredata = DB::table('drawer')->get();
        $data['content'] = 'admin.systemuser.view_drawer';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function general_setting()
    {
        $usredata = User::where('users_role', 2)->get();
        $data['content'] = 'admin.systemuser.general_setting';
        return view('layouts.content', compact('data'))->with(['editdata' => $usredata]);
    }
    public function edit_adminuser($id)
    {
        $editdata = DB::table('admin_user')->where('id',$id)->first();
        $data['content'] = 'admin.systemuser.edit_adminuser';
        return view('layouts.content', compact('data'))->with(['editdata' => $editdata]);
    }
    public function edit_type($id)
    {
        $editdata = DB::table('services')->where('id',$id)->first();
        $data['content'] = 'admin.systemuser.edit_type';
        return view('layouts.content', compact('data'))->with(['editdata' => $editdata]);
    }
    public function edit_drawer($id)
    {
        $editdata = DB::table('drawer')->where('id',$id)->first();
        $data['content'] = 'admin.systemuser.edit_drawer';
        return view('layouts.content', compact('data'))->with(['editdata' => $editdata]);
    }
    public function view_role()
    {
        $usredata = User::where('users_role', 2)->get();
        $data['content'] = 'admin.systemuser.view_role';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function view_cancellation()
    {
        $usredata = DB::table('order_cancel_reason')->get();
        $data['content'] = 'admin.systemuser.view_cancelreason';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function edit_cancellation($id)
    {
        $usredata = DB::table('order_cancel_reason')->where('id',$id)->first();
        $data['content'] = 'admin.systemuser.edit_cancelreason';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function order_request()
    {
        $usredata = DB::table('orderrequestconfig')->get();
        $data['content'] = 'admin.systemuser.order_configuration';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function driver_configuration()
    {
        $usredata = User::where('users_role', 2)->get();
        $data['content'] = 'admin.systemuser.driver_configuration';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function email_configuration()
    {
        $usredata = User::where('users_role', 2)->get();
        $data['content'] = 'admin.systemuser.email_configuration';
        return view('layouts.content', compact('data'))->with(['usredata' => $usredata]);
    }
    public function edit_role($id)
    {
        $editdata = User::where('id', $id)->first();
        $data['content'] = 'admin.systemuser.edit_role';
        return view('layouts.content', compact('data'))->with(['editdata' => $editdata]);
    }
    
    public function save_general_setting(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        if ($files = $request->logo) {
            $destinationPath = public_path('/settings/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $logo = $insert['photo'] = "$profileImage";
        }
        $data = array(
                    'logo' => $logo,
                    'email' => $request->email,
                    'phone' => $request->phone,
                    'android_maintenance_user' => $request->android_maintenance_user,
                    'android_user_version' => $request->android_user_version,
                    'android_user_update' => $request->android_user_update,
                    'android_maintenance_driver' => $request->android_maintenance_driver,
                    'android_driver_version' => $request->android_driver_version,
                    'android_driver_update' => $request->android_driver_update,
                    'ios_maintenance_user' => $request->ios_maintenance_user,
                    'ios_user_version' => $request->ios_user_version,
                    'ios_user_update' => $request->ios_user_update,
                    'ios_maintenance_driver' => $request->ios_maintenance_driver,
                    'ios_driver_version' => $request->ios_driver_version,
                    'ios_driver_update' => $request->ios_driver_update,
                    'user_walletone' => $request->user_walletone,
                    'user_wallettwo' => $request->user_wallettwo,
                    'user_walletthree' => $request->user_walletthree,
                    'driver_walletone' => $request->driver_walletone,
                    'driver_wallettwo' => $request->driver_wallettwo,
                    'driver_walletthree' => $request->driver_walletthree,
                    'remind_for_doc' => $request->remind_for_doc,
                    'fare_policy_text' => $request->fare_policy_text,
                    'referral_value' => $request->referral_value,
                    'created_at' => date('Y-m-d H:i:s')
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('general_setting')->insert($data);
        return back();
    }
    
    public function add_servicetype(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        if ($files = $request->icon) {
            $destinationPath = public_path('/settings/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $icon = $insert['photo'] = "$profileImage";
        }
        $data = array(
                    'name' => $request->name,
                    'type' => $request->type,
                    'icon' => $icon,
                    'color' => $request->color,
                    'created_at' => date('Y-m-d H:i:s')
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('services')->insert($data);
        return back();
    }
    
    public function add_loginapi(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
                    'ios_consumer_url' => $request->ios_consumer_url,
                    'adroid_consumer_url' => $request->adroid_consumer_url,
                    'ios_driver_url' => $request->ios_driver_url,
                    'created_at' => date('Y-m-d H:i:s')
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('app_url')->insert($data);
        return back();
    }
    
    public function add_appurl(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
                    'ios_consumer_url' => $request->ios_consumer_url,
                    'adroid_consumer_url' => $request->adroid_consumer_url,
                    'ios_driver_url' => $request->ios_driver_url,
                    'android_driver_url' => $request->android_driver_url,
                    'android_merchant_url' => $request->android_merchant_url,
                    'android_manager_url' => $request->android_manager_url,
                    'website_url' => $request->website_url,
                    'created_at' => date('Y-m-d H:i:s')
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('app_url')->insert($data);
        return back();
    }
    
    public function save_order_request(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
                    'user_request_timeout' => $request->user_request_timeout,
                    'restaurant_radius' => $request->restaurant_radius,
                    'driver_radius' => $request->driver_radius,
                    'distance_radius_for_ridenow' => $request->distance_radius_for_ridenow,
                    'ridenowrequest_noof_driver' => $request->ridenowrequest_noof_driver,
                    'ridenowdrop_location' => $request->ridenowdrop_location,
                    'ridelater_now_request' => $request->ridelater_now_request,
                    'ridelater_time' => $request->ridelater_time,
                    'distanceradius_forridelater' => $request->distanceradius_forridelater,
                    'droplater_location' => $request->droplater_location,
                    'ridelaterrequest_noof_driver' => $request->ridelaterrequest_noof_driver,
                    'sheduled_starttime' => $request->sheduled_starttime,
                    'created_at' => date('Y-m-d H:i:s')
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('orderrequestconfig')->insert($data);
        return back();
    }
    
    public function add_adminusers(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        $data = array(
                    'name' => $request->name,
                    'phone' => $request->phone,
                    'address' => $request->address,
                    'password' => $request->password,
                    'admin_type' => $request->admin_type,
                    'area_list' => $request->area_list,
                    'role' => $request->role,
                    'created_at' => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('admin_user')->insert($data);
        return back();
    }
    
    public function add_driverfiguration(Request $request)
    {
        $data = array(
                    'payment_to' => $request->payment_to,
                    'verify' => $request->verify,
                    'time' => $request->time,
                    'created_at' => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('driverconfiguration')->insert($data);
        return back();
    }
    
    public function add_emailconfig(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        if ($files = $request->emailreceipt) {
            $destinationPath = public_path('/emailconfig/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $emailreceipt = $insert['photo'] = "$profileImage";
        }
        if ($files = $request->image) {
            $destinationPath = public_path('/emailconfig/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $image = $insert['photo'] = "$profileImage";
        }
        if ($files = $request->logo) {
            $destinationPath = public_path('/emailconfig/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $logo = $insert['photo'] = "$profileImage";
        }
        $data = array(
                    'hostname'    => $request->hostname,
                    'portnumber'  => $request->portnumber,
                    'username'    => $request->username,
                    'password'    => $request->password,
                    'encryption'  => $request->encryption,
                    'driver'      => $request->driver,
                    'heading'     => $request->heading,
                    'subheading'  => $request->subheading,
                    'textmessage' => $request->textmessage,
                    'facebook'    => $request->facebook,
                    'twitter'     => $request->twitter,
                    'instagram'   => $request->instagram,
                    'linkedin'    => $request->linkedin,
                    'emailreceipt'=> @$emailreceipt,
                    'image'       => @$image,
                    'logo'        => @$logo,
                    'created_at'  => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('emailconfiguration')->insert($data);
        return back();
    }

    public function addorder_requestcon(Request $request)
    {
        echo "<pre>";print_r($request->all());die;
        $data = array(
                    'hostname'    => $request->hostname,
                    'portnumber'  => $request->portnumber,
                    'username'    => $request->username,
                    'password'    => $request->password,
                    'encryption'  => $request->encryption,
                    'driver'      => $request->driver,
                    'heading'     => $request->heading,
                    'subheading'  => $request->subheading,
                    'textmessage' => $request->textmessage,
                    'facebook'    => $request->facebook,
                    'twitter'     => $request->twitter,
                    'instagram'   => $request->instagram,
                    'linkedin'    => $request->linkedin,
                    'emailreceipt'=> @$emailreceipt,
                    'image'       => @$image,
                    'logo'        => @$logo,
                    'created_at'  => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('emailconfiguration')->insert($data);
        return back();
    }
    
    public function add_drawer(Request $request)
    {
        //echo "<pre>";print_r($request->all());die;
        if ($files = $request->icon) {
            $destinationPath = public_path('/settings/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $icon = $insert['photo'] = "$profileImage";
        }
        $data = array(
                    'name' => $request->name,
                    'description' => $request->description,
                    'icon' => $icon,
                    'sequence' => $request->sequence,
                    'created_at' => date('Y-m-d H:i:s')
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('drawer')->insert($data);
        return back();
    }
    
    public function update_servicetype(Request $request)
    {
        if ($files = $request->icon) {
            $destinationPath = public_path('/settings/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $icon = $insert['photo'] = "$profileImage";
        }
            $data = array(
                'name' => $request->name,
                'icon' => $icon,
                'color' => $request->color,
                'type' => $request->type
            );
        
        
            Session::flash('success', 'Updated successfully..!');
            $updateData = DB::table('services')->where('id', $request->id)->update($data);
            return back();
            
    }

    public function user_edit($id)
    {
        $editdata = User::where('id', $id)->first();
        $data['content'] = 'admin.user.edit_user';
        return view('layouts.content', compact('data'))->with(['editdata' => $editdata]);
    }
    public function view_user($id)
    {
        $editdata = User::where('id', $id)->first();
        $data['content'] = 'admin.user.view_user';
        return view('layouts.content', compact('data'))->with(['editdata' => $editdata]);
    }
    public function user_delete($id)
    {
        $customerdata_delete = User::where('id', $id)->delete();
        $statusnull = User::where('upload_by', $id)->get(['id']); /* Get manager lavel Data*/

        foreach ($statusnull as $key => $value) {
            $deletecustomer = User::where('upload_by', $id)->delete();
            $customerdata = User::where('upload_by', $value->id)->get();
            $product = DB::table('product')->where('upload_by', $id)->get();

            /*print_r($product); die;*/

            foreach ($customerdata as $key => $value2) {
                $deletecustomer = User::where('upload_by', $value->id)->delete();
            }

            foreach ($product as $key => $value3) {
                $productdelete = DB::table('product')->where('upload_by', $id)->delete();
            }
        }

        Session::flash('error', 'Delete successfully.!');
        return back();
    }
    /* User routr End */

    /* Country section Start */
    public function view_countries()
    {
        $countrydata = DB::table('countries')->get();

        $data['content'] = 'admin.countries.manage_country';
        return view('layouts.content', compact('data'))->with(['countrydata' => $countrydata]);
    }
    public function consumer_support()
    {
        $countrydata = DB::table('consumer_support')->get();
        $data['content'] = 'admin.support.customer_support';
        return view('layouts.content', compact('data'))->with(['manager' => $countrydata]);
    }
    public function driver_support()
    {
        $countrydata = DB::table('driver_support')->get();

        $data['content'] = 'admin.support.driver_support';
        return view('layouts.content', compact('data'))->with(['manager' => $countrydata]);
    }
    public function merchant_support()
    {
        $countrydata = DB::table('merchant_support')->get();

        $data['content'] = 'admin.support.merchant_support';
        return view('layouts.content', compact('data'))->with(['manager' => $countrydata]);
    }
    public function manage_support()
    {
        $countrydata = DB::table('manager_support')->get();

        $data['content'] = 'admin.support.operatormanag_support';
        return view('layouts.content', compact('data'))->with(['manager' => $countrydata]);
    }
    public function top_sales()
    {
        $countrydata = DB::table('users')->get();

        $data['content'] = 'admin.support.top_sales';
        return view('layouts.content', compact('data'))->with(['manager' => $countrydata]);
    }
    public function all_notification()
    {
        $countrydata = DB::table('notification')->get();

        $data['content'] = 'admin.support.all_notification';
        return view('layouts.content', compact('data'))->with(['manager' => $countrydata]);
    }
    
    public function add_cancellation(Request $request)
    {
        $data = array(
                    'reason_for' => $request->reason_for,
                    'cancel_reason' => $request->cancel_reason,
                    'created_at' => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('order_cancel_reason')->insert($data);
        return back();
    }

    public function add_countries(Request $request)
    {
        /*print_r($request->all()); die;*/
        $data = array(
            'code' => $request->code,
            'PhoneNumberCode' => $request->PhoneNumberCode,
            'name' => $request->name,
            'description' => $request->description,
        );
        if ($request->ids != '') {
            Session::flash('success', 'Updated successfully..!');
            $updateData = DB::table('countries')->where('id', $request->ids)->update($data);
            return back();
        } else {
            Session::flash('success', 'Inserted successfully..!');
            $insertData = DB::table('countries')->insert($data);
            return back();
        }
    }
    

    public function countries_edit($id)
    {
        $data = DB::table('countries')->where('id', $id)->first();
        return Response::json($data);
    }

    public function delete_countries($id)
    {
        $delete = DB::table('countries')->where('id', $id)->delete();
        session()->flash('error', 'Deleted Successfully..!');
        return redirect()->back();
    }
    /* Country section End */

    /* Customers section start */

    public function customer_view()
    {
        $customersdata = User::where('users_role', 3)->get();

        $data['content'] = 'admin.customer.manage_customer';
        return view('layouts.content', compact('data'))->with(['customersdata' => $customersdata]);
    }

    public function customer_delete($id)
    {
        $delete = DB::table('users')->where('id', $id)->delete();
        session()->flash('error', 'Deleted Successfully..!');
        return redirect()->back();
    }

    public function useremail($y)
    {
        $data = User::where('email', $y)->first();
        if ($data != '') {
            return Response::json($data);
        }
    }
    
    public function update_adminusers(Request $request)
    {
        $data = array(
                    'name' => $request->name,
                    'phone' => $request->phone,
                    'address' => $request->address,
                    'password' => $request->password,
                    'admin_type' => $request->admin_type,
                    'area_list' => $request->area_list,
                    'role' => $request->role,
                    'created_at' => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Inserted successfully..!');
        $insertData = DB::table('admin_user')->where('id',$request->id)->update($data);
        return back();
    }
    
    public function update_drawer(Request $request)
    {
        if ($files = $request->icon) {
            $destinationPath = public_path('/settings/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $icon = $insert['photo'] = "$profileImage";
        }
        $data = array(
                    'name' => $request->name,
                    'description' => $request->description,
                    'icon' => @$icon,
                    'sequence' => $request->sequence,
                    'created_at' => date('Y-m-d H:i:s')
                );
                
        Session::flash('success', 'Updated successfully..!');
        $insertData = DB::table('drawer')->where('id',$request->id)->update($data);
        return back();        
    }
    
    public function update_reason(Request $request)
    {
        $data = array(
                    'reason_for' => $request->reason_for,
                    'cancel_reason' => $request->cancel_reason,
                    'created_at' => date('Y-m-d H:i:s'),
                );
        
        Session::flash('success', 'Updated successfully..!');
        $insertData = DB::table('order_cancel_reason')->where('id',$request->id)->update($data);
        return back();
    }

    public function upload_user_document(Request $request)
    {
        $data = array();
        if ($request->bill) {
            $files = $request->bill;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bill'] = "$profileImage";
        }

        if ($request->passport) {
            $files = $request->passport;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['passport'] = "$profileImage";
        }

        if ($request->bank) {
            $files = $request->bank;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bank'] = "$profileImage";
        }

        if (count($data) > 0) {
            Session::flash('success', 'Document Updated Successfully..!');
            $updateData = DB::table('users')->where('id', $request->userid)->update($data);
            return back();
        } else {
            session()->flash('error', 'Select Images..!');
            //$insertData = DB::table('users')->insert($data);
            return back();
        }
    }

    public function admin_update_document(Request $request, $id)
    {
        $data = array();
        if ($request->bill) {
            $files = $request->bill;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bill'] = "$profileImage";
        }

        if ($request->passport) {
            $files = $request->passport;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['passport'] = "$profileImage";
        }

        if ($request->bank) {
            $files = $request->bank;
            $destinationPath = public_path('/user_document/');
            $profileImage = date('YmdHis') . "-" . $files->getClientOriginalName();
            $path =  $files->move($destinationPath, $profileImage);
            $data['bank'] = "$profileImage";
        }

        if (count($data) > 0) {
            Session::flash('success', 'Document Updated Successfully..!');
            $updateData = DB::table('users')->where('id', $id)->update($data);
            return back();
        } else {
            session()->flash('error', 'No Images selected..!');
            return back();
        }
    }

    /* Customers section End */
}
