<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Facades\Excel;
use App\Categary;
use Session;
use Response;
use App\User;
use DB;
use Hash;
use Auth;
use App\Lead;


class CategoryController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth');
    $this->middleware('role');
  }

  public function add_categorry()
  {
    $categorydata = DB::table('category')->get();
    $data['content'] = 'admin.category.add_category';
    return view('layouts.content', compact('data'))->with(['categorydata' => $categorydata]);
  }

  public function add_model(Request $request)
  {
    //dd($request->all());
    $data = array(
      //'brand_id'      => $request->brand_id,
      'service'       =>$request->servece,
      //'upload_by'     => Session::get('gorgID'),
      //'category_name' => $request->category_name,
      'description'   => $request->description,
      'status'        => $request->status,
      'created_at'    => date('Y-m-d H:i:s'),
    );
    Session::flash('success', 'Inserted successfully..!');
    $insertData = DB::table('category')->insert($data);
    return redirect('view-category');
  }

  public function listing_model()
  {
    $categorydata = DB::table('category')->get(); 
    $data['content'] = 'admin.category.manage_category';
    return view('layouts.content', compact('data'))->with(['categorydata' => $categorydata]);
  }
  public function manage_category(Request $request)
  {
    $categorydata = DB::table('category')->get(); 
    $data['content'] = 'admin.category.manage_category';
    return view('layouts.content', compact('data'))->with(['categorydata' => $categorydata]);
  }

  public function model_view($id)
  {
    $modeldata = DB::table('category')->where('id', $id)->first();
    $data['content'] = 'admin.category.view_category';
    return view('layouts.content', compact('data'))->with(['modeldata' => $modeldata]);
  }

  public function editCatogary($id)
  {
    $editmodel = DB::table('category')->where('id', $id)->first();
    // dd($editmodel);
    $data['content'] = 'admin.category.edit_category';
    return view('layouts.content', compact('data'))->with(['editmodel' => $editmodel]); 
  }
  public function updateCatogary(Request $request, $id)
  {
   //dd($request->all());
    $data = array(
      'upload_by' => 1,
      'service'=>$request->service,
      'description' => $request->description,
      'status' => $request->status,
      'updated_at' => date('Y-m-d H:i:s')
    );
    $insertData = DB::table('category')->where('id', $id)->update($data);
    Session::flash('success', 'Update successfully..!');
    return redirect('view-category');
  }
  public function delete_model($id)
  {
    $delete = DB::table('category')->where('id', $id)->delete();
    Session::flash('error', 'Data delete successfully..!');
    return back();
  }
}
